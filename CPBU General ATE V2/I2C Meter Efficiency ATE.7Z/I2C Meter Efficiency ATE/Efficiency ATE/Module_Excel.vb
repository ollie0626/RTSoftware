﻿
Imports Excel = Microsoft.Office.Interop.Excel
'2017/6/6


Module Module_Excel
    Public Excel_file As String
    Public xlApp As Excel.Application
    Public xlBooks As Excel.Workbooks
    Public xlBook As Excel.Workbook
    Public xlSheet As Excel.Worksheet
    Public xlrange As Excel.Range
    Public shpPic As Excel.Shape
    Public xlChart As Excel.Chart
    Public col As Integer = 1
    Public row As Integer = 1



    Public Function UsedRows(ByVal FileName As String, ByVal SheetName As String) As Integer

        Dim RowsUsed As Integer = -1

        If IO.File.Exists(FileName) Then
            Dim xlAplication As Excel.Application = Nothing
            Dim xlWorkBooks As Excel.Workbooks = Nothing
            Dim xlWorkBook As Excel.Workbook = Nothing
            Dim xlWorkSheet As Excel.Worksheet = Nothing
            Dim xlWorkSheets As Excel.Sheets = Nothing

            xlAplication = New Excel.Application
            xlAplication.DisplayAlerts = False
            xlWorkBooks = xlAplication.Workbooks
            xlWorkBook = xlWorkBooks.Open(FileName)

            xlAplication.Visible = False

            xlWorkSheets = xlWorkBook.Sheets

            For x As Integer = 1 To xlWorkSheets.Count

                xlWorkSheet = CType(xlWorkSheets(x), Excel.Worksheet)

                If xlWorkSheet.Name = SheetName Then
                    Dim xlCells As Excel.Range = Nothing
                    xlCells = xlWorkSheet.Cells

                    Dim xlTempRange As Excel.Range = xlCells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell)

                    RowsUsed = xlTempRange.Row
                    Runtime.InteropServices.Marshal.FinalReleaseComObject(xlTempRange)
                    xlTempRange = Nothing

                    Runtime.InteropServices.Marshal.FinalReleaseComObject(xlCells)
                    xlCells = Nothing

                    Exit For
                End If

                Runtime.InteropServices.Marshal.FinalReleaseComObject(xlWorkSheet)
                xlWorkSheet = Nothing

            Next

            xlWorkBook.Close()
            xlAplication.UserControl = True
            xlAplication.Quit()



            ReleaseComObject(xlWorkSheets)
            ReleaseComObject(xlWorkSheet)
            ReleaseComObject(xlWorkBook)
            ReleaseComObject(xlWorkBooks)
            ReleaseComObject(xlAplication)


        Else
            Throw New Exception("'" & FileName & "' not found.")
        End If

        Return RowsUsed

    End Function

    Public Sub ReleaseComObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        End Try
    End Sub

    Function ColumnLetter(ByVal ColumnNumber As Integer) As String

        If ColumnNumber > 26 Then



            ' 1st character:  Subtract 1 to map the characters to 0-25,

            '                 but you don't have to remap back to 1-26

            '                 after the 'Int' operation since columns

            '                 1-26 have no prefix letter



            ' 2nd character:  Subtract 1 to map the characters to 0-25,

            '                 but then must remap back to 1-26 after

            '                 the 'Mod' operation by adding 1 back in

            '                 (included in the '65')



            ColumnLetter = Chr(Int((ColumnNumber - 1) / 26) + 64) & Chr(((ColumnNumber - 1) Mod 26) + 65)

        Else

            ' Columns A-Z

            ColumnLetter = Chr(ColumnNumber + 64)

        End If


    End Function
    Function IsXLBookOpen(ByVal strName As String) As Boolean
        Dim temp As String
        'Function designed to test if a specific Excel
        'workbook is open or not.

        Dim i As Long
        Dim XLAppFx As Excel.Application
        Dim NotOpen As Boolean

        'Find/create an Excel instance
        On Error Resume Next '指定發生執行階段錯誤時, 控制權會移至緊接在發生錯誤的語句之後的語句, 並從該點繼續執行。
        XLAppFx = GetObject(, "Excel.Application")
        If Err.Number = 429 Then '文件已打開
            NotOpen = True
            XLAppFx = CreateObject("Excel.Application")
            Err.Clear()
        End If

        'Loop through all open workbooks in such instance
        For i = XLAppFx.Workbooks.Count To 1 Step -1
            temp = XLAppFx.Workbooks(i).Name
            If XLAppFx.Workbooks(i).Name = strName Then Exit For

        Next i

        'Set all to False
        IsXLBookOpen = False

        'Perform check to see if name was found
        If i <> 0 Then IsXLBookOpen = True

        'Close if was closed
        If NotOpen Then XLAppFx.Quit()

        'Release the instance
        XLAppFx = Nothing

    End Function

    Function ConvertToLetter(ByRef iCol As Integer) As String

        Dim dividend As Integer = iCol
        Dim columnName As String = String.Empty
        Dim modulo As Integer

        While dividend > 0
            modulo = (dividend - 1) Mod 26
            columnName = Convert.ToChar(65 + modulo).ToString() & columnName
            dividend = CInt((dividend - modulo) / 26)
        End While

        Return columnName


    End Function

End Module
