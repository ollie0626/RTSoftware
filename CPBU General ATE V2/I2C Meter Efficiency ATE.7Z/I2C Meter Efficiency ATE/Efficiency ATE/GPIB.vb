﻿Module GPIB

    'GPIB
    Public BDINDEX As Short = 0 ' Board Index
    'Dim PRIMARY_ADDR_OF_DMM As Short = 6 ' Primary address of device
    Public NO_SECONDARY_ADDR As Short = 0 ' Secondary address of device
    Public TIMEOUT As Short = T1s ' Timeout value = 10 seconds
    Public EOTMODE As Short = 1 ' Enable the END message
    Public EOSMODE As Short = 0 ' Disable the EOS mode
    Public ErrMsg As String '  New VB6.FixedLengthString(100)
    Public ARRAYSIZE As Short = 255 ' Size of read buffer
    Public ValueStr As String = Space(ARRAYSIZE)

    Public pad(&H1F) As Short
    Public instrument(&H1F) As Integer
    Public description(&H1F) As String
    Public dev_num As Integer


    Function check_gpib(ByVal status As Object, ByVal device As String) As Boolean
        Dim gpib_error As Boolean
        If (ibsta And EERR) Then
            status.Text = "GPIB connection to the " & device & " is not detected!"
            gpib_error = True
        Else
            gpib_error = False
        End If
        Return gpib_error
    End Function

    Function gpib_rst(ByVal device As String) As Double
        Dim ts As String
        ts = "*RST"
        ilwrt(device, ts, CInt(Len(ts)))

    End Function

  
End Module
