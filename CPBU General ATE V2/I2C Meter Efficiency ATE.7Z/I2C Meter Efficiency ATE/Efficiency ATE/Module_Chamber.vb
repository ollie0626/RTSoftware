﻿Module Module_Chamber

    Public Temp_name As String
    Public Temp_Dev As Integer
    Public Temp_addr As Integer
    Public ts As String
    Public Temp_Time As Double = 0
    Function Chamber_Temp_set(ByVal Temp As Double) As Integer
        Dim temp_now As Integer


        set_temp(Temp, 0)
        Delay(100)

        temp_now = read_temp()

        If Temp > temp_now Then

            While temp_now < Temp
                System.Windows.Forms.Application.DoEvents()
                If run = False Then
                    Exit While
                End If
                temp_now = read_temp()

            End While

        Else

            While temp_now > Temp
                System.Windows.Forms.Application.DoEvents()
                If run = False Then
                    Exit While
                End If

                temp_now = read_temp()


            End While

        End If


    End Function
    Function chamber_init() As Integer
        'TIMEOUT = T10s
        Temp_Dev = ildev(BDINDEX, Temp_addr, NO_SECONDARY_ADDR, TIMEOUT, EOTMODE, EOSMODE)

    End Function

    Function set_temp(ByVal temp As Double, ByVal time As Double) As Integer

        '正 = 空白 Convert.ToChar(&HB) , 負 = -
        ' ts = "T " & temp & "," & time & Convert.ToChar(13) & Convert.ToChar(10) 'vbNewLine  'sprintf(ts,"T %d.0,0 \n\r",chamber_settemp); //設定溫箱
        ts = "T" & temp & "," & time & vbNewLine
        ilwrt(Temp_Dev, ts, CInt(Len(ts)))

        'T <Temp.>,<Min.>
        'Sets chamber to arrive at temperature in set minutes.
    End Function


    Function read_set() As Double
        Dim test As Double
        'Returns user set temperature.

        ts = "ST" & vbNewLine  'Convert.ToChar(13) & Convert.ToChar(10)

        ilwrt(Temp_Dev, ts, CInt(Len(ts)))

        ' Delay(100)
        ilrd(Temp_Dev, ValueStr, ARRAYSIZE)

        If ibcnt > 0 Then
            test = Val(Mid(ValueStr, 1, (ibcntl - 1)))
        End If

        Return test
    End Function

    Function read_temp() As Double
        Dim test As Double
        Dim temp As String


        'Returns actual temperature.
        ts = "AT" & Convert.ToChar(13) & Convert.ToChar(10) 'vbNewLine  'Convert.ToChar(13) & Convert.ToChar(10)
        ilwrt(Temp_Dev, ts, CInt(Len(ts)))

        ' Delay(100)
        ilrd(Temp_Dev, ValueStr, ARRAYSIZE)

        If ibcnt > 0 Then

            temp = Mid(ValueStr, 1, 1)
            If temp = "-" Or temp = "=" Then
                test = -Val(Mid(ValueStr, 2, (ibcntl - 1)))
            Else
                test = Val(Mid(ValueStr, 1, (ibcntl - 1)))
            End If


        End If


        Return test
    End Function

    Function temp_off() As Integer

        ts = "T 25.0,0" & vbNewLine  'sprintf(ts,"T %d.0,0 \n\r",chamber_settemp); //設定溫箱
        ilwrt(Temp_Dev, ts, CInt(Len(ts)))

        'Turns temperature off.
        ts = "KT" & Convert.ToChar(13) ' vbNewLine 'Convert.ToChar(13)
        ilwrt(Temp_Dev, ts, CInt(Len(ts)))
    End Function

    Function Chamber_off() As Integer
        'Turns the chamber off and releases the test wheel.
 
        ts = "O" & vbNewLine 'Convert.ToChar(13)
        ilwrt(Temp_Dev, ts, CInt(Len(ts)))

    End Function


End Module
