﻿Module Modulel_Power

    Public N6705_Dev As Integer
    Public Power_2230_Dev As String
    Public Power_2230 As Boolean = False
    Public Power_num As Integer
    Dim ts As String

    Function Power2230_init() As String
        viOpenDefaultRM(defaultRM)
        viOpen(defaultRM, Power_2230_Dev, VI_NO_LOCK, 2000, vi)

        ts = "SYSTem:REMote"
        visa_status = viWrite(vi, ts, Len(ts), retcount)
        ts = "*RST"
        visa_status = viWrite(vi, ts, Len(ts), retcount)


        viClose(vi)
        viClose(defaultRM)
    End Function

    Function Power2230_ONOFF(ByVal on_off As String) As String
        viOpenDefaultRM(defaultRM)
        viOpen(defaultRM, Power_2230_Dev, VI_NO_LOCK, 2000, vi)

        ts = "OUTPUT " & on_off
        visa_status = viWrite(vi, ts, Len(ts), retcount)


        viClose(vi)
        viClose(defaultRM)
    End Function


    Function Power2230_set(ByVal OUT As Integer, ByVal VOLT As Double) As Integer

        viOpenDefaultRM(defaultRM)
        viOpen(defaultRM, Power_2230_Dev, VI_NO_LOCK, 2000, vi)


        ts = "INSTrument:NSELect " & OUT
        visa_status = viWrite(vi, ts, Len(ts), retcount)

        ts = "VOLT " & VOLT
        visa_status = viWrite(vi, ts, Len(ts), retcount)


        viClose(vi)
        viClose(defaultRM)

        'ts = "CURR " & CURR
        'visa_status = viWrite(vi, ts, Len(ts), retcount)

    End Function

    Function Power2230_read(ByVal OUT As Integer, ByVal volt_curr As String) As Double
        Dim value As Double

        viOpenDefaultRM(defaultRM)
        viOpen(defaultRM, Power_2230_Dev, VI_NO_LOCK, 2000, vi)


        ts = "INSTrument:NSELect " & OUT
        visa_status = viWrite(vi, ts, Len(ts), retcount)


        If volt_curr = "VOLT" Then
            ts = "MEAS:VOLT?"
        Else
            ts = "MEAS:CURR?"
        End If

        visa_status = viWrite(vi, ts, Len(ts), retcount)

        visa_status = viRead(vi, visa_response, Len(visa_response), retcount)

        value = Val(Mid(visa_response, 1, retcount))

        viClose(vi)
        viClose(defaultRM)

        Return value


    End Function





    Function N6705_OUT_set(ByVal OUT As String, ByVal VOLT As Double, ByVal CURR As Double) As Integer

        ts = "OUTP:COUP:CHAN " & OUT
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))


        ts = "VOLT " & VOLT & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        ts = "CURR " & CURR & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))



    End Function

    Function N6705_ONOFF(ByVal OUT As String, ByVal on_off As String) As Integer


        ts = "OUTP " & on_off & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

    End Function

    'Coupling


    Function N6705_ARB_ONOFF(ByVal OUT As String, ByVal on_off As String) As Integer

        If on_off = "ON" Then

            ts = "INIT:TRAN " & "(@" & OUT & ")"


        Else

            ts = "ABORt:TRANsient " & "(@" & OUT & ")"
        End If


        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

    End Function



    Function N6705_ARB_init(ByVal OUT As String, ByVal last_Arb As String, ByVal Continuous As Boolean, ByVal Count As Integer) As Integer


        'OFF: Return to DC Value
        'ON: Last Arb Value


        ts = "ARB:FUNCtion TRAPezoid" & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        ts = "VOLT:MODE ARB" & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        ts = "ARB:TERM:LAST " & last_Arb & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        If Continuous = True Then
            'Repeat the Arb continuously.:
            ts = "ARB:COUN INF " & ",(@" & OUT & ")"

        Else
            'The number of times the Arb repeats.
            ts = "ARB:COUN " & Count & ",(@" & OUT & ")"

        End If

        ilwrt(N6705_Dev, ts, CInt(Len(ts)))


    End Function




    Function N6705_ARB_set(ByVal OUT As String, ByVal V0 As Double, ByVal V1 As Double, ByVal t0 As Double, ByVal t1 As Double, ByVal t2 As Double, ByVal t3 As Double, ByVal t4 As Double) As Integer
        'Start(Setting(I0 Or V0))
        'Peak(Setting(I1 Or V1))
        'Delay(t0)
        'Rise(Time(t1))
        'Peak(Width(t2))
        'Fall(Time(t3))
        'End Time (T4)

        'The setting before and after the trapezoid:
        ts = "ARB:VOLT:TRAP:STAR " & V0 & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        'The peak setting:
        ts = "ARB:VOLT:TRAP:TOP " & V1 & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        'The delay after the trigger is received but before the trapezoid starts:
        ts = "ARB:VOLT:TRAP:STAR:TIM " & t0 & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        'The time that the trapezoid ramps up (RTIM) :
        ts = "ARB:VOLT:TRAP:RTIM " & t1 & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        'The width of the peak:
        ts = "ARB:VOLT:TRAP:TOP:TIM " & t2 & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        'The time that the trapezoid ramps down (FTIM):
        ts = "ARB:VOLT:TRAP:FTIM " & t3 & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))

        'The time the output remains at the end setting after the trapezoid:
        ts = "ARB:VOLT:TRAP:END:TIM " & t4 & ",(@" & OUT & ")"
        ilwrt(N6705_Dev, ts, CInt(Len(ts)))



    End Function



    Function power_OUT_init(ByVal device As String, ByVal power_out As String) As Double

        ts = "INST:SEL " & power_out

        ilwrt(device, ts, CInt(Len(ts)))




    End Function

    Function power_3632_Range(ByVal device As String, ByVal range As String) As Integer
        'VOLTage:RANGe {P15V|P30V||LOW|HIGH}


        If range = "L" Then
            '15V,7A
            ts = "VOLTage:RANGe P15V"

        Else
            '30V,4A
            ts = "VOLTage:RANGe P30V"

        End If


        ilwrt(device, ts, CInt(Len(ts)))


    End Function


    Function power_3632_OCP(ByVal device As String, ByVal ocp As Double) As Double
        ts = "CURR " & Format(ocp, "#0.0")
        ilwrt(device, ts, CInt(Len(ts)))


    End Function

    Function power_on_off(ByVal device_name As String, ByVal device As String, ByVal on_off As String) As Integer

        Dim temp() As String

        temp = Split(device_name, " ")

        If temp(0) = "CHROMA" Then

            Select Case device_name

                Case "CHROMA 6210-40"

                    If on_off = "ON" Then
                        ts = "OUT ON"
                    Else
                        ts = "OUT OFF"
                    End If


                Case "CHROMA 62006P-100-25"

                    If on_off = "ON" Then
                        ts = "CONFigure:OUTPut ON"
                    Else
                        ts = "CONFigure:OUTPut OFF"
                    End If

            End Select

            ilwrt(device, ts, CInt(Len(ts)))

        Else

            If on_off = "ON" Then
                ts = "OUTP ON"
            Else
                ts = "OUTP OFF"
            End If

            ilwrt(device, ts, CInt(Len(ts)))

        End If




        Delay(1000)
    End Function

    Function power_volt(ByVal device_name As String, ByVal device As String, ByVal power_out As String, ByVal volt As Double) As Double
        Dim temp() As String

        temp = Split(device_name, " ")

        If temp(0) = "CHROMA" Then
            Select Case device_name

                Case "CHROMA 6210-40"
                    ts = "VSET " & Format(volt, "#0.000")

                Case "CHROMA 62006P-100-25"

                    ts = "SOURce:VOLTage " & Format(volt, "#0.000")

            End Select

        Else


            If power_out <> "" Then
                ts = "INST:SEL " & power_out
                ilwrt(device, ts, CInt(Len(ts)))
            End If

            ts = "VOLT " & Format(volt, "#0.000")


        End If

        ilwrt(device, ts, CInt(Len(ts)))

    End Function

    Function power_read(ByVal device_name As String, ByVal device As String, ByVal power_out As String, ByVal volt_curr As String) As Double
        Dim test As Double
        Dim temp As String


        If device_name = "CHROMA 6210-40" Then

            If volt_curr = "VOLT" Then
                ts = "VOUT?"
            Else
                ts = "IOUT?"
            End If

            ilwrt(device, ts, CInt(Len(ts)))
            ilrd(device, ValueStr, ARRAYSIZE)



            If ibcnt > 0 Then
                temp = ibcntl - 1
                test = Val(Mid(ValueStr, 6, temp))
            End If
            power_read = Format(Val(test), "#0.0000")
        Else

            If power_out <> "" Then
                ts = "INST:SEL " & power_out
                ilwrt(device, ts, CInt(Len(ts)))
            End If

            If volt_curr = "VOLT" Then
                ts = "MEAS:VOLT?"
            Else
                ts = "MEAS:CURR?"
            End If

            ilwrt(device, ts, CInt(Len(ts)))
            ilrd(device, ValueStr, ARRAYSIZE)
            If ibcnt > 0 Then
                temp = ibcntl - 1
                test = Val(Mid(ValueStr, 1, temp))
            End If
            power_read = Format(Val(test), "#0.0000")
        End If



        Return power_read

    End Function









End Module
