﻿
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.IO
Imports System.Math
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Runtime.InteropServices.Marshal
Public Class Main

    'power
    Dim VIN2_Dev As Integer
    Dim VIN2_out As String
    Dim VIN2_device As String
    Dim VIN1_Dev As Integer
    Dim VIN1_out As String
    Dim VIN1_device As String
    Dim Power_3631A(2) As Integer
    Dim Power_3632A(2) As Integer
    Dim Power_62006 As Integer
    'DAQ
    Dim daq_vin1 As Integer
    Dim daq_vin2 As Integer
    Dim daq_vout As Integer

    Dim Vout_row As Integer = 0
    Dim multivout_use As Boolean = False


    Dim TA_now As Integer
    Public run_second As Integer
    Public run_time As String
    Public hour As String
    Public minute As String
    Public second As String


    Dim vin1_now As Double
    Dim vin2_now As Double
    Dim vout_now As Double
    Dim iout_now As Double = 0

    Public power_init As Boolean = False
    Dim initial_i2c As Boolean = True

    'Chart
    Public chart_top As String
    Public chart_height As Integer = 16
    Public chart_width As Integer = 8
    Public chart_row_start As Integer
    Public chart_row_stop As Integer
    Public chart_title_color As Integer = 19
    Public chart_col As Integer
    Public chart_row As Integer
    Dim Eff_Chart As Excel.ChartObject

    Public init_time As Date
    Public t_day, t_hour, t_minute As Integer
    Public time_now As String
    Dim total_sec As Integer







    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        status_Version.Text = My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & My.Application.Info.Version.Build
        Check_Eagleboard()
        Scan_Instrument()

        cbox_sense_VIN.SelectedIndex = 1
        cbox_sense_VIN2.SelectedIndex = 0
        cbox_iout_ch.SelectedIndex = 0
        cbox_daq_vout.SelectedIndex = 2

        cbox_type_Eff.SelectedIndex = 1

        rbtn_meter_iout.Checked = True



        VIN2_check.Checked = False
        Panel_vin2.Enabled = False
        pic_VIN2.Visible = True
        Panel_power2.Visible = False


        check_vout.Checked = False
        Panel_multivout.Visible = False
        data_I2C_multi.Visible = False
        data_I2C.Visible = True

        btn_vout_set.Location = New Point(157, 33)

        data_I2C.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中


        data_I2C_multi.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C_multi.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C_multi.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C_multi.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C_multi.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C_multi.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
        data_I2C_multi.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中


     



    End Sub
    Function Scan_Instrument() As Integer
        Dim temp() As String
        Dim i As Integer
        Dim addr() As String
        Dim name() As String

        Power_3631A(0) = 0
        Power_3632A(0) = 0

        data_GPIB.Rows.Clear()
        cbox_VIN.Items.Clear()
        cbox_VIN2.Items.Clear()

        Temp_addr = 0
        DAQ_addr = 0
        Load_addr = 0

        Power_num = 0

        panel_chamber.Enabled = False

        temp = visa_scan()

        If visa_count >= 1 Then


            For i = 0 To temp.Length - 1


                Select Case Mid(temp(i), 1, 3)





                    Case "GPI"

                        addr = Split(temp(i), "::")


                        If addr(1) = 3 Then

                            data_GPIB.Rows.Add("Chamber", "4350B", addr(0) & "::" & addr(1) & "::INSTR")
                            Temp_addr = addr(1)
                            panel_chamber.Enabled = True


                        Else
                            name = visa_name(temp(i))
                            Select Case name(1)
                                'name(1):儀器型號



                                Case "34970A"


                                    data_GPIB.Rows.Add("DAQ", name(1), addr(0) & "::" & addr(1) & "::INSTR")
                                    DAQ_addr = addr(1)


                                Case "E36312A"

                                    Power_num = Power_num + 1
                                    data_GPIB.Rows.Add("Power" & "_" & Power_num, name(1), addr(0) & "::" & addr(1) & "::INSTR")
                                    cbox_VIN.Items.Add("Keysight E36312A")
                                    cbox_VIN2.Items.Add("Keysight E36312A")

                                Case "E3631A"

                                    Power_num = Power_num + 1

                                    data_GPIB.Rows.Add("Power" & "_" & Power_num, name(1), addr(0) & "::" & addr(1) & "::INSTR")

                                    If Power_3631A(0) = 0 Then
                                        Power_3631A(0) = addr(1)
                                        cbox_VIN.Items.Add("Agilent 3631A (25V)")
                                        cbox_VIN.Items.Add("Agilent 3631A (6V)")
                                        cbox_VIN2.Items.Add("Agilent 3631A (25V)")
                                        cbox_VIN2.Items.Add("Agilent 3631A (6V)")



                                    Else
                                        Power_3631A(1) = addr(1)
                                        cbox_VIN.Items.Add("Agilent 3631A (25V)-2")
                                        cbox_VIN.Items.Add("Agilent 3631A (6V)-2")
                                        cbox_VIN2.Items.Add("Agilent 3631A (25V)-2")
                                        cbox_VIN2.Items.Add("Agilent 3631A (6V)-2")
                                    End If


                                Case "E3632A"

                                    Power_num = Power_num + 1

                                    data_GPIB.Rows.Add("Power" & "_" & Power_num, name(1), addr(0) & "::" & addr(1) & "::INSTR")


                                    If Power_3632A(0) = 0 Then
                                        Power_3632A(0) = addr(1)
                                        cbox_VIN.Items.Add("Agilent 3632A")
                                        cbox_VIN2.Items.Add("Agilent 3632A")
                                    Else
                                        Power_3632A(1) = addr(1)
                                        cbox_VIN.Items.Add("Agilent 3632A-2")
                                        cbox_VIN2.Items.Add("Agilent 3632A-2")
                                    End If

                                Case "62006P-100-25"

                                    Power_num = Power_num + 1
                                    data_GPIB.Rows.Add("Power" & "_" & Power_num, name(1), addr(0) & "::" & addr(1) & "::INSTR")


                                    Power_62006 = addr(1)
                                    cbox_VIN.Items.Add("CHROMA 62006P-100-25")
                                    cbox_VIN2.Items.Add("CHROMA 62006P-100-25")

                                Case "6301"

                                    data_GPIB.Rows.Add("DC Load", name(1), addr(0) & "::" & addr(1) & "::INSTR")
                                    Load_device = name(1)
                                    Load_addr = addr(1)


                                Case "6304"

                                    Load_device = name(1)
                                    data_GPIB.Rows.Add("DC Load", name(1), addr(0) & "::" & addr(1) & "::INSTR")
                                    Load_addr = addr(1)


                                Case "6312A"

                                    Load_device = name(1)
                                    data_GPIB.Rows.Add("DC Load", name(1), addr(0) & "::" & addr(1) & "::INSTR")
                                    Load_addr = addr(1)


                                Case "63600-1"

                                    Load_device = name(1)
                                    data_GPIB.Rows.Add("DC Load", name(1), addr(0) & "::" & addr(1) & "::INSTR")
                                    Load_addr = addr(1)



                                Case "63600-2"

                                    Load_device = name(1)
                                    data_GPIB.Rows.Add("DC Load", name(1), addr(0) & "::" & addr(1) & "::INSTR")
                                    Load_addr = addr(1)


                            End Select




                        End If







                End Select




            Next

        End If





        If Power_num = 0 Then

            cbox_VIN.Items.Add(No_Device)
            cbox_VIN2.Items.Add(No_Device)

        End If




        cbox_VIN.SelectedIndex = 0
        cbox_VIN2.SelectedIndex = 0


    End Function

    Private Sub btn_scan_Click(sender As Object, e As EventArgs) Handles btn_scan.Click
        Check_Eagleboard()
        Scan_Instrument()
    End Sub

    Private Sub VIN2_check_CheckedChanged(sender As Object, e As EventArgs) Handles VIN2_check.CheckedChanged
        If VIN2_check.Checked = True Then

            Panel_vin2.Enabled = True
            Panel_power2.Visible = True
            pic_VIN2.Visible = False


        Else

            Panel_vin2.Enabled = False
            Panel_power2.Visible = False
            pic_VIN2.Visible = True

        End If
    End Sub

    Private Sub check_vout_CheckedChanged(sender As Object, e As EventArgs) Handles check_vout.CheckedChanged

        data_i2c_vout.Rows.Clear()


        If check_vout.Checked = True Then

            btn_vout_set.Location = New Point(404, 29)

            Panel_multivout.Visible = True

            'I2C

            If multivout_use = False Then

                data_i2c_vout.Columns.Add("col_vout_addr", "Addr(Hex)")
                data_i2c_vout.Columns("col_vout_addr").Width = 80
                data_i2c_vout.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中

                data_i2c_vout.Columns.Add("col_vout_cmd", "Cmd & Data(Hex)")
                data_i2c_vout.Columns("col_vout_cmd").Width = 150
                data_i2c_vout.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter '內容置中
                multivout_use = True

            End If

            data_I2C_multi.Visible = True
            data_I2C.Visible = False




        Else

            btn_vout_set.Location = New Point(157, 33)

            Panel_multivout.Visible = False


            'I2C

            If multivout_use = True Then

                data_i2c_vout.Columns.Remove("col_vout_addr")
                data_i2c_vout.Columns.Remove("col_vout_cmd")
                multivout_use = False

            End If


            data_I2C_multi.Visible = False
            data_I2C.Visible = True



        End If




    End Sub
    Function power_select(ByVal device_name As String, ByVal num As Object) As String
        Dim out As String = ""

        Select Case device_name

            Case "OFF"
                num.text = 0

                out = ""

            Case "Agilent 3631A (25V)"
                num.text = Power_3631A(0)

                out = "P25V"

            Case "Agilent 3631A (6V)"

                num.text = Power_3631A(0)
                out = "P6V"

            Case "Agilent 3631A (25V)-2"
                num.text = Power_3631A(1)
                out = "P25V"

            Case "Agilent 3631A (6V)-2"

                num.text = Power_3631A(1)
                out = "P6V"

            Case "Agilent 3632A"

                num.text = Power_3632A(0)

                out = ""
            Case "Agilent 3632A-2"

                num.text = Power_3632A(1)

                out = ""

            Case "CHROMA 62006P-100-25"
                num.text = Power_62006
                out = ""


            Case "Keithley 2230-30-1 CH1"

                num.text = 0
                out = "1"

            Case "Keithley 2230-30-1 CH2"

                num.texte = 0
                out = "2"


            Case "Keithley 2230-30-1 CH3"

                num.text = 0
                out = "3"

        End Select

        Return out

    End Function
    Private Sub btn_vout_Clear_Click(sender As Object, e As EventArgs) Handles btn_vout_Clear.Click
        data_I2C.Rows.Clear()
        data_I2C_multi.Rows.Clear()
    End Sub


    Private Sub cbox_VIN_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbox_VIN.SelectedIndexChanged
        VIN1_device = cbox_VIN.SelectedItem
        VIN1_out = power_select(VIN1_device, num_addr_VIN)
    End Sub

    Private Sub cbox_sense_VIN_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbox_sense_VIN.SelectedIndexChanged
        If cbox_sense_VIN.SelectedItem <> "OFF" Then
            daq_vin1 = Mid(cbox_sense_VIN.SelectedItem, 3)
        End If
    End Sub

    Private Sub btn_vin_add_Click(sender As Object, e As EventArgs) Handles btn_vin_add.Click
        Dim VIN_row As Integer
        If data_vin.Rows.Count = 0 Then
            VIN_row = 0
        Else
            VIN_row = data_vin.SelectedCells(0).RowIndex + 1
        End If
        data_vin.Rows.Insert(VIN_row, num_start_VIN.Value)
        data_vin.CurrentCell = data_vin.Rows(VIN_row).Cells(0)
    End Sub

    Private Sub cbox_VIN2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbox_VIN2.SelectedIndexChanged
        VIN2_device = cbox_VIN2.SelectedItem
        VIN2_out = power_select(VIN2_device, num_addr_VIN2)
    End Sub

    Private Sub cbox_sense_VIN2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbox_sense_VIN2.SelectedIndexChanged
        If cbox_sense_VIN2.SelectedItem <> "OFF" Then
            daq_vin2 = Mid(cbox_sense_VIN2.SelectedItem, 3)
        End If
    End Sub

    Private Sub btn_iout_add_Click(sender As Object, e As EventArgs) Handles btn_iout_add.Click
        Dim Iout_step As Double
        Dim Iout As Double
        Dim Iout_row As Integer
        Dim new_iout() As Double




        If num_step_iout.Value = 0 Then
            If num_start_iout.Value > num_stop_iout.Value Then
                Iout_step = -1
            Else
                Iout_step = 1
            End If
        Else

            If num_start_iout.Value > num_stop_iout.Value Then
                Iout_step = -num_step_iout.Value


            Else
                Iout_step = num_step_iout.Value


            End If
        End If


        If num_start_iout.Value = 0 And num_stop_iout.Value = 0 Then

            data_iout.Rows.Insert(Iout_row, Format(0, "#0.0000"))
            data_iout.CurrentCell = data_iout.Rows(0).Cells(0)

        Else


            For Iout = num_start_iout.Value To num_stop_iout.Value Step Iout_step


                If data_iout.Rows.Count = 0 Then
                    Iout_row = 0
                Else
                    Iout_row = data_iout.SelectedCells(0).RowIndex + 1
                End If

                Iout = Format(Iout, "#0.0000")
                data_iout.Rows.Insert(Iout_row, Format(Iout, "#0.0000"))
                data_iout.CurrentCell = data_iout.Rows(Iout_row).Cells(0)


            Next


        End If

      
        new_iout = Calculate_iout(data_iout)
        data_iout.Rows.Clear()

        For i = 0 To new_iout.Length - 1
            data_iout.Rows.Insert(i, Format(new_iout(i), "#0.0000"))
            data_iout.CurrentCell = data_iout.Rows(i).Cells(0)
        Next

    End Sub

    Function Calculate_iout(ByVal data_iout As Object) As Double()
        Dim iout_temp() As Double


        ReDim iout_temp(data_iout.Rows.Count - 1)

        For i = 0 To data_iout.Rows.Count - 1
            iout_temp(i) = data_iout.Rows(i).Cells(0).Value
        Next

        ' 過濾重複的陣列元素 
        iout_temp = iout_temp.Distinct.ToArray()

        '------------------------------------------------------------
        '由小排到大

        Array.Sort(iout_temp)

        Return iout_temp

        '------------------------------------------------------------
    End Function


    Private Sub btn_iout_clear_Click(sender As Object, e As EventArgs) Handles btn_iout_clear.Click
        data_iout.Rows.Clear()
    End Sub

    Private Sub btn_add_w_Click(sender As Object, e As EventArgs) Handles btn_add_w.Click
        Dim addr, data, slave, i2c_row As Integer

        i2c_row = data_i2c_write.Rows.Count

        slave = num_test_slave_w.Value
        addr = num_test_addr_w.Value
        data = num_test_data.Value

        data_i2c_write.Rows.Insert(i2c_row, slave.ToString("X2"), addr.ToString("X2"), data.ToString("X2"))
        data_i2c_write.CurrentCell = data_i2c_write.Rows(i2c_row).Cells(0)
    End Sub


    Private Sub cbox_daq_vout_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbox_daq_vout.SelectedIndexChanged
        If cbox_daq_vout.SelectedItem <> "OFF" Then
            daq_vout = Mid(cbox_daq_vout.SelectedItem, 3)
        End If
    End Sub

    Private Sub btn_vout_set_Click(sender As Object, e As EventArgs) Handles btn_vout_set.Click
        Dim slave, i2c_row As Integer
        Dim vout As Double
        Dim cmd As String


        If txt_vout_volt.Text = "" Then
            MsgBox("Please enter the Vout test value!!", MsgBoxStyle.Exclamation, "Error")
            Exit Sub
        End If

        i2c_row = data_i2c_vout.Rows.Count
        vout = txt_vout_volt.Text
        cmd = txt_i2c.Text

        If check_vout.Checked = True Then

            slave = num_slave.Value


            data_i2c_vout.Rows.Insert(i2c_row, vout, slave.ToString("X2"), cmd)

        Else

            data_i2c_vout.Rows.Insert(i2c_row, vout, "", "")

        End If

        data_i2c_vout.CurrentCell = data_i2c_vout.Rows(i2c_row).Cells(0)
    End Sub

    Private Sub btn_add_Click(sender As Object, e As EventArgs) Handles btn_add.Click
        Dim iout_stop, vin_stop, temp_stop, vout_stop As Integer
        Dim vout, temp, vin1, vin2, iout_now, cmd As String
        Dim slave As String

        data_I2C.Rows.Clear()
        data_I2C_multi.Rows.Clear()

        If check_temp.Checked = True Then

            If data_Temp.Rows.Count = 0 Then
                MsgBox("Please enter the Temp test value!!", MsgBoxStyle.Exclamation, "Error")
                Exit Sub
            End If

        End If

        If data_vin.Rows.Count = 0 Then
            MsgBox("Please enter the Vin test value!!", MsgBoxStyle.Exclamation, "Error")
            Exit Sub
        End If

        If data_i2c_vout.Rows.Count = 0 Then
            MsgBox("Please enter the Vout test value!!", MsgBoxStyle.Exclamation, "Error")
            Exit Sub
        End If


        If data_iout.Rows.Count = 0 Then
            MsgBox("Please enter the Iout test value!!", MsgBoxStyle.Exclamation, "Error")
            Exit Sub
        End If


        If data_i2c_vout.Rows.Count = 0 Then
            MsgBox("Please enter the Vout test value!!", MsgBoxStyle.Exclamation, "Error")
            Exit Sub
        End If


        If data_vin.Rows.Count = 0 Then
            vin_stop = 0
        Else
            vin_stop = data_vin.Rows.Count - 1
        End If

        If check_temp.Checked = True Then

            If data_Temp.Rows.Count = 0 Then
                temp_stop = 0
            Else
                temp_stop = data_Temp.Rows.Count - 1
            End If

        Else
            temp_stop = 0
        End If


        If data_iout.Rows.Count = 0 Then
            iout_stop = 0
        Else
            iout_stop = data_iout.Rows.Count - 1
        End If

        If data_i2c_vout.Rows.Count = 0 Then
            vout_stop = 0
        Else
            vout_stop = data_i2c_vout.Rows.Count - 1
        End If


        If check_vout.Checked = True Then

            Vout_row = data_I2C_multi.Rows.Count
        Else

            Vout_row = data_I2C.Rows.Count

        End If



        For t = 0 To temp_stop

            If check_temp.Checked = True Then

                temp = data_Temp.Rows(t).Cells(0).Value
            Else

                temp = ""
            End If

            For ii = 0 To vin_stop

                vin1 = data_vin.Rows(ii).Cells(0).Value

                For a = 0 To vout_stop

                    vout = data_i2c_vout.Rows(a).Cells(0).Value

                    For i = 0 To iout_stop

                        iout_now = data_iout.Rows(i).Cells(0).Value

                        If VIN2_check.Checked = True Then

                            vin2 = num_start_VIN2.Value

                        Else

                            vin2 = ""

                        End If

                        If check_vout.Checked = True Then

                            slave = data_i2c_vout.Rows(a).Cells(1).Value
                            cmd = data_i2c_vout.Rows(a).Cells(2).Value

                            data_I2C_multi.Rows.Insert(Vout_row, temp, vout, vin1, vin2, iout_now, slave, cmd)
                            data_I2C_multi.CurrentCell = data_I2C_multi.Rows(Vout_row).Cells(0)

                        Else


                            data_I2C.Rows.Insert(Vout_row, temp, vout, vin1, vin2, iout_now)
                            data_I2C.CurrentCell = data_I2C.Rows(Vout_row).Cells(0)


                        End If


                        Vout_row = Vout_row + 1

                    Next



                Next



            Next

        Next



    End Sub

    Private Sub btn_test_export_Click(sender As Object, e As EventArgs) Handles btn_test_export.Click
        export_file()

        Delay(100)
        GC.Collect()
        GC.WaitForPendingFinalizers()
        Delay(100)
        System.Windows.Forms.Application.DoEvents()

    End Sub
    Function report_condition() As Integer

        xlSheet = xlBook.ActiveSheet

        With xlSheet

            .Activate()
            .Cells.Font.Name = "Arial"
            .Name = "Efficiency Test List"


            row = 1
            .Cells(row, 1) = "Instrument Set"
            .Cells(1, 1).Interior.Color = 65535

            row = row + 1 '2
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Temp Delay(sec):"
            .Cells(row, 2) = num_TA_delay.Text


            row = row + 1 '3
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Vin1 Power:"
            .Cells(row, 2) = cbox_VIN.SelectedItem

            .Cells(row, 3).Font.Bold = True
            .Cells(row, 3) = "DAQ Vin1:"
            .Cells(row, 4) = cbox_sense_VIN.SelectedItem


            row = row + 1 '4
            If VIN2_check.Checked = True Then

                .Cells(row, 1).Font.Bold = True
                .Cells(row, 1) = "Vin2 Power:"
                .Cells(row, 2) = cbox_VIN2.SelectedItem

                .Cells(row, 3).Font.Bold = True
                .Cells(row, 3) = "DAQ Vin2:"
                .Cells(row, 4) = cbox_sense_VIN2.SelectedItem


            End If

            row = row + 1 '5
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Load CH:"
            .Cells(row, 2) = cbox_iout_ch.SelectedItem

            row = row + 1 '6
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "DAQ Vout:"
            .Cells(row, 2) = cbox_daq_vout.SelectedItem



            row = row + 1 '7
            .Cells(row, 1) = "I2C Initial Set"
            .Cells(7, 1).Interior.Color = 65535


            row = row + 1 '8
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Addr(Hex)"


            For i = 0 To data_i2c_write.Rows.Count - 1

                For ii = 0 To data_i2c_write.Columns.Count - 1
                    .Cells(row + ii, 2 + i) = data_i2c_write.Rows(i).Cells(ii).Value
                Next
            Next


            row = row + 1 '9
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Cmd(Hex)"


            row = row + 1 '10
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Data(Hex)"



            row = row + 1 '11
            .Cells(row, 1) = "Chamber Set"
            .Cells(11, 1).Interior.Color = 65535


            row = row + 1 '12
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "TA(℃)"

            If check_temp.Checked = True Then
                For i = 0 To data_Temp.Rows.Count - 1
                    .Cells(row, 2 + i) = data_Temp.Rows(i).Cells(0).Value
                Next
            End If


            row = row + 1 '13
            .Cells(row, 1) = "Power Supply Set"
            .Cells(row, 1).Interior.Color = 65535


            row = row + 1 '14
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Vin1(V)"


            For i = 0 To data_vin.Rows.Count - 1
                .Cells(row, 2 + i) = data_vin.Rows(i).Cells(0).Value
            Next


            row = row + 1 '15
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Vin2(V)"

            If VIN2_check.Checked = True Then
                .Cells(row, 2) = num_start_VIN2.Value
            End If



            row = row + 1 '16
            .Cells(row, 1) = "Load Set"
            .Cells(row, 1).Interior.Color = 65535

            row = row + 1 '17
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Load(A)"

            For i = 0 To data_iout.Rows.Count - 1
                .Cells(row, 2 + i) = data_iout.Rows(i).Cells(0).Value
            Next



            row = row + 1 '18
            .Cells(row, 1) = "Vout Set"
            .Cells(row, 1).Interior.Color = 65535


            row = row + 1 '19
            .Cells(row, 1).Font.Bold = True
            .Cells(row, 1) = "Vout(V)"


            For i = 0 To data_i2c_vout.Rows.Count - 1

                For ii = 0 To data_i2c_vout.Columns.Count - 1
                    .Cells(row + ii, 2 + i) = data_i2c_vout.Rows(i).Cells(ii).Value
                Next
            Next


            If check_vout.Checked = True Then

                row = row + 1
                .Cells(row, 1).Font.Bold = True
                .Cells(row, 1) = "Addr(Hex)"

                row = row + 1
                .Cells(row, 1).Font.Bold = True
                .Cells(row, 1) = "Cmd & Data(Hex)"

            End If








            For i = 1 To 4

                .Columns(i).AutoFit()
                .Columns(i).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter

            Next


        End With






    End Function
    Function export_file() As Integer
        Dim sf_name As String


        dlgSave.Filter = "Excel Worksheets|*.xlsx|Excel 97-2003 Worksheets|*.xls"
        dlgSave.FilterIndex = 1
        dlgSave.RestoreDirectory = True
        dlgSave.DefaultExt = ".xlsx"
        dlgSave.FileName = "Efficiency Setting"

        If dlgSave.ShowDialog() = System.Windows.Forms.DialogResult.OK Then


            sf_name = dlgSave.FileName
            dlgSave.Dispose()
            Delay(300)

            xlApp = CreateObject("Excel.Application") '創建EXCEL對象

            xlApp.DisplayAlerts = False

            xlBook = xlApp.Workbooks.Add

            xlBook.SaveAs(sf_name)


            report_condition()


            Delay(100)

            excel_close()

            MsgBox("Export File OK!!", MsgBoxStyle.Information, "Information") '輸出對話式窗

        End If

    End Function
    Function excel_close() As Integer


        'Delay(100)

        excel_close_temp()

        GC.Collect()
        GC.WaitForPendingFinalizers()

        ' Kill(file_name)
        'Delay(100)
    End Function
    Function excel_close_temp() As Integer
        xlBook.Save()
        xlBook.Close(True)

        FinalReleaseComObject(xlBook)
        xlApp.Quit() '結束EXCEL對象



        xlBook = Nothing
        xlSheet = Nothing

        FinalReleaseComObject(xlApp)
        xlApp = Nothing

    End Function

    Private Sub btn_temp_add_Click(sender As Object, e As EventArgs) Handles btn_temp_add.Click
        Dim temp_row As Integer
        If data_Temp.Rows.Count = 0 Then
            temp_row = 0
        Else
            temp_row = data_Temp.SelectedCells(0).RowIndex + 1
        End If
        data_Temp.Rows.Insert(temp_row, num_Temp_add.Value)
        data_Temp.CurrentCell = data_Temp.Rows(temp_row).Cells(0)
    End Sub
    Function check_file_open(ByVal file_name As String) As Integer
        Dim IsError = True
        Dim ReadIO As IO.FileStream
        Dim Mcu_Save_CSV_File As String = file_name



        While IsError '當IsError = True 就會執行 while loop直到 IsError = false
            Try  '提供一種方法來處理特定程式碼區塊中可能發生的部分或所有可能錯誤，同時仍執行程式碼。
                ReadIO = IO.File.OpenRead(Mcu_Save_CSV_File)
                'File.​Open​Read(String) 方法
                '開啟現有檔案來讀取。
                IsError = False                                 '/預設沒有錯誤狀態
            Catch Have_Read As System.IO.IOException
                '/讀取Have_Read.GetType.ToString目前狀態
                '/當出現System.IO.FileNotFoundException為檔案路徑不存在
                '/當出現System.IO.IOException為檔案被占用

                If Have_Read.GetType.ToString = "System.IO.FileNotFoundException" Then '嘗試存取磁碟上不存在的檔案失敗時，所擲回的例外狀況。
                    IO.File.Create(Mcu_Save_CSV_File).Dispose()
                    FileClose()
                Else
                    MsgBox("目前檔案被開啟，請關閉檔案後再試", 0)

                End If

                'MsgBox(Have_Read.GetType.ToString, 0)
            End Try
        End While
        ReadIO.Close()  '/關閉開啟的檔案

    End Function
    Function import_file() As Integer
        Dim test_name As String
        Dim import_ok_vin1 As Boolean = False
        Dim import_ok_vin2 As Boolean = False
        Dim last_col As Integer
        Dim temp(2) As String
        Dim test(2) As String
        Dim list(0) As String
        Dim col_value As String
        Dim iout_stop, vin_stop, temp_stop, vout_stop As Integer
        Dim vout, TA, vin1, vin2, iout_now, cmd As String
        Dim slave As String


        dlgOpen.Filter = "Excel Worksheets|*.xlsx|Excel 97-2003 Worksheets|*.xls"
        dlgOpen.FilterIndex = 1
        dlgOpen.RestoreDirectory = True
        dlgOpen.DefaultExt = ".xlsx"
        dlgOpen.FileName = "Efficiency Setting"

        If dlgOpen.ShowDialog() = System.Windows.Forms.DialogResult.OK Then



            check_file_open(dlgOpen.FileName)

            dlgOpen.Dispose() '釋放 Component 所使用的所有資源。

            Delay(300)

            pf_name = dlgOpen.FileName

            xlApp = CreateObject("Excel.Application") '創建EXCEL對象

            xlApp.DisplayAlerts = False

            xlBook = xlApp.Workbooks.Open(pf_name)

            xlSheet = xlBook.ActiveSheet

            test_name = xlSheet.Name

            FinalReleaseComObject(xlSheet)
            xlSheet = Nothing

            xlSheet = xlBook.ActiveSheet


            data_Temp.Rows.Clear()
            data_vin.Rows.Clear()
            data_iout.Rows.Clear()
            data_i2c_write.Rows.Clear()
            data_i2c_vout.Rows.Clear()
            data_I2C.Rows.Clear()
            data_I2C_multi.Rows.Clear()



            With xlSheet


                num_TA_delay.Text = .Cells(2, 2).Value
                cbox_iout_ch.SelectedItem = .Cells(5, 2).Value
                cbox_daq_vout.SelectedItem = .Cells(6, 2).Value
                cbox_sense_VIN.SelectedItem = .Cells(3, 4).Value


                For i = 0 To cbox_VIN.Items.Count - 1
                    If cbox_VIN.Items(i) = .Cells(3, 2).Value Then
                        cbox_VIN.SelectedIndex = i
                        import_ok_vin1 = True
                        Exit For
                    End If
                Next

                If import_ok_vin1 = False Then
                    cbox_VIN.SelectedIndex = 0
                End If

                If .Cells(4, 1).Value <> Nothing Then

                    VIN2_check.Checked = True
                    cbox_sense_VIN2.SelectedItem = .Cells(4, 4).Value

                    For i = 0 To cbox_VIN2.Items.Count - 1
                        If cbox_VIN2.Items(i) = .Cells(4, 2).Value Then
                            cbox_VIN2.SelectedIndex = i
                            import_ok_vin2 = True
                            Exit For
                        End If
                    Next
                    If import_ok_vin2 = False Then
                        cbox_VIN2.SelectedIndex = 0
                    End If

                End If




                last_col = .Range(ConvertToLetter(1) & 8).CurrentRegion.Columns.Count

                'I2C Initial Set
                col_value = .Cells(8, 2).Value

                If (col_value <> Nothing) And (col_value <> " ") And (col_value <> "") Then

                    For i = 0 To last_col

                        temp(0) = .Cells(8, i + 2).Value

                        If (temp(0) <> Nothing) And (temp(0) <> " ") And (temp(0) <> "") Then
                            data_i2c_write.Rows.Add(temp(0))

                            For ii = 1 To data_i2c_write.Columns.Count - 1

                                temp(ii) = .Cells(8 + ii, i + 2).Value
                                data_i2c_write.Rows(data_i2c_write.Rows.Count - 1).Cells(ii).Value = temp(ii)


                            Next

                        End If

                    Next

                    check_initial.Checked = True

                End If

                'Chamber Set
                col_value = .Cells(12, 2).Value
                If (col_value <> Nothing) And (col_value <> " ") And (col_value <> "") Then

                    For i = 0 To last_col

                        temp(0) = .Cells(12, i + 2).Value

                        If (temp(0) <> Nothing) And (temp(0) <> " ") And (temp(0) <> "") Then
                            data_Temp.Rows.Add(temp(0))
                        End If

                    Next

                    check_temp.Checked = True

                End If


                'Power Supply Set
                For i = 0 To last_col

                    temp(0) = .Cells(14, i + 2).Value

                    If (temp(0) <> Nothing) And (temp(0) <> " ") And (temp(0) <> "") Then
                        data_vin.Rows.Add(temp(0))
                    End If

                Next


                col_value = .Cells(15, 2).Value
                If (col_value <> Nothing) And (col_value <> " ") And (col_value <> "") Then
                    VIN2_check.Checked = True
                    num_start_VIN2.Value = .Cells(15, 2).Value
                End If

                'Load Set
                For i = 0 To last_col

                    temp(0) = .Cells(17, i + 2).Value

                    If (temp(0) <> Nothing) And (temp(0) <> " ") And (temp(0) <> "") Then
                        data_iout.Rows.Add(temp(0))
                    End If

                Next


                ' Vout Set
                col_value = .Cells(20, 2).Value

                If (col_value <> Nothing) And (col_value <> " ") And (col_value <> "") Then
                    'Multi-vout
                    check_vout.Checked = True

                    For i = 0 To last_col

                        temp(0) = .Cells(19, i + 2).Value

                        If (temp(0) <> Nothing) And (temp(0) <> " ") And (temp(0) <> "") Then
                            data_i2c_vout.Rows.Add(temp(0))

                            For ii = 1 To data_i2c_vout.Columns.Count - 1

                                temp(ii) = .Cells(19 + ii, i + 2).Value
                                data_i2c_vout.Rows(data_i2c_vout.Rows.Count - 1).Cells(ii).Value = temp(ii)


                            Next

                        End If

                    Next



                Else
                    'Single vout
                    For i = 0 To last_col
                        temp(0) = .Cells(19, i + 2).Value
                        If (temp(0) <> Nothing) And (temp(0) <> " ") And (temp(0) <> "") Then
                            data_i2c_vout.Rows.Add(temp(0))
                        End If
                    Next

                End If


                '------


                If data_vin.Rows.Count = 0 Then
                    vin_stop = 0
                Else
                    vin_stop = data_vin.Rows.Count - 1
                End If

                If check_temp.Checked = True Then

                    If data_Temp.Rows.Count = 0 Then
                        temp_stop = 0
                    Else
                        temp_stop = data_Temp.Rows.Count - 1
                    End If

                Else
                    temp_stop = 0
                End If


                If data_iout.Rows.Count = 0 Then
                    iout_stop = 0
                Else
                    iout_stop = data_iout.Rows.Count - 1
                End If

                If data_i2c_vout.Rows.Count = 0 Then
                    vout_stop = 0
                Else
                    vout_stop = data_i2c_vout.Rows.Count - 1
                End If


                If check_vout.Checked = True Then

                    Vout_row = data_I2C_multi.Rows.Count
                Else

                    Vout_row = data_I2C.Rows.Count

                End If



                For t = 0 To temp_stop

                    If check_temp.Checked = True Then

                        TA = data_Temp.Rows(t).Cells(0).Value
                    Else

                        TA = ""
                    End If

                    For ii = 0 To vin_stop

                        vin1 = data_vin.Rows(ii).Cells(0).Value

                        For a = 0 To vout_stop

                            vout = data_i2c_vout.Rows(a).Cells(0).Value

                            For i = 0 To iout_stop

                                iout_now = data_iout.Rows(i).Cells(0).Value

                                If VIN2_check.Checked = True Then

                                    vin2 = num_start_VIN2.Value

                                Else

                                    vin2 = ""

                                End If

                                If check_vout.Checked = True Then

                                    slave = data_i2c_vout.Rows(a).Cells(1).Value
                                    cmd = data_i2c_vout.Rows(a).Cells(2).Value

                                    data_I2C_multi.Rows.Insert(Vout_row, TA, vout, vin1, vin2, iout_now, slave, cmd)
                                    data_I2C_multi.CurrentCell = data_I2C_multi.Rows(Vout_row).Cells(0)

                                Else


                                    data_I2C.Rows.Insert(Vout_row, TA, vout, vin1, vin2, iout_now)
                                    data_I2C.CurrentCell = data_I2C.Rows(Vout_row).Cells(0)


                                End If


                                Vout_row = Vout_row + 1

                            Next



                        Next



                    Next

                Next





            End With







            excel_close()

            MsgBox("Import File OK!!", MsgBoxStyle.Information, "Information") '輸出對話式窗

        End If



    End Function
    Private Sub btn_test_import_Click(sender As Object, e As EventArgs) Handles btn_test_import.Click
        import_file()

        Delay(100)
        GC.Collect()
        GC.WaitForPendingFinalizers()
        Delay(100)
        System.Windows.Forms.Application.DoEvents()
    End Sub

    Private Sub btn_stop_Click(sender As Object, e As EventArgs) Handles btn_stop.Click
        run = False
        System.Windows.Forms.Application.DoEvents()
    End Sub

    Function input_meter_auto(ByVal average As Integer) As Double
        Dim read_data(1) As Integer
        Dim iout_now As Double
        Dim temp() As Integer
        Dim total As Double = 0
        Dim curr_data As Double
        Dim read_error As Integer

        Meas_ID_input_before = Meas_ID_input

        curr_data = power_read(VIN1_device, VIN1_Dev, VIN1_out, "CURR")

        If curr_data >= Meter_H Then

            Meas_ID_input = in_high_id
            data_input = &H0
            resolution_input = in_high_resolution

        End If

        If curr_data < Meter_H And curr_data >= Meter_L Then

            Meas_ID_input = in_middle_id
            data_input = &H2
            resolution_input = in_middle_resolution

        End If

        If curr_data < Meter_L Then

            Meas_ID_input = in_low_id
            data_input = &H1
            resolution_input = in_low_resolution

        End If

        Meas_ID_input_now = Meas_ID_input


        If Meas_ID_input_now <> Meas_ID_input_before Then

            reg_write_word(in_io_id, &H1, data_input, "H")  '切換檔位
            Delay(1000)

        End If

        Dim array() As Double
        Dim remove_data As Integer

        total = 0
        read_error = 0
        remove_data = 0

        ReDim array(average - 1 + remove_data)

        For i = 0 To (average - 1) + remove_data
            System.Windows.Forms.Application.DoEvents()
            If run = False Then
                Exit For
            End If
            temp = reg_read_word(Meas_ID_input_now, &H4, "H")
            While temp(0) <> 0 Or temp(1) = 65535
                System.Windows.Forms.Application.DoEvents()

                read_error = read_error + 1
                If (read_error = 5) Or (run = False) Then
                    Return 0
                    Exit Function
                End If
                Delay(10)
                temp = reg_read_word(Meas_ID_input_now, &H4, "H")
            End While
            Delay(10)
            iout_now = temp(1) * resolution_input * 10 ^ -3
            If i >= remove_data Then
                array(i) = iout_now
                total += array(i)
            End If

        Next

      
        If average > 0 Then
            total = total / average
        Else
            total = 0
        End If

        'Dim result As String = String.Join(",", array)
        'Console.WriteLine(result & "/" & power_read(VIN1_device, VIN1_Dev, VIN1_out, "CURR"))


        Return total

    End Function
   
    Function output_meter_auto(ByVal average As Integer) As Double
        Dim read_data(1) As Integer
        Dim iout_now As Double
        Dim temp() As Integer
        Dim total As Double = 0
        Dim curr_data As Double
        Dim read_error As Integer

        Meas_ID_output_before = Meas_ID_output

        curr_data = load_read("CURR")

        If curr_data >= Meter_H Then

            Meas_ID_output = out_high_id
            data_output = &H0
            resolution_output = out_high_resolution

        End If

        If curr_data < Meter_H And curr_data >= Meter_L Then

            Meas_ID_output = out_middle_id
            data_output = &H2
            resolution_output = out_middle_resolution

        End If

        If curr_data < Meter_L Then

            Meas_ID_output = out_low_id
            data_output = &H1
            resolution_output = out_low_resolution

        End If

        Meas_ID_output_now = Meas_ID_output


        If Meas_ID_output_now <> Meas_ID_output_before Then

            reg_write_word(out_io_id, &H1, data_output, "H")  '切換檔位
            Delay(1000)

        End If



        Dim array() As Double
        Dim remove_data As Integer

        read_error = 0
        total = 0
        remove_data = 0

        ReDim array(average - 1 + remove_data)


        For i = 0 To (average - 1) + remove_data
            System.Windows.Forms.Application.DoEvents()
            If run = False Then
                Exit For
            End If

            temp = reg_read_word(Meas_ID_output_now, &H4, "H")

            While temp(0) <> 0 Or temp(1) = 65535
                System.Windows.Forms.Application.DoEvents()

                read_error = read_error + 1
                If (read_error = 5) Or (run = False) Then
                    Return 0
                    Exit Function
                End If
                Delay(10)
                temp = reg_read_word(Meas_ID_output_now, &H4, "H")
            End While
            Delay(10)
            iout_now = temp(1) * resolution_output * 10 ^ -3
            If i >= remove_data Then
                array(i) = iout_now
                total += array(i)
            End If
          
        Next

        Dim result As String = String.Join(",", array)
        Console.WriteLine(result & "/" & load_read("CURR"))

        If average > 0 Then
            total = total / average
        Else
            total = 0
        End If


        Return total

    End Function

    Function relay_meter_intial() As Integer

        reg_write_word(in_io_id, &H3, &H0, "H")
        reg_write_word(in_io_id, &H1, &H0, "H") '切換最大檔位
        reg_write_word(in_high_id, &H5, in_high_comp, "H")
        reg_write_word(in_middle_id, &H5, in_middle_comp, "H")
        reg_write_word(in_low_id, &H5, in_low_comp, "H")

        Meas_ID_input = in_high_id
        data_input = &H0
        resolution_input = in_high_resolution


        reg_write_word(out_io_id, &H3, &H0, "H")
        reg_write_word(out_io_id, &H1, &H0, "H") '切換最大檔位
        reg_write_word(out_high_id, &H5, out_high_comp, "H")
        reg_write_word(out_middle_id, &H5, out_middle_comp, "H")
        reg_write_word(out_low_id, &H5, out_low_comp, "H")

        Meas_ID_output = out_high_id
        data_output = &H0
        resolution_output = out_high_resolution


    End Function
    Private Sub btn_run_Click(sender As Object, e As EventArgs) Handles btn_run.Click

        init_time = Now




        If check_temp.Checked = True Then

            If data_Temp.Rows.Count = 0 Then
                MsgBox("Please enter the Temp test value!!", MsgBoxStyle.Exclamation, "Error")
                Exit Sub
            End If

        End If

        If data_vin.Rows.Count = 0 Then
            MsgBox("Please enter the Vin test value!!", MsgBoxStyle.Exclamation, "Error")
            Exit Sub
        End If

        If data_i2c_vout.Rows.Count = 0 Then
            MsgBox("Please enter the Vout test value!!", MsgBoxStyle.Exclamation, "Error")
            Exit Sub
        End If


        If data_iout.Rows.Count = 0 Then
            MsgBox("Please enter the Iout test value!!", MsgBoxStyle.Exclamation, "Error")
            Exit Sub
        End If



        in_high_id = num_slave_in_H.Value
        in_middle_id = num_slave_in_M.Value
        in_low_id = num_slave_in_L.Value
        in_io_id = num_slave_in_IO.Value

        in_high_comp = num_comp_in_H.Value
        in_middle_comp = num_comp_in_M.Value
        in_low_comp = num_comp_in_L.Value

        in_high_resolution = num_resolution_in_H.Value
        in_middle_resolution = num_resolution_in_M.Value
        in_low_resolution = num_resolution_in_L.Value


        out_high_id = num_slave_out_H.Value
        out_middle_id = num_slave_out_M.Value
        out_low_id = num_slave_out_L.Value
        out_io_id = num_slave_out_IO.Value

        out_high_comp = num_comp_out_H.Value
        out_middle_comp = num_comp_out_M.Value
        out_low_comp = num_comp_out_L.Value

        out_high_resolution = num_resolution_out_H.Value
        out_middle_resolution = num_resolution_out_M.Value
        out_low_resolution = num_resolution_out_L.Value


        Check_Eagleboard()
        I2CScan()

        If Relay_OK = False Then

            MsgBox("Please Check Meter Board!!", MsgBoxStyle.Exclamation, "Error Message") '輸出對話式窗

            Exit Sub

        End If

        Temp_Dev = 0
        Load_Dev = 0
        VIN1_Dev = 0
        VIN2_Dev = 0
        DAQ_Dev = 0


        'temp
        If check_temp.Checked = True Then

            If Temp_addr = 0 Then
                MsgBox("GPIB connection to the Chamber is not detected !!", MsgBoxStyle.Exclamation, "Error")
                Exit Sub
            Else
                Temp_Dev = ildev(BDINDEX, Temp_addr, NO_SECONDARY_ADDR, TIMEOUT, EOTMODE, EOSMODE)
            End If

        End If

        If num_addr_VIN.Text = "" Then

            MsgBox("GPIB connection to the Power1 is not detected !!", MsgBoxStyle.Exclamation, "Error")
            RUN_stop()
            Exit Sub

        Else

            VIN1_Dev = ildev(BDINDEX, num_addr_VIN.Text, NO_SECONDARY_ADDR, TIMEOUT, EOTMODE, EOSMODE)

        End If



        If VIN2_check.Checked = True Then

            If num_addr_VIN2.Text = "" Then
                MsgBox("GPIB connection to the Power2 is not detected !!", MsgBoxStyle.Exclamation, "Error")
                RUN_stop()
                Exit Sub
            Else
                VIN2_Dev = ildev(BDINDEX, num_addr_VIN2.Text, NO_SECONDARY_ADDR, TIMEOUT, EOTMODE, EOSMODE)
            End If

        End If

        If Load_addr = 0 Then

            MsgBox("GPIB connection to the  DC Load is not detected !!", MsgBoxStyle.Exclamation, "Error")
            RUN_stop()
            Exit Sub

        Else

            Load_Dev = ildev(BDINDEX, Load_addr, NO_SECONDARY_ADDR, TIMEOUT, EOTMODE, EOSMODE)
            Load_ch = cbox_iout_ch.SelectedIndex + 1
            Load_range = Load_range_H
            load_init(Load_range)
            DCLoad_Iout(0)
            load_onoff("ON")
            Delay(10)
        End If


        If DAQ_addr = 0 Then
            MsgBox("GPIB connection to the Data Acquisition is not detected !!", MsgBoxStyle.Exclamation, "Error")
            RUN_stop()
            Exit Sub

        Else
            DAQ_Dev = ildev(BDINDEX, DAQ_addr, NO_SECONDARY_ADDR, TIMEOUT, EOTMODE, EOSMODE)
        End If

        dlgSave.Filter = "Excel 97-2003 Worksheets|*.xls|Excel Worksheets|*.xlsx"
        dlgSave.FilterIndex = 2
        dlgSave.RestoreDirectory = True
        dlgSave.DefaultExt = ".xlsx"
        dlgSave.FileName = "Efficiency" & "_" & DateTime.Now.ToString("MMdd")
        If dlgSave.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            sf_name = dlgSave.FileName
        Else

            Exit Sub

        End If


        check_file_open(dlgSave.FileName)

        xlApp = CreateObject("Excel.Application") '?萄遣EXCEL撠情
        xlApp.DisplayAlerts = False

        xlApp.Visible = False

        xlApp.AutoRecover.Enabled = False
        '此物件會以定時間隔備份所有檔案格式。

        xlBook = xlApp.Workbooks.Add

        xlBook.Activate()

        xlApp.Calculation = Excel.XlCalculation.xlCalculationManual
        '設置工作簿手動計算.
        'Excel比較不會有當機的情況發生

        xlBook.SaveAs(sf_name)

        excel_close()

        dlgSave.Dispose()

        Delay(300)

        run = True
        btn_run.Visible = False
        btn_stop.Visible = True



        start_run()

        excel_close()

        Delay(100)
        GC.Collect()
        GC.WaitForPendingFinalizers()

        Delay(100)
        System.Windows.Forms.Application.DoEvents()


        RUN_stop()

        total_sec = DateDiff(DateInterval.Second, init_time, Now)
        time_cal(total_sec)
        MsgBox("End Test,Total Time:" & time_now, MsgBoxStyle.Information, "Information")

    End Sub
    Function time_cal(ByVal sec_now As Integer) As Integer

        t_day = Math.Floor(sec_now / 60 / 60 / 24)
        t_hour = Math.Floor(sec_now / 60 / 60 - (t_day * 24))
        t_minute = Math.Floor(sec_now / 60 - (t_day * 24 * 60) - (t_hour * 60))
        time_now = t_day & " days " & t_hour & " hours " & t_minute & " miuntes "

    End Function
    Function Remaining_time(ByVal stop_time As String) As Integer
        Dim stopDate As Date

        stopDate = CDate(stop_time) '任何有效的日期運算式  ;每個函數都會將運算式強制為特定資料類型。使用 CDate 函數將字串轉換為日期。Convert to Date data type.  轉Date型態的值 


        'DateDiff 函式可以取得兩個日期的間隔，並且可以用年、月、日等單位傳回兩個日期的差距
        '傳回 Variant (Long) 指定兩個指定日期之間的時間間隔數目。
        hour = DateDiff(DateInterval.Hour, Now, stopDate)
        minute = DateDiff(DateInterval.Minute, Now, stopDate) - (hour * 60)
        second = DateDiff(DateInterval.Second, Now, stopDate) - (hour * 60 * 60) - minute * 60
        'txt_remaining_time.Text = hour & ":" & minute & ":" & second & " (hh:mm:ss)"

        Return (hour * 60 * 60 + minute * 60 + second)

    End Function
    Function start_run() As Integer
        Dim vout_stop As Integer
        Dim slave, addr, data As Integer
        'Dim cmd As String
        'Dim w_data(), w_cmd(1) As String
        'Dim len_number As Integer
        'Dim i2c_addr, i2c_data As Byte
        Dim total_serial As String
        Dim i2c_temp() As String
        Dim length_adc As Integer


        ReDim vin_meas(data_iout.Rows.Count - 1)
        ReDim iin_meas(data_iout.Rows.Count - 1)
        ReDim vout_meas(data_iout.Rows.Count - 1)
        ReDim iout_meas(data_iout.Rows.Count - 1)
        ReDim Eff_meas(data_iout.Rows.Count - 1)
        ReDim loss_meas(data_iout.Rows.Count - 1)
        ReDim PASS_meas(data_iout.Rows.Count - 1)


        Vin_test_num = 0
        Vout_test_num = 0

        power_init = False
        initial_i2c = True

        xlApp = CreateObject("Excel.Application") '?萄遣EXCEL撠情
        xlApp.DisplayAlerts = False
        xlApp.Visible = False
        xlBook = xlApp.Workbooks.Open(sf_name)

        xlSheet = xlBook.ActiveSheet

        With xlSheet
            .Activate()
            .Name = "Efficiency"
            .Cells.Font.Name = "Arial" '設定Arial 字型
        End With

        If check_temp.Checked = True Then

            TA_num = data_Temp.Rows.Count - 1

        Else

            TA_num = 0
            TA_title = ""
        End If


        If check_vout.Checked = True Then

            vout_stop = data_i2c_vout.Rows.Count - 1

        Else

            vout_stop = 0

        End If



        relay_meter_intial()



        For t = 0 To TA_num

            System.Windows.Forms.Application.DoEvents()

            If run = False Then
                Exit For ' 中斷迴圈
            End If

            TA_Test_num = t

            'Chamber
            If check_temp.Checked = True Then

                TA_now = data_Temp.Rows(t).Cells(0).Value
                TA_title = "TA=" & TA_now & ", "
                run_time = DateTime.Now.AddSeconds(num_TA_delay.Value)

                run_second = Remaining_time(run_time)

                'Delay
                While run_second > 0

                    System.Windows.Forms.Application.DoEvents()

                    If run = False Then
                        Exit While
                    End If


                    run_second = Remaining_time(run_time)

                    If run_second < 0 Then
                        status_test_min.Text = "0s"
                    Else
                        status_test_min.Text = run_second & "s"
                    End If

                End While


            End If


            If VIN2_check.Checked = True Then
                vin2_now = num_start_VIN2.Value
                power_volt(VIN2_device, VIN2_Dev, VIN2_out, vin2_now)
                If power_init = False Then
                    power_on_off(VIN2_device, VIN2_Dev, "ON")
                End If
            End If



            'power
            For v = 0 To data_vin.Rows.Count - 1
                '  Dim col_vin, col_iin, col_vout, col_iout, data_row As Integer
                System.Windows.Forms.Application.DoEvents()
                If run = False Then
                    Exit For ' 中斷迴圈
                End If

                vin1_now = data_vin.Rows(v).Cells(0).Value
                Vin_test_num = v

                If cbox_VIN.SelectedItem = "Agilent 3632A" Or cbox_VIN.SelectedItem = "Agilent 3632A-2" Then

                    If vin1_now > 15 Then
                        power_3632_Range(VIN1_Dev, "H")
                    Else
                        power_3632_Range(VIN1_Dev, "L")
                        power_3632_OCP(VIN1_Dev, num_VIN_OCP.Value)
                    End If

                End If

                power_volt(VIN1_device, VIN1_Dev, VIN1_out, vin1_now)
                If power_init = False Then
                    power_on_off(VIN1_device, VIN1_Dev, "ON")
                    power_init = True
                End If


                If check_initial.Checked = True And initial_i2c = True Then

                    For i2c_set = 0 To data_i2c_write.Rows.Count - 1
                        If run = False Then
                            Exit For
                        End If
                        slave = Val("&h" & data_i2c_write.Rows(i2c_set).Cells(0).Value)
                        addr = Val("&h" & data_i2c_write.Rows(i2c_set).Cells(1).Value)
                        data = Val("&h" & data_i2c_write.Rows(i2c_set).Cells(2).Value)
                        Device_ID = slave
                        reg_write(Device_ID, addr, data)
                    Next

                    initial_i2c = False
                    Delay(10)
                End If


                'vout

                For ii = 0 To vout_stop

                    System.Windows.Forms.Application.DoEvents()
                    If run = False Then
                        Exit For ' 中斷迴圈
                    End If

                    vout_now = data_i2c_vout.Rows(ii).Cells(0).Value
                    Vout_test_num = ii

                    If check_vout.Checked = True Then

                        slave = Val("&h" & data_i2c_vout.Rows(ii).Cells(1).Value)
                        i2c_temp = Split(data_i2c_vout.Rows(ii).Cells(2).Value, ",")

                        For a = 0 To i2c_temp.Length - 1

                            length_adc = Len(i2c_temp(a))

                            If length_adc > 6 Then

                                addr = "&H" & Mid(i2c_temp(a), 1, 2)
                                data = "&H" & Mid(i2c_temp(a), 4, 4)
                                reg_write_word(slave, addr, data, "H")

                            Else

                                addr = "&H" & Mid(i2c_temp(a), 1, 2)
                                data = "&H" & Mid(i2c_temp(a), 4, 2)
                                reg_write(slave, addr, data)

                            End If


                        Next




                    End If

                    'iout

                    For x = 0 To data_iout.Rows.Count - 1

                        System.Windows.Forms.Application.DoEvents()
                        If run = False Then
                            Exit For ' 中斷迴圈
                        End If

                        iout_now = data_iout.Rows(x).Cells(0).Value
                        DCLoad_Iout(iout_now)

                        'Sense Vin1
                        If cbox_sense_VIN.SelectedItem <> "OFF" Then
                            vin_power_sense(vin1_now, daq_vin1, VIN1_Dev, VIN1_device, VIN1_out, num_sense_VIN.Value)
                        End If
                        'Sense Vin2
                        If VIN2_check.Checked = True Then
                            If cbox_sense_VIN2.SelectedItem <> "OFF" Then
                                vin_power_sense(vin2_now, daq_vin2, VIN2_Dev, VIN2_device, VIN2_out, num_sense_VIN2.Value)
                            End If
                        End If

                        Delay(10)

                        'Loss=(VIN*IIN)-(VOUT*IOUT)
                        'Efficiency = (VOUT × ILOAD) / (VIN × IIN)*100
                        vin_meas(x) = DAQ_caculation(daq_vin1, num_meter_count.Value)
                        vout_meas(x) = DAQ_caculation(daq_vout, num_meter_count.Value)
                        iin_meas(x) = input_meter_auto(num_meter_count.Value)


                        If rbtn_meter_iout.Checked = True Then

                            iout_meas(x) = output_meter_auto(num_meter_count.Value)
                        Else
                            iout_meas(x) = load_read("CURR")

                        End If

                        Eff_meas(x) = (vout_meas(x) * iout_meas(x)) / (vin_meas(x) * iin_meas(x)) * 100
                        loss_meas(x) = (vin_meas(x) * iin_meas(x)) - (vout_meas(x) * iout_meas(x))

                        If Eff_meas(x) > num_pass_eff.Value Then
                            PASS_meas(x) = "PASS"
                        Else
                            PASS_meas(x) = "FAIL"
                        End If
                        'ReDim vin_meas(data_iout.Rows.Count - 1)
                        'ReDim iin_meas(data_iout.Rows.Count - 1)
                        'ReDim vout_meas(data_iout.Rows.Count - 1)
                        'ReDim iout_meas(data_iout.Rows.Count - 1)
                        'ReDim Eff_meas(data_iout.Rows.Count - 1)
                        'Console.WriteLine(iin_meas(x) & "/" & power_read(VIN1_device, VIN1_Dev, VIN1_out, "CURR"))
                    Next

                    report_eff()

                    chart_num = TA_Test_num * data_i2c_vout.Rows.Count + ii + 1

                    If (v = 0) Then
                        chart_col = 2
                        chart_row = first_row
                        chart_init(Eff_Chart, TA_title & "VOUT=" & vout_now & "V", "Efficiency", "Load Current (A)", "Efficiency (%)", iout_now, 0, 100, 0, cbox_type_Eff.SelectedItem)
                    End If


                    'Add Serial 
                    chart_row_start = init_row
                    chart_row_stop = end_row
                    total_serial = TA_title & " VOUT=" & vout_now & "V, VIN=" & vin1_now & "V"
                    chart_add_series(xlSheet.Name, Eff_Chart, chart_num, total_serial, start_col + 3, start_col + 4, False)
                    xlSheet.Columns(col).AutoFit()

                    xlBook.Save()

                Next


            Next



        Next


    End Function
    Function report_Group(ByVal start_col As Integer, ByVal start_row As Integer, ByVal col_num As Integer, ByVal row_num As Integer) As Integer
        Dim top As String

        'start_col:起始欄
        'start_row :起始列
        'col_num :一共幾欄
        ' row_num :一共幾列

        xlSheet.Activate()
        top = ConvertToLetter(start_col) & start_row & ":" & ConvertToLetter(start_col + col_num - 1) & (start_row + row_num)
        xlrange = xlSheet.Range(top)
        xlrange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous

        xlrange.Borders(Excel.XlBordersIndex.xlEdgeTop).Weight = Excel.XlBorderWeight.xlMedium
        xlrange.Borders(Excel.XlBordersIndex.xlEdgeBottom).Weight = Excel.XlBorderWeight.xlMedium
        xlrange.Borders(Excel.XlBordersIndex.xlEdgeRight).Weight = Excel.XlBorderWeight.xlMedium
        xlrange.Borders(Excel.XlBordersIndex.xlEdgeLeft).Weight = Excel.XlBorderWeight.xlMedium

        xlrange.Borders(Excel.XlBordersIndex.xlInsideHorizontal).Weight = Excel.XlBorderWeight.xlThin
        xlrange.Borders(Excel.XlBordersIndex.xlInsideVertical).Weight = Excel.XlBorderWeight.xlThin

        xlrange.HorizontalAlignment = Excel.Constants.xlCenter

        FinalReleaseComObject(xlrange)
        'xlrange = Nothing
    End Function
    Function report_title(ByVal title As String, ByVal start_col As Integer, ByVal start_row As Integer, ByVal col_num As Integer, ByVal row_num As Integer, ByVal color As Integer) As Integer
        Dim top As String

        xlSheet.Activate()
        top = ConvertToLetter(start_col) & start_row & ":" & ConvertToLetter(start_col + col_num - 1) & (start_row + row_num - 1)
        xlSheet.Cells(start_row, start_col) = title

        xlrange = xlSheet.Range(top)
        xlrange.MergeCells = True

        'xlrange.Interior.ColorIndex = color
        xlrange.HorizontalAlignment = Excel.Constants.xlCenter
        xlrange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous
        xlSheet.Columns(start_col).AutoFit()

        FinalReleaseComObject(xlrange)
        'xlrange = Nothing
    End Function
    Function chart_init(ByVal chart As Excel.ChartObject, ByVal title_text As String, ByVal chart_title As String, ByVal x_text As String, ByVal y_text As String, ByVal x_max As String, ByVal x_min As String, ByVal y_max As String, ByVal y_min As String, ByVal chart_type As String) As Integer
        Dim heigh As String
        Dim width As String
        Dim height_temp As Integer
        Dim width_temp As Integer
        Dim value As Double

        xlSheet.Activate()
        'Update Title
        report_title(title_text, chart_col, chart_row, chart_width, 1, chart_title_color)

        'Chart Init
        chart_row = chart_row + 1

        chart_top = ConvertToLetter(chart_col) & chart_row

        heigh = chart_top & ":" & ConvertToLetter(chart_col) & (chart_row + chart_height - 1)
        height_temp = xlSheet.Range(heigh).Height


        width = chart_top & ":" & ConvertToLetter(chart_col + chart_width - 1) & chart_row
        width_temp = xlSheet.Range(width).Width


        chart = xlSheet.ChartObjects.add(xlSheet.Range(chart_top).Left, xlSheet.Range(chart_top).Top, width_temp, height_temp)



        xlchart = chart.Chart



        xlchart.ChartType = Excel.XlChartType.xlXYScatterSmoothNoMarkers

        With xlchart
            .HasTitle = True
            .ChartTitle.Text = chart_title
            .ChartTitle.Font.Bold = False
            .ChartTitle.Font.Size = 14

        End With


        With xlchart.Axes(1)
            .HasTitle = True
            .HasMajorGridlines = True
            .AxisTitle.Text = x_text
            .AxisTitle.Font.Bold = False


            If chart_type = "Log" Then
                .ScaleType = Excel.XlScaleType.xlScaleLogarithmic
                .HasMinorGridlines = True '如果座標軸有次要格線，則為 True
                .MinimumScale = 0.000001
                .CrossesAt = 0.000001
                '傳回或設定數值座標軸上與類別座標軸的交點。 僅套用至數值座標軸。 讀取/寫入的 Double。

            Else
                .ScaleType = Excel.XlScaleType.xlScaleLinear

                If x_min = "" Then
                    .MinimumScaleIsAuto = True
                Else
                    value = Val(x_min)
                    .MinimumScale = value
                End If


            End If

            If x_max = "" Then
                .MaximumScaleIsAuto = True
            Else
                value = Val(x_max)
                .MaximumScale = value
            End If


        End With


        With xlchart.Axes(2)
            .HasTitle = True
            .AxisTitle.Text = y_text
            .AxisTitle.Font.Bold = False
            If y_min = "" Then
                .MinimumScaleIsAuto = True
            Else
                value = Val(y_min)
                .MinimumScale = value
            End If
            If y_max = "" Then
                .MaximumScaleIsAuto = True
            Else
                value = Val(y_max)
                .MaximumScale = value
            End If
            '.MinimumScale = y_min
            '.MaximumScale = y_max
            '.MinimumScaleIsAuto =
            '.MaximumScaleIsAuto = 
        End With

        FinalReleaseComObject(xlchart)
        xlchart = Nothing
    End Function


    Function chart_add_series(ByVal Test_sheet As String, ByVal chart_name As Excel.ChartObject, ByVal chart_num As Integer, ByVal series_text As String, ByVal x_col As Integer, ByVal y_col As Integer, ByVal linedash As Boolean) As Integer
        Dim num As Integer
        xlSheet.Activate()
        chart_name = xlSheet.ChartObjects(chart_num)
        xlchart = chart_name.Chart
        xlchart.SeriesCollection.NewSeries()
        num = xlchart.SeriesCollection.Count
        xlchart.FullSeriesCollection(num).Name = series_text
        xlchart.FullSeriesCollection(num).XValues = "='" & Test_sheet & "'!$" & ConvertToLetter(x_col) & "$" & chart_row_start & ":$" & ConvertToLetter(x_col) & "$" & chart_row_stop
        xlchart.FullSeriesCollection(num).Values = "='" & Test_sheet & "'!$" & ConvertToLetter(y_col) & "$" & chart_row_start & ":$" & ConvertToLetter(y_col) & "$" & chart_row_stop

        If linedash = True Then

            With xlchart.FullSeriesCollection(num).Format.Line
                .Visible = Microsoft.Office.Core.MsoTriState.msoTrue
                .DashStyle = Microsoft.Office.Core.MsoLineDashStyle.msoLineDash
                '    .Weight = 2
            End With

        End If

        FinalReleaseComObject(xlchart)
        xlchart = Nothing
    End Function
    Function report_eff() As Integer
        Dim end_col As Integer

        '    Public chart_width As Integer = 8
        '  Public test_col As Integer = 3
        start_col = test_col + chart_width + (Vin_test_num * 8)

        row_num = data_iout.Rows.Count + 2

        If row_num < (chart_height + 1) Then
            'TA_num = data_Temp.Rows.Count - 1
            'TA_Test_num=t
            'vout_now = data_i2c_vout.Rows(ii).Cells(0).Value
            'Vout_test_num = ii
            first_row = test_row + (Vout_test_num * (TA_num + 1) + TA_Test_num) * ((chart_height + 1) + row_Space)
        Else

            first_row = test_row + (Vout_test_num * (TA_num + 1) + TA_Test_num) * (row_num + row_Space)
        End If

        init_row = first_row + 2
        end_row = init_row + data_iout.Rows.Count - 1
        col = start_col

        'vin_meas(x) = DAQ_caculation(daq_vin1, num_meter_count.Value)
        'vout_meas(x) = DAQ_caculation(daq_vout, num_meter_count.Value)
        'iin_meas(x) = input_meter_auto(num_meter_count.Value)
        'iout_meas(x) = output_meter_auto(num_meter_count.Value)
        'Eff_meas(x) = (vout_meas(x) * iout_meas(x)) / (vin_meas(x) * iin_meas(x)) * 100

        With xlSheet

            .Activate()

            .Range(ConvertToLetter(col) & (init_row - 1)).Value = "VIN (V)"
            .Range(ConvertToLetter(col) & (init_row - 1)).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            .Range(xlApp.Cells(init_row, col), xlApp.Cells(end_row, col)).Value = xlApp.Transpose(vin_meas)
            .Columns(col).AutoFit()

            col = col + 1
            .Range(ConvertToLetter(col) & (init_row - 1)).Value = "IIN (A)"
            .Range(ConvertToLetter(col) & (init_row - 1)).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            .Range(xlApp.Cells(init_row, col), xlApp.Cells(end_row, col)).Value = xlApp.Transpose(iin_meas)
            .Columns(col).AutoFit()

            col = col + 1
            .Range(ConvertToLetter(col) & (init_row - 1)).Value = "VOUT (V)"
            .Range(ConvertToLetter(col) & (init_row - 1)).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            .Range(xlApp.Cells(init_row, col), xlApp.Cells(end_row, col)).Value = xlApp.Transpose(vout_meas)
            .Columns(col).AutoFit()

            col = col + 1
            .Range(ConvertToLetter(col) & (init_row - 1)).Value = "IOUT (A)"
            .Range(ConvertToLetter(col) & (init_row - 1)).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            .Range(xlApp.Cells(init_row, col), xlApp.Cells(end_row, col)).Value = xlApp.Transpose(iout_meas)
            .Columns(col).AutoFit()

            col = col + 1
            .Range(ConvertToLetter(col) & (init_row - 1)).Value = "Efficiency >" & num_pass_eff.Value & "%"
            .Range(ConvertToLetter(col) & (init_row - 1)).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            .Range(xlApp.Cells(init_row, col), xlApp.Cells(end_row, col)).Value = xlApp.Transpose(Eff_meas)
            .Columns(col).AutoFit()

            col = col + 1
            .Range(ConvertToLetter(col) & (init_row - 1)).Value = "Loss (W)"
            .Range(ConvertToLetter(col) & (init_row - 1)).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            .Range(xlApp.Cells(init_row, col), xlApp.Cells(end_row, col)).Value = xlApp.Transpose(loss_meas)
            .Columns(col).AutoFit()

            col = col + 1
            .Range(ConvertToLetter(col) & (init_row - 1)).Value = "PASS/FAIL"
            .Range(ConvertToLetter(col) & (init_row - 1)).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            .Range(xlApp.Cells(init_row, col), xlApp.Cells(end_row, col)).Value = xlApp.Transpose(PASS_meas)
            .Columns(col).AutoFit()


            For i = init_row To end_row

                If .Range(ConvertToLetter(col) & i).Value = "FAIL" Then
                    .Range(ConvertToLetter(col) & i).Interior.Color = 65535
                End If

            Next

            end_col = col

            .Range(ConvertToLetter(start_col) & (init_row - 2) & ":" & ConvertToLetter(end_col) & (init_row - 2)).MergeCells = True
            .Range(ConvertToLetter(start_col) & (init_row - 2) & ":" & ConvertToLetter(end_col) & (init_row - 2)).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            .Range(ConvertToLetter(start_col) & (init_row - 2) & ":" & ConvertToLetter(end_col) & (init_row - 2)).Value = TA_title & "VIN=" & vin1_now & "V , VOUT=" & vout_now & "V"

        End With

        'start_col:起始欄
        'start_row :起始列
        'col_num :一共幾欄
        ' row_num :一共幾列
        report_Group(start_col, first_row, col_num, end_row - first_row)



    End Function
    Function vin_power_sense(ByVal volt As Double, ByVal daq As Integer, ByVal device As String, ByVal device_name As String, ByVal power_out As String, ByVal range As Double) As Integer
        '  vin_power_sense(vin_now, daq_vin, VIN_Dev, cbox_VIN, VIN_out, num_sense_VIN)
        Dim value As Double
        Dim new_volt As Double
        Dim power_now As Double
        Dim data As Double

        power_now = power_read(device_name, device, power_out, "VOLT") 'power supply輸出電壓
        value = DAQ_read(daq) 'DAQ 量測電壓
        new_volt = power_now


        While (value > (volt + range) Or value < (volt - range))
            System.Windows.Forms.Application.DoEvents()

            If run = False Then
                Exit While
            End If

            If value > (volt + range) Then
                data = value - (volt + range)

                If data > 1 Then
                    new_volt = new_volt - 0.5
                End If
                If data < 1 And data > 0.1 Then
                    new_volt = new_volt - 0.1
                End If
                If data < 0.1 Then
                    new_volt = new_volt - range
                End If
                If new_volt <= 0 Then

                    run = False
                    MsgBox("Please Check Sense Pin!!", MsgBoxStyle.Exclamation, "Error")
                    Exit While

                End If


            Else

                data = (volt + range) - value

                If data > 1 Then
                    new_volt = new_volt + 0.5
                End If
                If data < 1 And data > 0.1 Then
                    new_volt = new_volt + 0.1
                End If
                If data < 0.1 Then
                    new_volt = new_volt + range
                End If


                If new_volt >= volt + 1 Then
                    run = False
                    MsgBox("Please Check Sense Pin!!", MsgBoxStyle.Exclamation, "Error")
                    Exit While
                End If




            End If

            power_volt(device_name, device, power_out, new_volt)
            value = DAQ_read(daq)


        End While



    End Function
    Function RUN_stop() As Integer

        run = False

        If Temp_Dev <> 0 Then
            temp_off()
            Chamber_off()
            ibonl(Temp_Dev, 0)
        End If

        Delay(10)


        If Load_Dev <> 0 Then
            DCLoad_Iout(0)
            load_onoff("OFF")
            ibonl(Load_Dev, 0)
        End If

        Delay(10)

        If VIN1_Dev <> 0 Then
            power_on_off(VIN1_device, VIN1_Dev, "OFF")
            ibonl(VIN1_Dev, 0)
        End If

        If VIN2_Dev <> 0 Then
            power_on_off(VIN2_device, VIN2_Dev, "OFF")
            ibonl(VIN2_Dev, 0)
        End If

        If DAQ_Dev <> 0 Then
            ibonl(DAQ_Dev, 0)
        End If




        btn_run.Visible = True
        btn_stop.Visible = False




    End Function



    Private Sub rbtn_meter_iout_CheckedChanged(sender As Object, e As EventArgs) Handles rbtn_meter_iout.CheckedChanged

        If rbtn_meter_iout.Checked = True Then
            Panel_out_merte.Visible = True
        End If

    End Sub

    Private Sub rbtn_iout_load_CheckedChanged(sender As Object, e As EventArgs) Handles rbtn_iout_load.CheckedChanged


        If rbtn_iout_load.Checked = True Then
            Panel_out_merte.Visible = False

        End If

    End Sub
End Class
