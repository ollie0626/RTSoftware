﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel8 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status_bridge = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status_Version = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status_test_min = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status_error = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.btn_scan = New System.Windows.Forms.Button()
        Me.data_GPIB = New System.Windows.Forms.DataGridView()
        Me.col_Instrument = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.Panel69 = New System.Windows.Forms.Panel()
        Me.data_Temp = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btn_temp_add = New System.Windows.Forms.Button()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.num_TA_delay = New System.Windows.Forms.NumericUpDown()
        Me.num_Temp_add = New System.Windows.Forms.NumericUpDown()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.VIN2_check = New System.Windows.Forms.CheckBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Panel_vin2 = New System.Windows.Forms.Panel()
        Me.num_addr_VIN2 = New System.Windows.Forms.TextBox()
        Me.cbox_VIN2 = New System.Windows.Forms.ComboBox()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.cbox_sense_VIN2 = New System.Windows.Forms.ComboBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.num_sense_VIN2 = New System.Windows.Forms.NumericUpDown()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.num_start_VIN2 = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.num_VIN_OCP = New System.Windows.Forms.NumericUpDown()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.num_start_VIN = New System.Windows.Forms.NumericUpDown()
        Me.btn_vin_add = New System.Windows.Forms.Button()
        Me.Panel_sense = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.cbox_sense_VIN = New System.Windows.Forms.ComboBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.num_sense_VIN = New System.Windows.Forms.NumericUpDown()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.data_vin = New System.Windows.Forms.DataGridView()
        Me.col_VIN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.cbox_VIN = New System.Windows.Forms.ComboBox()
        Me.num_addr_VIN = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.btn_iout_clear = New System.Windows.Forms.Button()
        Me.cbox_iout_ch = New System.Windows.Forms.ComboBox()
        Me.num_step_iout = New System.Windows.Forms.NumericUpDown()
        Me.num_stop_iout = New System.Windows.Forms.NumericUpDown()
        Me.num_start_iout = New System.Windows.Forms.NumericUpDown()
        Me.btn_iout_add = New System.Windows.Forms.Button()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.data_iout = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel_out_merte = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.num_slave_out_IO = New System.Windows.Forms.NumericUpDown()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.num_resolution_out_H = New System.Windows.Forms.NumericUpDown()
        Me.num_resolution_out_M = New System.Windows.Forms.NumericUpDown()
        Me.num_resolution_out_L = New System.Windows.Forms.NumericUpDown()
        Me.num_comp_out_H = New System.Windows.Forms.NumericUpDown()
        Me.num_slave_out_H = New System.Windows.Forms.NumericUpDown()
        Me.num_comp_out_M = New System.Windows.Forms.NumericUpDown()
        Me.num_slave_out_M = New System.Windows.Forms.NumericUpDown()
        Me.num_comp_out_L = New System.Windows.Forms.NumericUpDown()
        Me.num_slave_out_L = New System.Windows.Forms.NumericUpDown()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.rbtn_iout_load = New System.Windows.Forms.RadioButton()
        Me.rbtn_meter_iout = New System.Windows.Forms.RadioButton()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.num_slave_in_IO = New System.Windows.Forms.NumericUpDown()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.num_resolution_in_H = New System.Windows.Forms.NumericUpDown()
        Me.num_resolution_in_M = New System.Windows.Forms.NumericUpDown()
        Me.num_comp_in_H = New System.Windows.Forms.NumericUpDown()
        Me.num_slave_in_H = New System.Windows.Forms.NumericUpDown()
        Me.num_comp_in_M = New System.Windows.Forms.NumericUpDown()
        Me.num_slave_in_M = New System.Windows.Forms.NumericUpDown()
        Me.num_comp_in_L = New System.Windows.Forms.NumericUpDown()
        Me.num_slave_in_L = New System.Windows.Forms.NumericUpDown()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.num_resolution_in_L = New System.Windows.Forms.NumericUpDown()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.num_meter_count = New System.Windows.Forms.NumericUpDown()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.num_test_slave_w = New System.Windows.Forms.NumericUpDown()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.num_test_data = New System.Windows.Forms.NumericUpDown()
        Me.btn_add_w = New System.Windows.Forms.Button()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.data_i2c_write = New System.Windows.Forms.DataGridView()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_data_w = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.num_test_addr_w = New System.Windows.Forms.NumericUpDown()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.btn_add = New System.Windows.Forms.Button()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.panel_vout_i2c = New System.Windows.Forms.Panel()
        Me.Panel_multivout = New System.Windows.Forms.Panel()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Lab_note = New System.Windows.Forms.Label()
        Me.num_slave = New System.Windows.Forms.NumericUpDown()
        Me.txt_i2c = New System.Windows.Forms.TextBox()
        Me.data_i2c_vout = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.txt_vout_volt = New System.Windows.Forms.TextBox()
        Me.btn_vout_set = New System.Windows.Forms.Button()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbox_daq_vout = New System.Windows.Forms.ComboBox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.data_I2C = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.data_I2C_multi = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_vin2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btn_vout_Clear = New System.Windows.Forms.Button()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.num_pass_eff = New System.Windows.Forms.NumericUpDown()
        Me.btn_test_export = New System.Windows.Forms.Button()
        Me.btn_test_import = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.panel_setting = New System.Windows.Forms.Panel()
        Me.check_vout = New System.Windows.Forms.CheckBox()
        Me.pic_VIN2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.panel_initial = New System.Windows.Forms.Panel()
        Me.check_initial = New System.Windows.Forms.CheckBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel_power2 = New System.Windows.Forms.Panel()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.pic_TA = New System.Windows.Forms.PictureBox()
        Me.panel_chamber = New System.Windows.Forms.Panel()
        Me.check_temp = New System.Windows.Forms.CheckBox()
        Me.dlgOpen = New System.Windows.Forms.OpenFileDialog()
        Me.dlgSave = New System.Windows.Forms.SaveFileDialog()
        Me.btn_stop = New System.Windows.Forms.Button()
        Me.btn_run = New System.Windows.Forms.Button()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.cbox_type_Eff = New System.Windows.Forms.ComboBox()
        Me.StatusStrip1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.data_GPIB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.Panel69.SuspendLayout()
        CType(Me.data_Temp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_TA_delay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_Temp_add, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.Panel_vin2.SuspendLayout()
        Me.Panel17.SuspendLayout()
        CType(Me.num_sense_VIN2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_start_VIN2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel8.SuspendLayout()
        CType(Me.num_VIN_OCP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_start_VIN, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_sense.SuspendLayout()
        CType(Me.num_sense_VIN, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.data_vin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.Panel13.SuspendLayout()
        CType(Me.num_step_iout, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_stop_iout, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_start_iout, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.data_iout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.Panel_out_merte.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.num_slave_out_IO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_resolution_out_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_resolution_out_M, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_resolution_out_L, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_comp_out_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_slave_out_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_comp_out_M, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_slave_out_M, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_comp_out_L, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_slave_out_L, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel9.SuspendLayout()
        CType(Me.num_slave_in_IO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_resolution_in_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_resolution_in_M, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_comp_in_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_slave_in_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_comp_in_M, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_slave_in_M, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_comp_in_L, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_slave_in_L, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_resolution_in_L, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_meter_count, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.Panel15.SuspendLayout()
        CType(Me.num_test_slave_w, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_test_data, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.data_i2c_write, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.num_test_addr_w, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.panel_vout_i2c.SuspendLayout()
        Me.Panel_multivout.SuspendLayout()
        CType(Me.num_slave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.data_i2c_vout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        CType(Me.data_I2C, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.data_I2C_multi, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        CType(Me.num_pass_eff, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel_setting.SuspendLayout()
        CType(Me.pic_VIN2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel_initial.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_power2.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel20.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_TA, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel_chamber.SuspendLayout()
        Me.Panel40.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Silver
        Me.StatusStrip1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel8, Me.status_bridge, Me.ToolStripStatusLabel3, Me.status_Version, Me.ToolStripStatusLabel4, Me.status_test_min, Me.ToolStripStatusLabel1, Me.status_error})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 441)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 16, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(934, 24)
        Me.StatusStrip1.SizingGrip = False
        Me.StatusStrip1.TabIndex = 2048
        '
        'ToolStripStatusLabel8
        '
        Me.ToolStripStatusLabel8.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.ToolStripStatusLabel8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel8.Name = "ToolStripStatusLabel8"
        Me.ToolStripStatusLabel8.Size = New System.Drawing.Size(88, 19)
        Me.ToolStripStatusLabel8.Text = "Bridge Board:"
        '
        'status_bridge
        '
        Me.status_bridge.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.status_bridge.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.status_bridge.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.status_bridge.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.status_bridge.Name = "status_bridge"
        Me.status_bridge.Size = New System.Drawing.Size(112, 19)
        Me.status_bridge.Text = "No board detected"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(33, 19)
        Me.ToolStripStatusLabel3.Text = "Ver:"
        '
        'status_Version
        '
        Me.status_Version.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.status_Version.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.status_Version.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.status_Version.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.status_Version.Name = "status_Version"
        Me.status_Version.Size = New System.Drawing.Size(38, 19)
        Me.status_Version.Text = "1.0.0"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.ToolStripStatusLabel4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(102, 19)
        Me.ToolStripStatusLabel4.Text = "Remaining time:"
        '
        'status_test_min
        '
        Me.status_test_min.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.status_test_min.Name = "status_test_min"
        Me.status_test_min.Size = New System.Drawing.Size(18, 19)
        Me.status_test_min.Text = "0"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(51, 19)
        Me.ToolStripStatusLabel1.Text = "Status:"
        '
        'status_error
        '
        Me.status_error.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.status_error.Name = "status_error"
        Me.status_error.Size = New System.Drawing.Size(42, 19)
        Me.status_error.Text = "Ready"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage1)
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage2)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Location = New System.Drawing.Point(147, 6)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(640, 425)
        Me.TabControl2.TabIndex = 3089
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.LightGray
        Me.TabPage4.Controls.Add(Me.btn_scan)
        Me.TabPage4.Controls.Add(Me.data_GPIB)
        Me.TabPage4.Location = New System.Drawing.Point(4, 24)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(632, 397)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Instrument"
        '
        'btn_scan
        '
        Me.btn_scan.BackgroundImage = CType(resources.GetObject("btn_scan.BackgroundImage"), System.Drawing.Image)
        Me.btn_scan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_scan.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_scan.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btn_scan.Image = CType(resources.GetObject("btn_scan.Image"), System.Drawing.Image)
        Me.btn_scan.Location = New System.Drawing.Point(409, 137)
        Me.btn_scan.Name = "btn_scan"
        Me.btn_scan.Size = New System.Drawing.Size(106, 46)
        Me.btn_scan.TabIndex = 3253
        Me.btn_scan.Text = "Scan Device"
        Me.btn_scan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_scan.UseVisualStyleBackColor = True
        '
        'data_GPIB
        '
        Me.data_GPIB.AllowUserToAddRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.data_GPIB.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.data_GPIB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_GPIB.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_Instrument, Me.DataGridViewTextBoxColumn35, Me.col_Address})
        Me.data_GPIB.Location = New System.Drawing.Point(7, 8)
        Me.data_GPIB.Name = "data_GPIB"
        Me.data_GPIB.RowTemplate.Height = 24
        Me.data_GPIB.Size = New System.Drawing.Size(508, 114)
        Me.data_GPIB.TabIndex = 3252
        '
        'col_Instrument
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.col_Instrument.DefaultCellStyle = DataGridViewCellStyle2
        Me.col_Instrument.HeaderText = "Instrument"
        Me.col_Instrument.Name = "col_Instrument"
        Me.col_Instrument.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.HeaderText = "Device"
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        Me.DataGridViewTextBoxColumn35.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn35.Width = 70
        '
        'col_Address
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.col_Address.DefaultCellStyle = DataGridViewCellStyle3
        Me.col_Address.HeaderText = "Address"
        Me.col_Address.Name = "col_Address"
        Me.col_Address.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.col_Address.Width = 240
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.LightGray
        Me.TabPage5.Controls.Add(Me.TextBox13)
        Me.TabPage5.Controls.Add(Me.Panel69)
        Me.TabPage5.Location = New System.Drawing.Point(4, 24)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(632, 397)
        Me.TabPage5.TabIndex = 8
        Me.TabPage5.Text = "Chamber"
        '
        'TextBox13
        '
        Me.TextBox13.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox13.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox13.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox13.Location = New System.Drawing.Point(6, 8)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.ReadOnly = True
        Me.TextBox13.Size = New System.Drawing.Size(314, 21)
        Me.TextBox13.TabIndex = 3261
        Me.TextBox13.Text = "Chamber"
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel69
        '
        Me.Panel69.BackColor = System.Drawing.Color.LightGray
        Me.Panel69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel69.Controls.Add(Me.data_Temp)
        Me.Panel69.Controls.Add(Me.btn_temp_add)
        Me.Panel69.Controls.Add(Me.Label47)
        Me.Panel69.Controls.Add(Me.num_TA_delay)
        Me.Panel69.Controls.Add(Me.num_Temp_add)
        Me.Panel69.Controls.Add(Me.Label45)
        Me.Panel69.Controls.Add(Me.Label52)
        Me.Panel69.Controls.Add(Me.Label53)
        Me.Panel69.Location = New System.Drawing.Point(6, 27)
        Me.Panel69.Name = "Panel69"
        Me.Panel69.Size = New System.Drawing.Size(314, 128)
        Me.Panel69.TabIndex = 3082
        '
        'data_Temp
        '
        Me.data_Temp.AllowUserToAddRows = False
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.data_Temp.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.data_Temp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_Temp.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn4})
        Me.data_Temp.Location = New System.Drawing.Point(161, 7)
        Me.data_Temp.Name = "data_Temp"
        Me.data_Temp.RowTemplate.Height = 24
        Me.data_Temp.Size = New System.Drawing.Size(140, 106)
        Me.data_Temp.TabIndex = 3244
        '
        'DataGridViewTextBoxColumn4
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridViewTextBoxColumn4.HeaderText = "TA (℃)"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn4.Width = 80
        '
        'btn_temp_add
        '
        Me.btn_temp_add.BackgroundImage = CType(resources.GetObject("btn_temp_add.BackgroundImage"), System.Drawing.Image)
        Me.btn_temp_add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_temp_add.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_temp_add.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btn_temp_add.Image = CType(resources.GetObject("btn_temp_add.Image"), System.Drawing.Image)
        Me.btn_temp_add.Location = New System.Drawing.Point(118, 80)
        Me.btn_temp_add.Name = "btn_temp_add"
        Me.btn_temp_add.Size = New System.Drawing.Size(36, 33)
        Me.btn_temp_add.TabIndex = 3082
        Me.btn_temp_add.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_temp_add.UseVisualStyleBackColor = True
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(5, 45)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(41, 15)
        Me.Label47.TabIndex = 3023
        Me.Label47.Text = "Temp:"
        '
        'num_TA_delay
        '
        Me.num_TA_delay.Location = New System.Drawing.Point(52, 7)
        Me.num_TA_delay.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.num_TA_delay.Name = "num_TA_delay"
        Me.num_TA_delay.Size = New System.Drawing.Size(69, 21)
        Me.num_TA_delay.TabIndex = 3021
        Me.num_TA_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_TA_delay.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'num_Temp_add
        '
        Me.num_Temp_add.Location = New System.Drawing.Point(52, 43)
        Me.num_Temp_add.Maximum = New Decimal(New Integer() {200, 0, 0, 0})
        Me.num_Temp_add.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.num_Temp_add.Name = "num_Temp_add"
        Me.num_Temp_add.Size = New System.Drawing.Size(69, 21)
        Me.num_Temp_add.TabIndex = 2327
        Me.num_Temp_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(127, 9)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(27, 15)
        Me.Label45.TabIndex = 3020
        Me.Label45.Text = "sec"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(128, 45)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(19, 15)
        Me.Label52.TabIndex = 2328
        Me.Label52.Text = "℃"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(5, 9)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(41, 15)
        Me.Label53.TabIndex = 3022
        Me.Label53.Text = "Delay:"
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.LightGray
        Me.TabPage1.Controls.Add(Me.VIN2_check)
        Me.TabPage1.Controls.Add(Me.TextBox23)
        Me.TabPage1.Controls.Add(Me.Panel_vin2)
        Me.TabPage1.Controls.Add(Me.TextBox7)
        Me.TabPage1.Controls.Add(Me.Panel8)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(632, 397)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Power Supply"
        '
        'VIN2_check
        '
        Me.VIN2_check.AutoSize = True
        Me.VIN2_check.ForeColor = System.Drawing.Color.Black
        Me.VIN2_check.Location = New System.Drawing.Point(10, 8)
        Me.VIN2_check.Name = "VIN2_check"
        Me.VIN2_check.Size = New System.Drawing.Size(68, 19)
        Me.VIN2_check.TabIndex = 3226
        Me.VIN2_check.Text = "Power2"
        Me.VIN2_check.UseVisualStyleBackColor = True
        '
        'TextBox23
        '
        Me.TextBox23.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox23.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox23.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox23.Location = New System.Drawing.Point(9, 196)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.ReadOnly = True
        Me.TextBox23.Size = New System.Drawing.Size(293, 21)
        Me.TextBox23.TabIndex = 3225
        Me.TextBox23.Text = "Power2"
        Me.TextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel_vin2
        '
        Me.Panel_vin2.BackColor = System.Drawing.Color.LightGray
        Me.Panel_vin2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel_vin2.Controls.Add(Me.num_addr_VIN2)
        Me.Panel_vin2.Controls.Add(Me.cbox_VIN2)
        Me.Panel_vin2.Controls.Add(Me.Panel17)
        Me.Panel_vin2.Controls.Add(Me.Label26)
        Me.Panel_vin2.Controls.Add(Me.num_start_VIN2)
        Me.Panel_vin2.Controls.Add(Me.Label25)
        Me.Panel_vin2.Location = New System.Drawing.Point(9, 216)
        Me.Panel_vin2.Name = "Panel_vin2"
        Me.Panel_vin2.Size = New System.Drawing.Size(293, 98)
        Me.Panel_vin2.TabIndex = 3224
        '
        'num_addr_VIN2
        '
        Me.num_addr_VIN2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.num_addr_VIN2.Location = New System.Drawing.Point(208, 6)
        Me.num_addr_VIN2.Name = "num_addr_VIN2"
        Me.num_addr_VIN2.Size = New System.Drawing.Size(71, 21)
        Me.num_addr_VIN2.TabIndex = 3026
        Me.num_addr_VIN2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cbox_VIN2
        '
        Me.cbox_VIN2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbox_VIN2.FormattingEnabled = True
        Me.cbox_VIN2.Items.AddRange(New Object() {"OFF", "Agilent 3631A (6V)", "Agilent 3631A (25V)", "Agilent 3632A", "CHROMA 62006P-100-25"})
        Me.cbox_VIN2.Location = New System.Drawing.Point(6, 6)
        Me.cbox_VIN2.Name = "cbox_VIN2"
        Me.cbox_VIN2.Size = New System.Drawing.Size(196, 23)
        Me.cbox_VIN2.TabIndex = 1935
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.Label3)
        Me.Panel17.Controls.Add(Me.Label23)
        Me.Panel17.Controls.Add(Me.cbox_sense_VIN2)
        Me.Panel17.Controls.Add(Me.Label24)
        Me.Panel17.Controls.Add(Me.num_sense_VIN2)
        Me.Panel17.Location = New System.Drawing.Point(5, 32)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(268, 30)
        Me.Panel17.TabIndex = 3024
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(5, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 15)
        Me.Label3.TabIndex = 3025
        Me.Label3.Text = "Sense:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(251, 8)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(14, 15)
        Me.Label23.TabIndex = 3023
        Me.Label23.Text = "V"
        '
        'cbox_sense_VIN2
        '
        Me.cbox_sense_VIN2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbox_sense_VIN2.FormattingEnabled = True
        Me.cbox_sense_VIN2.Items.AddRange(New Object() {"OFF", "CH101", "CH102", "CH103", "CH104", "CH105", "CH106", "CH107", "CH108", "CH109", "CH110", "CH111", "CH112", "CH113", "CH114", "CH115", "CH116", "CH117", "CH118", "CH119", "CH120"})
        Me.cbox_sense_VIN2.Location = New System.Drawing.Point(52, 5)
        Me.cbox_sense_VIN2.Name = "cbox_sense_VIN2"
        Me.cbox_sense_VIN2.Size = New System.Drawing.Size(85, 23)
        Me.cbox_sense_VIN2.TabIndex = 1935
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(143, 10)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(18, 15)
        Me.Label24.TabIndex = 1940
        Me.Label24.Text = "+-"
        '
        'num_sense_VIN2
        '
        Me.num_sense_VIN2.DecimalPlaces = 3
        Me.num_sense_VIN2.Location = New System.Drawing.Point(166, 6)
        Me.num_sense_VIN2.Maximum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.num_sense_VIN2.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.num_sense_VIN2.Name = "num_sense_VIN2"
        Me.num_sense_VIN2.Size = New System.Drawing.Size(79, 21)
        Me.num_sense_VIN2.TabIndex = 1941
        Me.num_sense_VIN2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_sense_VIN2.Value = New Decimal(New Integer() {1, 0, 0, 131072})
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(235, 74)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(14, 15)
        Me.Label26.TabIndex = 1939
        Me.Label26.Text = "V"
        '
        'num_start_VIN2
        '
        Me.num_start_VIN2.DecimalPlaces = 3
        Me.num_start_VIN2.Location = New System.Drawing.Point(164, 70)
        Me.num_start_VIN2.Maximum = New Decimal(New Integer() {150, 0, 0, 0})
        Me.num_start_VIN2.Name = "num_start_VIN2"
        Me.num_start_VIN2.Size = New System.Drawing.Size(69, 21)
        Me.num_start_VIN2.TabIndex = 1938
        Me.num_start_VIN2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(128, 74)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(34, 15)
        Me.Label25.TabIndex = 1937
        Me.Label25.Text = "Vin2:"
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox7.Location = New System.Drawing.Point(9, 31)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(456, 21)
        Me.TextBox7.TabIndex = 3223
        Me.TextBox7.Text = "Power1"
        Me.TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.LightGray
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel8.Controls.Add(Me.num_VIN_OCP)
        Me.Panel8.Controls.Add(Me.Label100)
        Me.Panel8.Controls.Add(Me.num_start_VIN)
        Me.Panel8.Controls.Add(Me.btn_vin_add)
        Me.Panel8.Controls.Add(Me.Panel_sense)
        Me.Panel8.Controls.Add(Me.Label50)
        Me.Panel8.Controls.Add(Me.data_vin)
        Me.Panel8.Controls.Add(Me.Label51)
        Me.Panel8.Controls.Add(Me.cbox_VIN)
        Me.Panel8.Controls.Add(Me.num_addr_VIN)
        Me.Panel8.Location = New System.Drawing.Point(9, 50)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(456, 139)
        Me.Panel8.TabIndex = 3087
        '
        'num_VIN_OCP
        '
        Me.num_VIN_OCP.DecimalPlaces = 1
        Me.num_VIN_OCP.ForeColor = System.Drawing.Color.Black
        Me.num_VIN_OCP.Location = New System.Drawing.Point(56, 104)
        Me.num_VIN_OCP.Maximum = New Decimal(New Integer() {150, 0, 0, 0})
        Me.num_VIN_OCP.Name = "num_VIN_OCP"
        Me.num_VIN_OCP.Size = New System.Drawing.Size(58, 21)
        Me.num_VIN_OCP.TabIndex = 3257
        Me.num_VIN_OCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_VIN_OCP.Value = New Decimal(New Integer() {7, 0, 0, 0})
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.ForeColor = System.Drawing.Color.Black
        Me.Label100.Location = New System.Drawing.Point(3, 107)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(54, 15)
        Me.Label100.TabIndex = 3256
        Me.Label100.Text = "OCP (A):"
        '
        'num_start_VIN
        '
        Me.num_start_VIN.DecimalPlaces = 3
        Me.num_start_VIN.Location = New System.Drawing.Point(164, 104)
        Me.num_start_VIN.Maximum = New Decimal(New Integer() {150, 0, 0, 0})
        Me.num_start_VIN.Name = "num_start_VIN"
        Me.num_start_VIN.Size = New System.Drawing.Size(69, 21)
        Me.num_start_VIN.TabIndex = 1938
        Me.num_start_VIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_vin_add
        '
        Me.btn_vin_add.BackgroundImage = CType(resources.GetObject("btn_vin_add.BackgroundImage"), System.Drawing.Image)
        Me.btn_vin_add.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_vin_add.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btn_vin_add.Image = CType(resources.GetObject("btn_vin_add.Image"), System.Drawing.Image)
        Me.btn_vin_add.Location = New System.Drawing.Point(253, 96)
        Me.btn_vin_add.Name = "btn_vin_add"
        Me.btn_vin_add.Size = New System.Drawing.Size(46, 35)
        Me.btn_vin_add.TabIndex = 3244
        Me.btn_vin_add.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_vin_add.UseVisualStyleBackColor = True
        '
        'Panel_sense
        '
        Me.Panel_sense.Controls.Add(Me.Label36)
        Me.Panel_sense.Controls.Add(Me.Label60)
        Me.Panel_sense.Controls.Add(Me.cbox_sense_VIN)
        Me.Panel_sense.Controls.Add(Me.Label57)
        Me.Panel_sense.Controls.Add(Me.num_sense_VIN)
        Me.Panel_sense.Location = New System.Drawing.Point(4, 37)
        Me.Panel_sense.Name = "Panel_sense"
        Me.Panel_sense.Size = New System.Drawing.Size(268, 30)
        Me.Panel_sense.TabIndex = 3024
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(5, 9)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(46, 15)
        Me.Label36.TabIndex = 3024
        Me.Label36.Text = "Sense:"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(251, 7)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(14, 15)
        Me.Label60.TabIndex = 3023
        Me.Label60.Text = "V"
        '
        'cbox_sense_VIN
        '
        Me.cbox_sense_VIN.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbox_sense_VIN.FormattingEnabled = True
        Me.cbox_sense_VIN.Items.AddRange(New Object() {"OFF", "CH101", "CH102", "CH103", "CH104", "CH105", "CH106", "CH107", "CH108", "CH109", "CH110", "CH111", "CH112", "CH113", "CH114", "CH115", "CH116", "CH117", "CH118", "CH119", "CH120"})
        Me.cbox_sense_VIN.Location = New System.Drawing.Point(52, 4)
        Me.cbox_sense_VIN.Name = "cbox_sense_VIN"
        Me.cbox_sense_VIN.Size = New System.Drawing.Size(85, 23)
        Me.cbox_sense_VIN.TabIndex = 1935
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(143, 9)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(18, 15)
        Me.Label57.TabIndex = 1940
        Me.Label57.Text = "+-"
        '
        'num_sense_VIN
        '
        Me.num_sense_VIN.DecimalPlaces = 3
        Me.num_sense_VIN.Location = New System.Drawing.Point(166, 5)
        Me.num_sense_VIN.Maximum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.num_sense_VIN.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.num_sense_VIN.Name = "num_sense_VIN"
        Me.num_sense_VIN.Size = New System.Drawing.Size(79, 21)
        Me.num_sense_VIN.TabIndex = 1941
        Me.num_sense_VIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_sense_VIN.Value = New Decimal(New Integer() {1, 0, 0, 131072})
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(236, 108)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(14, 15)
        Me.Label50.TabIndex = 1939
        Me.Label50.Text = "V"
        '
        'data_vin
        '
        Me.data_vin.AllowUserToAddRows = False
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.data_vin.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.data_vin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_vin.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_VIN})
        Me.data_vin.Location = New System.Drawing.Point(305, 5)
        Me.data_vin.Name = "data_vin"
        Me.data_vin.RowTemplate.Height = 24
        Me.data_vin.Size = New System.Drawing.Size(140, 126)
        Me.data_vin.TabIndex = 3243
        '
        'col_VIN
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black
        Me.col_VIN.DefaultCellStyle = DataGridViewCellStyle7
        Me.col_VIN.HeaderText = "Vin1 (V)"
        Me.col_VIN.Name = "col_VIN"
        Me.col_VIN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.col_VIN.Width = 80
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(128, 107)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(34, 15)
        Me.Label51.TabIndex = 1937
        Me.Label51.Text = "Vin1:"
        '
        'cbox_VIN
        '
        Me.cbox_VIN.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbox_VIN.FormattingEnabled = True
        Me.cbox_VIN.Items.AddRange(New Object() {"OFF", "Agilent 3631A (6V)", "Agilent 3631A (25V)", "Agilent 3632A", "CHROMA 62006P-100-25"})
        Me.cbox_VIN.Location = New System.Drawing.Point(4, 7)
        Me.cbox_VIN.Name = "cbox_VIN"
        Me.cbox_VIN.Size = New System.Drawing.Size(196, 23)
        Me.cbox_VIN.TabIndex = 1935
        '
        'num_addr_VIN
        '
        Me.num_addr_VIN.BackColor = System.Drawing.Color.WhiteSmoke
        Me.num_addr_VIN.Location = New System.Drawing.Point(209, 7)
        Me.num_addr_VIN.Name = "num_addr_VIN"
        Me.num_addr_VIN.Size = New System.Drawing.Size(71, 21)
        Me.num_addr_VIN.TabIndex = 3026
        Me.num_addr_VIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.LightGray
        Me.TabPage3.Controls.Add(Me.TextBox8)
        Me.TabPage3.Controls.Add(Me.Panel13)
        Me.TabPage3.Location = New System.Drawing.Point(4, 24)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(632, 397)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Load"
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox8.Location = New System.Drawing.Point(9, 9)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.ReadOnly = True
        Me.TextBox8.Size = New System.Drawing.Size(284, 21)
        Me.TextBox8.TabIndex = 3224
        Me.TextBox8.Text = "DC Load"
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.LightGray
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel13.Controls.Add(Me.btn_iout_clear)
        Me.Panel13.Controls.Add(Me.cbox_iout_ch)
        Me.Panel13.Controls.Add(Me.num_step_iout)
        Me.Panel13.Controls.Add(Me.num_stop_iout)
        Me.Panel13.Controls.Add(Me.num_start_iout)
        Me.Panel13.Controls.Add(Me.btn_iout_add)
        Me.Panel13.Controls.Add(Me.Label64)
        Me.Panel13.Controls.Add(Me.Label67)
        Me.Panel13.Controls.Add(Me.Label63)
        Me.Panel13.Controls.Add(Me.data_iout)
        Me.Panel13.Controls.Add(Me.Label65)
        Me.Panel13.Controls.Add(Me.Label66)
        Me.Panel13.Controls.Add(Me.Label62)
        Me.Panel13.Location = New System.Drawing.Point(9, 29)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(284, 174)
        Me.Panel13.TabIndex = 3085
        '
        'btn_iout_clear
        '
        Me.btn_iout_clear.BackgroundImage = CType(resources.GetObject("btn_iout_clear.BackgroundImage"), System.Drawing.Image)
        Me.btn_iout_clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_iout_clear.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btn_iout_clear.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_iout_clear.Image = CType(resources.GetObject("btn_iout_clear.Image"), System.Drawing.Image)
        Me.btn_iout_clear.Location = New System.Drawing.Point(74, 122)
        Me.btn_iout_clear.Name = "btn_iout_clear"
        Me.btn_iout_clear.Size = New System.Drawing.Size(51, 35)
        Me.btn_iout_clear.TabIndex = 3091
        Me.btn_iout_clear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_iout_clear.UseVisualStyleBackColor = True
        '
        'cbox_iout_ch
        '
        Me.cbox_iout_ch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbox_iout_ch.FormattingEnabled = True
        Me.cbox_iout_ch.Items.AddRange(New Object() {"CH1", "CH2", "CH3", "CH4"})
        Me.cbox_iout_ch.Location = New System.Drawing.Point(13, 10)
        Me.cbox_iout_ch.Name = "cbox_iout_ch"
        Me.cbox_iout_ch.Size = New System.Drawing.Size(75, 23)
        Me.cbox_iout_ch.TabIndex = 3090
        '
        'num_step_iout
        '
        Me.num_step_iout.DecimalPlaces = 4
        Me.num_step_iout.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.num_step_iout.Location = New System.Drawing.Point(45, 90)
        Me.num_step_iout.Maximum = New Decimal(New Integer() {150, 0, 0, 0})
        Me.num_step_iout.Name = "num_step_iout"
        Me.num_step_iout.Size = New System.Drawing.Size(67, 21)
        Me.num_step_iout.TabIndex = 3086
        Me.num_step_iout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'num_stop_iout
        '
        Me.num_stop_iout.DecimalPlaces = 4
        Me.num_stop_iout.Location = New System.Drawing.Point(45, 66)
        Me.num_stop_iout.Maximum = New Decimal(New Integer() {150, 0, 0, 0})
        Me.num_stop_iout.Name = "num_stop_iout"
        Me.num_stop_iout.Size = New System.Drawing.Size(67, 21)
        Me.num_stop_iout.TabIndex = 3083
        Me.num_stop_iout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'num_start_iout
        '
        Me.num_start_iout.DecimalPlaces = 4
        Me.num_start_iout.Location = New System.Drawing.Point(45, 42)
        Me.num_start_iout.Maximum = New Decimal(New Integer() {150, 0, 0, 0})
        Me.num_start_iout.Name = "num_start_iout"
        Me.num_start_iout.Size = New System.Drawing.Size(67, 21)
        Me.num_start_iout.TabIndex = 3080
        Me.num_start_iout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_iout_add
        '
        Me.btn_iout_add.BackgroundImage = CType(resources.GetObject("btn_iout_add.BackgroundImage"), System.Drawing.Image)
        Me.btn_iout_add.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_iout_add.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btn_iout_add.Image = CType(resources.GetObject("btn_iout_add.Image"), System.Drawing.Image)
        Me.btn_iout_add.Location = New System.Drawing.Point(15, 122)
        Me.btn_iout_add.Name = "btn_iout_add"
        Me.btn_iout_add.Size = New System.Drawing.Size(52, 35)
        Me.btn_iout_add.TabIndex = 3089
        Me.btn_iout_add.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_iout_add.UseVisualStyleBackColor = True
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(111, 44)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(14, 15)
        Me.Label64.TabIndex = 3081
        Me.Label64.Text = "A"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(111, 67)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(14, 15)
        Me.Label67.TabIndex = 3084
        Me.Label67.Text = "A"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(111, 92)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(14, 15)
        Me.Label63.TabIndex = 3087
        Me.Label63.Text = "A"
        '
        'data_iout
        '
        Me.data_iout.AllowUserToAddRows = False
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.data_iout.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.data_iout.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_iout.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2})
        Me.data_iout.Location = New System.Drawing.Point(131, 10)
        Me.data_iout.Name = "data_iout"
        Me.data_iout.RowTemplate.Height = 24
        Me.data_iout.Size = New System.Drawing.Size(140, 147)
        Me.data_iout.TabIndex = 3088
        '
        'DataGridViewTextBoxColumn2
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle9
        Me.DataGridViewTextBoxColumn2.HeaderText = "IOUT (A)"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn2.Width = 80
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(9, 92)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(35, 15)
        Me.Label65.TabIndex = 3085
        Me.Label65.Text = "Step:"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(9, 68)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(35, 15)
        Me.Label66.TabIndex = 3082
        Me.Label66.Text = "Stop:"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(9, 46)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(35, 15)
        Me.Label62.TabIndex = 3079
        Me.Label62.Text = "Start:"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.LightGray
        Me.TabPage2.Controls.Add(Me.Panel_out_merte)
        Me.TabPage2.Controls.Add(Me.rbtn_iout_load)
        Me.TabPage2.Controls.Add(Me.rbtn_meter_iout)
        Me.TabPage2.Controls.Add(Me.Label102)
        Me.TabPage2.Controls.Add(Me.Panel9)
        Me.TabPage2.Controls.Add(Me.TextBox2)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.num_meter_count)
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(632, 397)
        Me.TabPage2.TabIndex = 7
        Me.TabPage2.Text = "Meter"
        '
        'Panel_out_merte
        '
        Me.Panel_out_merte.Controls.Add(Me.Panel2)
        Me.Panel_out_merte.Controls.Add(Me.TextBox12)
        Me.Panel_out_merte.Location = New System.Drawing.Point(11, 230)
        Me.Panel_out_merte.Name = "Panel_out_merte"
        Me.Panel_out_merte.Size = New System.Drawing.Size(336, 161)
        Me.Panel_out_merte.TabIndex = 3649
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightGray
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.num_slave_out_IO)
        Me.Panel2.Controls.Add(Me.TextBox22)
        Me.Panel2.Controls.Add(Me.num_resolution_out_H)
        Me.Panel2.Controls.Add(Me.num_resolution_out_M)
        Me.Panel2.Controls.Add(Me.num_resolution_out_L)
        Me.Panel2.Controls.Add(Me.num_comp_out_H)
        Me.Panel2.Controls.Add(Me.num_slave_out_H)
        Me.Panel2.Controls.Add(Me.num_comp_out_M)
        Me.Panel2.Controls.Add(Me.num_slave_out_M)
        Me.Panel2.Controls.Add(Me.num_comp_out_L)
        Me.Panel2.Controls.Add(Me.num_slave_out_L)
        Me.Panel2.Controls.Add(Me.TextBox3)
        Me.Panel2.Controls.Add(Me.TextBox4)
        Me.Panel2.Controls.Add(Me.TextBox5)
        Me.Panel2.Controls.Add(Me.TextBox6)
        Me.Panel2.Controls.Add(Me.TextBox9)
        Me.Panel2.Controls.Add(Me.TextBox11)
        Me.Panel2.Location = New System.Drawing.Point(3, 26)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(328, 132)
        Me.Panel2.TabIndex = 3644
        '
        'num_slave_out_IO
        '
        Me.num_slave_out_IO.Hexadecimal = True
        Me.num_slave_out_IO.Location = New System.Drawing.Point(81, 103)
        Me.num_slave_out_IO.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave_out_IO.Name = "num_slave_out_IO"
        Me.num_slave_out_IO.Size = New System.Drawing.Size(75, 21)
        Me.num_slave_out_IO.TabIndex = 3654
        Me.num_slave_out_IO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_slave_out_IO.Value = New Decimal(New Integer() {56, 0, 0, 0})
        '
        'TextBox22
        '
        Me.TextBox22.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox22.Location = New System.Drawing.Point(9, 103)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.ReadOnly = True
        Me.TextBox22.Size = New System.Drawing.Size(69, 21)
        Me.TextBox22.TabIndex = 3653
        Me.TextBox22.Text = "Expand I/O"
        Me.TextBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'num_resolution_out_H
        '
        Me.num_resolution_out_H.DecimalPlaces = 3
        Me.num_resolution_out_H.Location = New System.Drawing.Point(239, 78)
        Me.num_resolution_out_H.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.num_resolution_out_H.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.num_resolution_out_H.Name = "num_resolution_out_H"
        Me.num_resolution_out_H.Size = New System.Drawing.Size(77, 21)
        Me.num_resolution_out_H.TabIndex = 3651
        Me.num_resolution_out_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_resolution_out_H.Value = New Decimal(New Integer() {65, 0, 0, 131072})
        '
        'num_resolution_out_M
        '
        Me.num_resolution_out_M.DecimalPlaces = 3
        Me.num_resolution_out_M.Location = New System.Drawing.Point(239, 54)
        Me.num_resolution_out_M.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.num_resolution_out_M.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.num_resolution_out_M.Name = "num_resolution_out_M"
        Me.num_resolution_out_M.Size = New System.Drawing.Size(77, 21)
        Me.num_resolution_out_M.TabIndex = 3650
        Me.num_resolution_out_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_resolution_out_M.Value = New Decimal(New Integer() {35, 0, 0, 131072})
        '
        'num_resolution_out_L
        '
        Me.num_resolution_out_L.DecimalPlaces = 3
        Me.num_resolution_out_L.Location = New System.Drawing.Point(239, 30)
        Me.num_resolution_out_L.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.num_resolution_out_L.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.num_resolution_out_L.Name = "num_resolution_out_L"
        Me.num_resolution_out_L.Size = New System.Drawing.Size(77, 21)
        Me.num_resolution_out_L.TabIndex = 3649
        Me.num_resolution_out_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_resolution_out_L.Value = New Decimal(New Integer() {1, 0, 0, 131072})
        '
        'num_comp_out_H
        '
        Me.num_comp_out_H.Hexadecimal = True
        Me.num_comp_out_H.Location = New System.Drawing.Point(159, 78)
        Me.num_comp_out_H.Margin = New System.Windows.Forms.Padding(2)
        Me.num_comp_out_H.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.num_comp_out_H.Name = "num_comp_out_H"
        Me.num_comp_out_H.Size = New System.Drawing.Size(77, 21)
        Me.num_comp_out_H.TabIndex = 3648
        Me.num_comp_out_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_comp_out_H.Value = New Decimal(New Integer() {1930, 0, 0, 0})
        '
        'num_slave_out_H
        '
        Me.num_slave_out_H.Hexadecimal = True
        Me.num_slave_out_H.Location = New System.Drawing.Point(81, 78)
        Me.num_slave_out_H.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave_out_H.Name = "num_slave_out_H"
        Me.num_slave_out_H.Size = New System.Drawing.Size(75, 21)
        Me.num_slave_out_H.TabIndex = 3647
        Me.num_slave_out_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_slave_out_H.Value = New Decimal(New Integer() {79, 0, 0, 0})
        '
        'num_comp_out_M
        '
        Me.num_comp_out_M.Hexadecimal = True
        Me.num_comp_out_M.Location = New System.Drawing.Point(159, 54)
        Me.num_comp_out_M.Margin = New System.Windows.Forms.Padding(2)
        Me.num_comp_out_M.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.num_comp_out_M.Name = "num_comp_out_M"
        Me.num_comp_out_M.Size = New System.Drawing.Size(77, 21)
        Me.num_comp_out_M.TabIndex = 3646
        Me.num_comp_out_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_comp_out_M.Value = New Decimal(New Integer() {1840, 0, 0, 0})
        '
        'num_slave_out_M
        '
        Me.num_slave_out_M.Hexadecimal = True
        Me.num_slave_out_M.Location = New System.Drawing.Point(81, 54)
        Me.num_slave_out_M.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave_out_M.Name = "num_slave_out_M"
        Me.num_slave_out_M.Size = New System.Drawing.Size(75, 21)
        Me.num_slave_out_M.TabIndex = 3645
        Me.num_slave_out_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_slave_out_M.Value = New Decimal(New Integer() {78, 0, 0, 0})
        '
        'num_comp_out_L
        '
        Me.num_comp_out_L.Hexadecimal = True
        Me.num_comp_out_L.Location = New System.Drawing.Point(159, 30)
        Me.num_comp_out_L.Margin = New System.Windows.Forms.Padding(2)
        Me.num_comp_out_L.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.num_comp_out_L.Name = "num_comp_out_L"
        Me.num_comp_out_L.Size = New System.Drawing.Size(77, 21)
        Me.num_comp_out_L.TabIndex = 3644
        Me.num_comp_out_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_comp_out_L.Value = New Decimal(New Integer() {1280, 0, 0, 0})
        '
        'num_slave_out_L
        '
        Me.num_slave_out_L.Hexadecimal = True
        Me.num_slave_out_L.Location = New System.Drawing.Point(81, 30)
        Me.num_slave_out_L.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave_out_L.Name = "num_slave_out_L"
        Me.num_slave_out_L.Size = New System.Drawing.Size(75, 21)
        Me.num_slave_out_L.TabIndex = 3643
        Me.num_slave_out_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_slave_out_L.Value = New Decimal(New Integer() {77, 0, 0, 0})
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox3.Location = New System.Drawing.Point(9, 78)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(69, 21)
        Me.TextBox3.TabIndex = 3641
        Me.TextBox3.Text = "High"
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.Color.Gray
        Me.TextBox4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox4.Location = New System.Drawing.Point(81, 6)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(75, 21)
        Me.TextBox4.TabIndex = 3625
        Me.TextBox4.Text = "Slave(Hex)"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox5.Location = New System.Drawing.Point(9, 30)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(69, 21)
        Me.TextBox5.TabIndex = 3626
        Me.TextBox5.Text = "Low"
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.Color.Gray
        Me.TextBox6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox6.Location = New System.Drawing.Point(239, 6)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(77, 21)
        Me.TextBox6.TabIndex = 3627
        Me.TextBox6.Text = "Resolution"
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.Gray
        Me.TextBox9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox9.Location = New System.Drawing.Point(159, 6)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ReadOnly = True
        Me.TextBox9.Size = New System.Drawing.Size(77, 21)
        Me.TextBox9.TabIndex = 3638
        Me.TextBox9.Text = "Comp.(Hex)"
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox11.Location = New System.Drawing.Point(9, 54)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.ReadOnly = True
        Me.TextBox11.Size = New System.Drawing.Size(69, 21)
        Me.TextBox11.TabIndex = 3633
        Me.TextBox11.Text = "Middle"
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox12
        '
        Me.TextBox12.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox12.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox12.Location = New System.Drawing.Point(3, 6)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.ReadOnly = True
        Me.TextBox12.Size = New System.Drawing.Size(328, 21)
        Me.TextBox12.TabIndex = 3643
        Me.TextBox12.Text = "Output Meter"
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'rbtn_iout_load
        '
        Me.rbtn_iout_load.AutoSize = True
        Me.rbtn_iout_load.Location = New System.Drawing.Point(129, 206)
        Me.rbtn_iout_load.Name = "rbtn_iout_load"
        Me.rbtn_iout_load.Size = New System.Drawing.Size(74, 19)
        Me.rbtn_iout_load.TabIndex = 3648
        Me.rbtn_iout_load.TabStop = True
        Me.rbtn_iout_load.Text = "DC Load"
        Me.rbtn_iout_load.UseVisualStyleBackColor = True
        '
        'rbtn_meter_iout
        '
        Me.rbtn_meter_iout.AutoSize = True
        Me.rbtn_meter_iout.Location = New System.Drawing.Point(129, 186)
        Me.rbtn_meter_iout.Name = "rbtn_meter_iout"
        Me.rbtn_meter_iout.Size = New System.Drawing.Size(55, 19)
        Me.rbtn_meter_iout.TabIndex = 3647
        Me.rbtn_meter_iout.TabStop = True
        Me.rbtn_meter_iout.Text = "Meter"
        Me.rbtn_meter_iout.UseVisualStyleBackColor = True
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.ForeColor = System.Drawing.Color.Black
        Me.Label102.Location = New System.Drawing.Point(14, 188)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(109, 15)
        Me.Label102.TabIndex = 3260
        Me.Label102.Text = "Iout Measurement:"
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.LightGray
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel9.Controls.Add(Me.num_slave_in_IO)
        Me.Panel9.Controls.Add(Me.TextBox21)
        Me.Panel9.Controls.Add(Me.num_resolution_in_H)
        Me.Panel9.Controls.Add(Me.num_resolution_in_M)
        Me.Panel9.Controls.Add(Me.num_comp_in_H)
        Me.Panel9.Controls.Add(Me.num_slave_in_H)
        Me.Panel9.Controls.Add(Me.num_comp_in_M)
        Me.Panel9.Controls.Add(Me.num_slave_in_M)
        Me.Panel9.Controls.Add(Me.num_comp_in_L)
        Me.Panel9.Controls.Add(Me.num_slave_in_L)
        Me.Panel9.Controls.Add(Me.TextBox15)
        Me.Panel9.Controls.Add(Me.TextBox55)
        Me.Panel9.Controls.Add(Me.TextBox54)
        Me.Panel9.Controls.Add(Me.num_resolution_in_L)
        Me.Panel9.Controls.Add(Me.TextBox50)
        Me.Panel9.Controls.Add(Me.TextBox57)
        Me.Panel9.Controls.Add(Me.TextBox10)
        Me.Panel9.Location = New System.Drawing.Point(11, 50)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(328, 131)
        Me.Panel9.TabIndex = 3642
        '
        'num_slave_in_IO
        '
        Me.num_slave_in_IO.Hexadecimal = True
        Me.num_slave_in_IO.Location = New System.Drawing.Point(81, 102)
        Me.num_slave_in_IO.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave_in_IO.Name = "num_slave_in_IO"
        Me.num_slave_in_IO.Size = New System.Drawing.Size(75, 21)
        Me.num_slave_in_IO.TabIndex = 3652
        Me.num_slave_in_IO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_slave_in_IO.Value = New Decimal(New Integer() {63, 0, 0, 0})
        '
        'TextBox21
        '
        Me.TextBox21.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox21.Location = New System.Drawing.Point(9, 102)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.ReadOnly = True
        Me.TextBox21.Size = New System.Drawing.Size(69, 21)
        Me.TextBox21.TabIndex = 3651
        Me.TextBox21.Text = "Expand I/O"
        Me.TextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'num_resolution_in_H
        '
        Me.num_resolution_in_H.DecimalPlaces = 3
        Me.num_resolution_in_H.Location = New System.Drawing.Point(239, 78)
        Me.num_resolution_in_H.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.num_resolution_in_H.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.num_resolution_in_H.Name = "num_resolution_in_H"
        Me.num_resolution_in_H.Size = New System.Drawing.Size(77, 21)
        Me.num_resolution_in_H.TabIndex = 3650
        Me.num_resolution_in_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_resolution_in_H.Value = New Decimal(New Integer() {65, 0, 0, 131072})
        '
        'num_resolution_in_M
        '
        Me.num_resolution_in_M.DecimalPlaces = 3
        Me.num_resolution_in_M.Location = New System.Drawing.Point(239, 54)
        Me.num_resolution_in_M.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.num_resolution_in_M.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.num_resolution_in_M.Name = "num_resolution_in_M"
        Me.num_resolution_in_M.Size = New System.Drawing.Size(77, 21)
        Me.num_resolution_in_M.TabIndex = 3649
        Me.num_resolution_in_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_resolution_in_M.Value = New Decimal(New Integer() {35, 0, 0, 131072})
        '
        'num_comp_in_H
        '
        Me.num_comp_in_H.Hexadecimal = True
        Me.num_comp_in_H.Location = New System.Drawing.Point(159, 78)
        Me.num_comp_in_H.Margin = New System.Windows.Forms.Padding(2)
        Me.num_comp_in_H.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.num_comp_in_H.Name = "num_comp_in_H"
        Me.num_comp_in_H.Size = New System.Drawing.Size(77, 21)
        Me.num_comp_in_H.TabIndex = 3648
        Me.num_comp_in_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_comp_in_H.Value = New Decimal(New Integer() {1930, 0, 0, 0})
        '
        'num_slave_in_H
        '
        Me.num_slave_in_H.Hexadecimal = True
        Me.num_slave_in_H.Location = New System.Drawing.Point(81, 78)
        Me.num_slave_in_H.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave_in_H.Name = "num_slave_in_H"
        Me.num_slave_in_H.Size = New System.Drawing.Size(75, 21)
        Me.num_slave_in_H.TabIndex = 3647
        Me.num_slave_in_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_slave_in_H.Value = New Decimal(New Integer() {66, 0, 0, 0})
        '
        'num_comp_in_M
        '
        Me.num_comp_in_M.Hexadecimal = True
        Me.num_comp_in_M.Location = New System.Drawing.Point(159, 54)
        Me.num_comp_in_M.Margin = New System.Windows.Forms.Padding(2)
        Me.num_comp_in_M.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.num_comp_in_M.Name = "num_comp_in_M"
        Me.num_comp_in_M.Size = New System.Drawing.Size(77, 21)
        Me.num_comp_in_M.TabIndex = 3646
        Me.num_comp_in_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_comp_in_M.Value = New Decimal(New Integer() {1840, 0, 0, 0})
        '
        'num_slave_in_M
        '
        Me.num_slave_in_M.Hexadecimal = True
        Me.num_slave_in_M.Location = New System.Drawing.Point(81, 54)
        Me.num_slave_in_M.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave_in_M.Name = "num_slave_in_M"
        Me.num_slave_in_M.Size = New System.Drawing.Size(75, 21)
        Me.num_slave_in_M.TabIndex = 3645
        Me.num_slave_in_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_slave_in_M.Value = New Decimal(New Integer() {65, 0, 0, 0})
        '
        'num_comp_in_L
        '
        Me.num_comp_in_L.Hexadecimal = True
        Me.num_comp_in_L.Location = New System.Drawing.Point(159, 30)
        Me.num_comp_in_L.Margin = New System.Windows.Forms.Padding(2)
        Me.num_comp_in_L.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.num_comp_in_L.Name = "num_comp_in_L"
        Me.num_comp_in_L.Size = New System.Drawing.Size(77, 21)
        Me.num_comp_in_L.TabIndex = 3644
        Me.num_comp_in_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_comp_in_L.Value = New Decimal(New Integer() {1280, 0, 0, 0})
        '
        'num_slave_in_L
        '
        Me.num_slave_in_L.Hexadecimal = True
        Me.num_slave_in_L.Location = New System.Drawing.Point(81, 30)
        Me.num_slave_in_L.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave_in_L.Name = "num_slave_in_L"
        Me.num_slave_in_L.Size = New System.Drawing.Size(75, 21)
        Me.num_slave_in_L.TabIndex = 3643
        Me.num_slave_in_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_slave_in_L.Value = New Decimal(New Integer() {64, 0, 0, 0})
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox15.Location = New System.Drawing.Point(9, 78)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.ReadOnly = True
        Me.TextBox15.Size = New System.Drawing.Size(69, 21)
        Me.TextBox15.TabIndex = 3641
        Me.TextBox15.Text = "High"
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox55
        '
        Me.TextBox55.BackColor = System.Drawing.Color.Gray
        Me.TextBox55.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox55.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox55.Location = New System.Drawing.Point(81, 6)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.ReadOnly = True
        Me.TextBox55.Size = New System.Drawing.Size(75, 21)
        Me.TextBox55.TabIndex = 3625
        Me.TextBox55.Text = "Slave(Hex)"
        Me.TextBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox54
        '
        Me.TextBox54.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox54.Location = New System.Drawing.Point(9, 30)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.ReadOnly = True
        Me.TextBox54.Size = New System.Drawing.Size(69, 21)
        Me.TextBox54.TabIndex = 3626
        Me.TextBox54.Text = "Low"
        Me.TextBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'num_resolution_in_L
        '
        Me.num_resolution_in_L.DecimalPlaces = 3
        Me.num_resolution_in_L.Location = New System.Drawing.Point(240, 30)
        Me.num_resolution_in_L.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.num_resolution_in_L.Minimum = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.num_resolution_in_L.Name = "num_resolution_in_L"
        Me.num_resolution_in_L.Size = New System.Drawing.Size(77, 21)
        Me.num_resolution_in_L.TabIndex = 3629
        Me.num_resolution_in_L.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_resolution_in_L.Value = New Decimal(New Integer() {1, 0, 0, 131072})
        '
        'TextBox50
        '
        Me.TextBox50.BackColor = System.Drawing.Color.Gray
        Me.TextBox50.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox50.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox50.Location = New System.Drawing.Point(239, 6)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.ReadOnly = True
        Me.TextBox50.Size = New System.Drawing.Size(77, 21)
        Me.TextBox50.TabIndex = 3627
        Me.TextBox50.Text = "Resolution"
        Me.TextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox57
        '
        Me.TextBox57.BackColor = System.Drawing.Color.Gray
        Me.TextBox57.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox57.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox57.Location = New System.Drawing.Point(159, 6)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.ReadOnly = True
        Me.TextBox57.Size = New System.Drawing.Size(77, 21)
        Me.TextBox57.TabIndex = 3638
        Me.TextBox57.Text = "Comp.(Hex)"
        Me.TextBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox10
        '
        Me.TextBox10.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox10.Location = New System.Drawing.Point(9, 54)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.ReadOnly = True
        Me.TextBox10.Size = New System.Drawing.Size(69, 21)
        Me.TextBox10.TabIndex = 3633
        Me.TextBox10.Text = "Middle"
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox2.Location = New System.Drawing.Point(11, 30)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(328, 21)
        Me.TextBox2.TabIndex = 3262
        Me.TextBox2.Text = "Input Meter"
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(11, 8)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(126, 15)
        Me.Label5.TabIndex = 3250
        Me.Label5.Text = "Numbers of Measure:"
        '
        'num_meter_count
        '
        Me.num_meter_count.Location = New System.Drawing.Point(143, 5)
        Me.num_meter_count.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.num_meter_count.Name = "num_meter_count"
        Me.num_meter_count.Size = New System.Drawing.Size(64, 21)
        Me.num_meter_count.TabIndex = 3249
        Me.num_meter_count.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_meter_count.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.LightGray
        Me.TabPage7.Controls.Add(Me.TextBox20)
        Me.TabPage7.Controls.Add(Me.Panel15)
        Me.TabPage7.Location = New System.Drawing.Point(4, 24)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(632, 397)
        Me.TabPage7.TabIndex = 10
        Me.TabPage7.Text = "I2C Initial/Setting"
        '
        'TextBox20
        '
        Me.TextBox20.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox20.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox20.Location = New System.Drawing.Point(6, 7)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.ReadOnly = True
        Me.TextBox20.Size = New System.Drawing.Size(467, 21)
        Me.TextBox20.TabIndex = 3263
        Me.TextBox20.Text = "I2C Initial"
        Me.TextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.LightGray
        Me.Panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel15.Controls.Add(Me.num_test_slave_w)
        Me.Panel15.Controls.Add(Me.Label56)
        Me.Panel15.Controls.Add(Me.num_test_data)
        Me.Panel15.Controls.Add(Me.btn_add_w)
        Me.Panel15.Controls.Add(Me.Label78)
        Me.Panel15.Controls.Add(Me.data_i2c_write)
        Me.Panel15.Controls.Add(Me.Label69)
        Me.Panel15.Controls.Add(Me.num_test_addr_w)
        Me.Panel15.Location = New System.Drawing.Point(6, 27)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(467, 168)
        Me.Panel15.TabIndex = 3086
        '
        'num_test_slave_w
        '
        Me.num_test_slave_w.Hexadecimal = True
        Me.num_test_slave_w.Location = New System.Drawing.Point(68, 15)
        Me.num_test_slave_w.Margin = New System.Windows.Forms.Padding(2)
        Me.num_test_slave_w.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_test_slave_w.Name = "num_test_slave_w"
        Me.num_test_slave_w.Size = New System.Drawing.Size(66, 21)
        Me.num_test_slave_w.TabIndex = 2348
        Me.num_test_slave_w.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(11, 17)
        Me.Label56.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(53, 15)
        Me.Label56.TabIndex = 2347
        Me.Label56.Text = "Addr:  0x"
        '
        'num_test_data
        '
        Me.num_test_data.Hexadecimal = True
        Me.num_test_data.Location = New System.Drawing.Point(68, 72)
        Me.num_test_data.Margin = New System.Windows.Forms.Padding(2)
        Me.num_test_data.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_test_data.Name = "num_test_data"
        Me.num_test_data.Size = New System.Drawing.Size(66, 21)
        Me.num_test_data.TabIndex = 2344
        Me.num_test_data.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_add_w
        '
        Me.btn_add_w.BackgroundImage = CType(resources.GetObject("btn_add_w.BackgroundImage"), System.Drawing.Image)
        Me.btn_add_w.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_add_w.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btn_add_w.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_add_w.Image = CType(resources.GetObject("btn_add_w.Image"), System.Drawing.Image)
        Me.btn_add_w.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btn_add_w.Location = New System.Drawing.Point(40, 108)
        Me.btn_add_w.Margin = New System.Windows.Forms.Padding(2)
        Me.btn_add_w.Name = "btn_add_w"
        Me.btn_add_w.Size = New System.Drawing.Size(94, 40)
        Me.btn_add_w.TabIndex = 2346
        Me.btn_add_w.Text = "Add"
        Me.btn_add_w.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_add_w.UseVisualStyleBackColor = True
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(11, 45)
        Me.Label78.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(52, 15)
        Me.Label78.TabIndex = 2343
        Me.Label78.Text = "Cmd: 0x"
        '
        'data_i2c_write
        '
        Me.data_i2c_write.AllowUserToAddRows = False
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.data_i2c_write.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle10
        Me.data_i2c_write.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.data_i2c_write.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.data_i2c_write.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_i2c_write.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column7, Me.DataGridViewTextBoxColumn1, Me.col_data_w})
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle13.NullValue = Nothing
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.data_i2c_write.DefaultCellStyle = DataGridViewCellStyle13
        Me.data_i2c_write.Location = New System.Drawing.Point(147, 10)
        Me.data_i2c_write.Margin = New System.Windows.Forms.Padding(2)
        Me.data_i2c_write.Name = "data_i2c_write"
        Me.data_i2c_write.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.data_i2c_write.RowTemplate.Height = 24
        Me.data_i2c_write.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.data_i2c_write.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.data_i2c_write.Size = New System.Drawing.Size(301, 138)
        Me.data_i2c_write.TabIndex = 2341
        '
        'Column7
        '
        Me.Column7.HeaderText = "Addr(Hex)"
        Me.Column7.Name = "Column7"
        Me.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column7.Width = 80
        '
        'DataGridViewTextBoxColumn1
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle12.NullValue = Nothing
        Me.DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle12
        Me.DataGridViewTextBoxColumn1.HeaderText = "Cmd(Hex)"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn1.Width = 80
        '
        'col_data_w
        '
        Me.col_data_w.HeaderText = "Data(Hex) "
        Me.col_data_w.Name = "col_data_w"
        Me.col_data_w.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.col_data_w.Width = 80
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(11, 73)
        Me.Label69.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(51, 15)
        Me.Label69.TabIndex = 2345
        Me.Label69.Text = "Data: 0x"
        '
        'num_test_addr_w
        '
        Me.num_test_addr_w.Hexadecimal = True
        Me.num_test_addr_w.Location = New System.Drawing.Point(68, 43)
        Me.num_test_addr_w.Margin = New System.Windows.Forms.Padding(2)
        Me.num_test_addr_w.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_test_addr_w.Name = "num_test_addr_w"
        Me.num_test_addr_w.Size = New System.Drawing.Size(66, 21)
        Me.num_test_addr_w.TabIndex = 2342
        Me.num_test_addr_w.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.LightGray
        Me.TabPage6.Controls.Add(Me.btn_add)
        Me.TabPage6.Controls.Add(Me.TextBox19)
        Me.TabPage6.Controls.Add(Me.Panel14)
        Me.TabPage6.Controls.Add(Me.TextBox1)
        Me.TabPage6.Controls.Add(Me.Panel1)
        Me.TabPage6.Location = New System.Drawing.Point(4, 24)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(632, 397)
        Me.TabPage6.TabIndex = 9
        Me.TabPage6.Text = "Vout Setting"
        '
        'btn_add
        '
        Me.btn_add.BackgroundImage = CType(resources.GetObject("btn_add.BackgroundImage"), System.Drawing.Image)
        Me.btn_add.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_add.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btn_add.Image = CType(resources.GetObject("btn_add.Image"), System.Drawing.Image)
        Me.btn_add.Location = New System.Drawing.Point(468, 172)
        Me.btn_add.Name = "btn_add"
        Me.btn_add.Size = New System.Drawing.Size(74, 35)
        Me.btn_add.TabIndex = 3263
        Me.btn_add.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_add.UseVisualStyleBackColor = True
        '
        'TextBox19
        '
        Me.TextBox19.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox19.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox19.Location = New System.Drawing.Point(6, 6)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.ReadOnly = True
        Me.TextBox19.Size = New System.Drawing.Size(456, 21)
        Me.TextBox19.TabIndex = 3262
        Me.TextBox19.Text = "Vout Setting"
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.LightGray
        Me.Panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel14.Controls.Add(Me.panel_vout_i2c)
        Me.Panel14.Location = New System.Drawing.Point(6, 25)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(456, 187)
        Me.Panel14.TabIndex = 3086
        '
        'panel_vout_i2c
        '
        Me.panel_vout_i2c.Controls.Add(Me.Panel_multivout)
        Me.panel_vout_i2c.Controls.Add(Me.data_i2c_vout)
        Me.panel_vout_i2c.Controls.Add(Me.TextBox17)
        Me.panel_vout_i2c.Controls.Add(Me.txt_vout_volt)
        Me.panel_vout_i2c.Controls.Add(Me.btn_vout_set)
        Me.panel_vout_i2c.Controls.Add(Me.TextBox18)
        Me.panel_vout_i2c.Location = New System.Drawing.Point(3, 2)
        Me.panel_vout_i2c.Name = "panel_vout_i2c"
        Me.panel_vout_i2c.Size = New System.Drawing.Size(448, 179)
        Me.panel_vout_i2c.TabIndex = 3137
        '
        'Panel_multivout
        '
        Me.Panel_multivout.Controls.Add(Me.TextBox14)
        Me.Panel_multivout.Controls.Add(Me.TextBox16)
        Me.Panel_multivout.Controls.Add(Me.Lab_note)
        Me.Panel_multivout.Controls.Add(Me.num_slave)
        Me.Panel_multivout.Controls.Add(Me.txt_i2c)
        Me.Panel_multivout.Location = New System.Drawing.Point(153, 5)
        Me.Panel_multivout.Name = "Panel_multivout"
        Me.Panel_multivout.Size = New System.Drawing.Size(250, 80)
        Me.Panel_multivout.TabIndex = 3158
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.Color.Gray
        Me.TextBox14.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox14.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox14.Location = New System.Drawing.Point(3, 11)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.ReadOnly = True
        Me.TextBox14.Size = New System.Drawing.Size(76, 21)
        Me.TextBox14.TabIndex = 3600
        Me.TextBox14.Text = "Addr (Hex)"
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox16
        '
        Me.TextBox16.BackColor = System.Drawing.Color.Gray
        Me.TextBox16.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox16.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox16.Location = New System.Drawing.Point(83, 11)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.ReadOnly = True
        Me.TextBox16.Size = New System.Drawing.Size(159, 21)
        Me.TextBox16.TabIndex = 3595
        Me.TextBox16.Text = "Cmd & Data (Hex)"
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Lab_note
        '
        Me.Lab_note.AutoSize = True
        Me.Lab_note.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_note.Location = New System.Drawing.Point(80, 58)
        Me.Lab_note.Name = "Lab_note"
        Me.Lab_note.Size = New System.Drawing.Size(126, 15)
        Me.Lab_note.TabIndex = 3602
        Me.Lab_note.Text = "Note. 00[00],00[00] ..." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'num_slave
        '
        Me.num_slave.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.num_slave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.num_slave.Hexadecimal = True
        Me.num_slave.Location = New System.Drawing.Point(4, 34)
        Me.num_slave.Margin = New System.Windows.Forms.Padding(2)
        Me.num_slave.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.num_slave.Name = "num_slave"
        Me.num_slave.Size = New System.Drawing.Size(75, 21)
        Me.num_slave.TabIndex = 3599
        Me.num_slave.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_i2c
        '
        Me.txt_i2c.Location = New System.Drawing.Point(83, 34)
        Me.txt_i2c.Name = "txt_i2c"
        Me.txt_i2c.Size = New System.Drawing.Size(159, 21)
        Me.txt_i2c.TabIndex = 3601
        Me.txt_i2c.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'data_i2c_vout
        '
        Me.data_i2c_vout.AllowUserToAddRows = False
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.data_i2c_vout.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle14
        Me.data_i2c_vout.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.data_i2c_vout.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.data_i2c_vout.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_i2c_vout.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn21})
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle16.NullValue = Nothing
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.data_i2c_vout.DefaultCellStyle = DataGridViewCellStyle16
        Me.data_i2c_vout.Location = New System.Drawing.Point(7, 88)
        Me.data_i2c_vout.Margin = New System.Windows.Forms.Padding(2)
        Me.data_i2c_vout.Name = "data_i2c_vout"
        Me.data_i2c_vout.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.data_i2c_vout.RowTemplate.Height = 24
        Me.data_i2c_vout.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.data_i2c_vout.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.data_i2c_vout.Size = New System.Drawing.Size(382, 85)
        Me.data_i2c_vout.TabIndex = 3604
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.HeaderText = "Vout(V)"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn21.Width = 80
        '
        'TextBox17
        '
        Me.TextBox17.BackColor = System.Drawing.Color.Gray
        Me.TextBox17.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox17.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox17.Location = New System.Drawing.Point(78, 16)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.ReadOnly = True
        Me.TextBox17.Size = New System.Drawing.Size(73, 21)
        Me.TextBox17.TabIndex = 3592
        Me.TextBox17.Text = "VOLT (V)"
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_vout_volt
        '
        Me.txt_vout_volt.Location = New System.Drawing.Point(78, 39)
        Me.txt_vout_volt.Name = "txt_vout_volt"
        Me.txt_vout_volt.Size = New System.Drawing.Size(73, 21)
        Me.txt_vout_volt.TabIndex = 3074
        Me.txt_vout_volt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_vout_set
        '
        Me.btn_vout_set.BackgroundImage = CType(resources.GetObject("btn_vout_set.BackgroundImage"), System.Drawing.Image)
        Me.btn_vout_set.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_vout_set.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_vout_set.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btn_vout_set.Image = CType(resources.GetObject("btn_vout_set.Image"), System.Drawing.Image)
        Me.btn_vout_set.Location = New System.Drawing.Point(404, 29)
        Me.btn_vout_set.Name = "btn_vout_set"
        Me.btn_vout_set.Size = New System.Drawing.Size(36, 33)
        Me.btn_vout_set.TabIndex = 3081
        Me.btn_vout_set.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_vout_set.UseVisualStyleBackColor = True
        '
        'TextBox18
        '
        Me.TextBox18.BackColor = System.Drawing.Color.LightYellow
        Me.TextBox18.Location = New System.Drawing.Point(5, 39)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.ReadOnly = True
        Me.TextBox18.Size = New System.Drawing.Size(69, 21)
        Me.TextBox18.TabIndex = 3593
        Me.TextBox18.Text = "VOUT"
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.SteelBlue
        Me.TextBox1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox1.Location = New System.Drawing.Point(6, 218)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(162, 21)
        Me.TextBox1.TabIndex = 3260
        Me.TextBox1.Text = "Data Acquisition"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightGray
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.cbox_daq_vout)
        Me.Panel1.Location = New System.Drawing.Point(6, 238)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(162, 47)
        Me.Panel1.TabIndex = 3261
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 15)
        Me.Label1.TabIndex = 3253
        Me.Label1.Text = "VOUT:"
        '
        'cbox_daq_vout
        '
        Me.cbox_daq_vout.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbox_daq_vout.FormattingEnabled = True
        Me.cbox_daq_vout.Items.AddRange(New Object() {"OFF", "CH101", "CH102", "CH103", "CH104", "CH105", "CH106", "CH107", "CH108", "CH109", "CH110", "CH111", "CH112", "CH113", "CH114", "CH115", "CH116", "CH117", "CH118", "CH119", "CH120"})
        Me.cbox_daq_vout.Location = New System.Drawing.Point(61, 10)
        Me.cbox_daq_vout.Name = "cbox_daq_vout"
        Me.cbox_daq_vout.Size = New System.Drawing.Size(85, 23)
        Me.cbox_daq_vout.TabIndex = 3252
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.LightGray
        Me.TabPage8.Controls.Add(Me.data_I2C)
        Me.TabPage8.Controls.Add(Me.data_I2C_multi)
        Me.TabPage8.Controls.Add(Me.btn_vout_Clear)
        Me.TabPage8.Location = New System.Drawing.Point(4, 24)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(632, 397)
        Me.TabPage8.TabIndex = 11
        Me.TabPage8.Text = "Summary"
        '
        'data_I2C
        '
        Me.data_I2C.AllowUserToAddRows = False
        Me.data_I2C.AllowUserToDeleteRows = False
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.data_I2C.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle17
        Me.data_I2C.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_I2C.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18})
        Me.data_I2C.Location = New System.Drawing.Point(6, 9)
        Me.data_I2C.Name = "data_I2C"
        Me.data_I2C.ReadOnly = True
        Me.data_I2C.RowTemplate.Height = 24
        Me.data_I2C.Size = New System.Drawing.Size(615, 328)
        Me.data_I2C.TabIndex = 3164
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "Temp.(℃)"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn14.Width = 70
        '
        'DataGridViewTextBoxColumn15
        '
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn15.DefaultCellStyle = DataGridViewCellStyle18
        Me.DataGridViewTextBoxColumn15.HeaderText = "Vout(V)"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn15.Width = 70
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "Vin1(V)"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn16.Width = 70
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Vin2(V)"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 70
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "DC Load(A)"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        Me.DataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn18.Width = 80
        '
        'data_I2C_multi
        '
        Me.data_I2C_multi.AllowUserToAddRows = False
        Me.data_I2C_multi.AllowUserToDeleteRows = False
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle19.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.data_I2C_multi.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle19
        Me.data_I2C_multi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.data_I2C_multi.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.col_vin2, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13})
        Me.data_I2C_multi.Location = New System.Drawing.Point(6, 9)
        Me.data_I2C_multi.Name = "data_I2C_multi"
        Me.data_I2C_multi.ReadOnly = True
        Me.data_I2C_multi.RowTemplate.Height = 24
        Me.data_I2C_multi.Size = New System.Drawing.Size(615, 328)
        Me.data_I2C_multi.TabIndex = 3161
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "Temp.(℃)"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn8.Width = 70
        '
        'DataGridViewTextBoxColumn9
        '
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn9.DefaultCellStyle = DataGridViewCellStyle20
        Me.DataGridViewTextBoxColumn9.HeaderText = "Vout(V)"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn9.Width = 65
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Vin1(V)"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn10.Width = 65
        '
        'col_vin2
        '
        Me.col_vin2.HeaderText = "Vin2(V)"
        Me.col_vin2.Name = "col_vin2"
        Me.col_vin2.ReadOnly = True
        Me.col_vin2.Width = 65
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "DC Load(A)"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn11.Width = 80
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "Addr(Hex)"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn12.Width = 65
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "Cmd & Data (Hex)"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn13.Width = 140
        '
        'btn_vout_Clear
        '
        Me.btn_vout_Clear.BackgroundImage = CType(resources.GetObject("btn_vout_Clear.BackgroundImage"), System.Drawing.Image)
        Me.btn_vout_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_vout_Clear.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btn_vout_Clear.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_vout_Clear.Image = CType(resources.GetObject("btn_vout_Clear.Image"), System.Drawing.Image)
        Me.btn_vout_Clear.Location = New System.Drawing.Point(531, 349)
        Me.btn_vout_Clear.Name = "btn_vout_Clear"
        Me.btn_vout_Clear.Size = New System.Drawing.Size(90, 40)
        Me.btn_vout_Clear.TabIndex = 3162
        Me.btn_vout_Clear.Text = "Clear"
        Me.btn_vout_Clear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_vout_Clear.UseVisualStyleBackColor = True
        '
        'TextBox30
        '
        Me.TextBox30.BackColor = System.Drawing.Color.Gray
        Me.TextBox30.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox30.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox30.Location = New System.Drawing.Point(798, 309)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.ReadOnly = True
        Me.TextBox30.Size = New System.Drawing.Size(109, 21)
        Me.TextBox30.TabIndex = 3258
        Me.TextBox30.Text = "Judgment(%)"
        Me.TextBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.LightGray
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.Label4)
        Me.Panel6.Controls.Add(Me.Label31)
        Me.Panel6.Controls.Add(Me.num_pass_eff)
        Me.Panel6.Location = New System.Drawing.Point(798, 330)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(109, 35)
        Me.Panel6.TabIndex = 3262
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(4, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(14, 15)
        Me.Label4.TabIndex = 3157
        Me.Label4.Text = ">"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(85, 9)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(18, 15)
        Me.Label31.TabIndex = 3159
        Me.Label31.Text = "%"
        '
        'num_pass_eff
        '
        Me.num_pass_eff.Location = New System.Drawing.Point(22, 6)
        Me.num_pass_eff.Name = "num_pass_eff"
        Me.num_pass_eff.Size = New System.Drawing.Size(60, 21)
        Me.num_pass_eff.TabIndex = 3030
        Me.num_pass_eff.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.num_pass_eff.Value = New Decimal(New Integer() {70, 0, 0, 0})
        '
        'btn_test_export
        '
        Me.btn_test_export.BackgroundImage = CType(resources.GetObject("btn_test_export.BackgroundImage"), System.Drawing.Image)
        Me.btn_test_export.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_test_export.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btn_test_export.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_test_export.Image = CType(resources.GetObject("btn_test_export.Image"), System.Drawing.Image)
        Me.btn_test_export.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btn_test_export.Location = New System.Drawing.Point(797, 62)
        Me.btn_test_export.Name = "btn_test_export"
        Me.btn_test_export.Size = New System.Drawing.Size(110, 45)
        Me.btn_test_export.TabIndex = 3095
        Me.btn_test_export.Text = "Export"
        Me.btn_test_export.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_test_export.UseVisualStyleBackColor = True
        '
        'btn_test_import
        '
        Me.btn_test_import.BackgroundImage = CType(resources.GetObject("btn_test_import.BackgroundImage"), System.Drawing.Image)
        Me.btn_test_import.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_test_import.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btn_test_import.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_test_import.Image = CType(resources.GetObject("btn_test_import.Image"), System.Drawing.Image)
        Me.btn_test_import.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btn_test_import.Location = New System.Drawing.Point(797, 11)
        Me.btn_test_import.Name = "btn_test_import"
        Me.btn_test_import.Size = New System.Drawing.Size(110, 45)
        Me.btn_test_import.TabIndex = 3094
        Me.btn_test_import.Text = "Import"
        Me.btn_test_import.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_test_import.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Panel3)
        Me.GroupBox5.Controls.Add(Me.PictureBox6)
        Me.GroupBox5.Controls.Add(Me.panel_setting)
        Me.GroupBox5.Controls.Add(Me.pic_VIN2)
        Me.GroupBox5.Controls.Add(Me.PictureBox5)
        Me.GroupBox5.Controls.Add(Me.panel_initial)
        Me.GroupBox5.Controls.Add(Me.PictureBox4)
        Me.GroupBox5.Controls.Add(Me.PictureBox2)
        Me.GroupBox5.Controls.Add(Me.Panel_power2)
        Me.GroupBox5.Controls.Add(Me.Panel21)
        Me.GroupBox5.Controls.Add(Me.Panel20)
        Me.GroupBox5.Controls.Add(Me.PictureBox1)
        Me.GroupBox5.Controls.Add(Me.pic_TA)
        Me.GroupBox5.Controls.Add(Me.panel_chamber)
        Me.GroupBox5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox5.Location = New System.Drawing.Point(5, 6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(135, 422)
        Me.GroupBox5.TabIndex = 3098
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Test Flow"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Silver
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Location = New System.Drawing.Point(9, 370)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(118, 30)
        Me.Panel3.TabIndex = 3586
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Silver
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(30, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 15)
        Me.Label2.TabIndex = 1924
        Me.Label2.Text = "Measure"
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(53, 286)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox6.TabIndex = 3585
        Me.PictureBox6.TabStop = False
        '
        'panel_setting
        '
        Me.panel_setting.BackColor = System.Drawing.Color.Silver
        Me.panel_setting.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panel_setting.Controls.Add(Me.check_vout)
        Me.panel_setting.Location = New System.Drawing.Point(9, 254)
        Me.panel_setting.Name = "panel_setting"
        Me.panel_setting.Size = New System.Drawing.Size(118, 30)
        Me.panel_setting.TabIndex = 3089
        '
        'check_vout
        '
        Me.check_vout.AutoSize = True
        Me.check_vout.ForeColor = System.Drawing.Color.Black
        Me.check_vout.Location = New System.Drawing.Point(18, 4)
        Me.check_vout.Name = "check_vout"
        Me.check_vout.Size = New System.Drawing.Size(78, 19)
        Me.check_vout.TabIndex = 2334
        Me.check_vout.Text = "Multi-Vout"
        Me.check_vout.UseVisualStyleBackColor = True
        '
        'pic_VIN2
        '
        Me.pic_VIN2.Image = CType(resources.GetObject("pic_VIN2.Image"), System.Drawing.Image)
        Me.pic_VIN2.Location = New System.Drawing.Point(53, 81)
        Me.pic_VIN2.Name = "pic_VIN2"
        Me.pic_VIN2.Size = New System.Drawing.Size(24, 24)
        Me.pic_VIN2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pic_VIN2.TabIndex = 3581
        Me.pic_VIN2.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(53, 228)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox5.TabIndex = 3582
        Me.PictureBox5.TabStop = False
        '
        'panel_initial
        '
        Me.panel_initial.BackColor = System.Drawing.Color.Silver
        Me.panel_initial.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panel_initial.Controls.Add(Me.check_initial)
        Me.panel_initial.Location = New System.Drawing.Point(9, 195)
        Me.panel_initial.Name = "panel_initial"
        Me.panel_initial.Size = New System.Drawing.Size(118, 30)
        Me.panel_initial.TabIndex = 3581
        '
        'check_initial
        '
        Me.check_initial.AutoSize = True
        Me.check_initial.ForeColor = System.Drawing.Color.Black
        Me.check_initial.Location = New System.Drawing.Point(19, 4)
        Me.check_initial.Name = "check_initial"
        Me.check_initial.Size = New System.Drawing.Size(77, 19)
        Me.check_initial.TabIndex = 2334
        Me.check_initial.Text = "I2C Initial"
        Me.check_initial.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(53, 344)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox4.TabIndex = 3153
        Me.PictureBox4.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(53, 169)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 3152
        Me.PictureBox2.TabStop = False
        '
        'Panel_power2
        '
        Me.Panel_power2.BackColor = System.Drawing.Color.Silver
        Me.Panel_power2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel_power2.Controls.Add(Me.Label30)
        Me.Panel_power2.Location = New System.Drawing.Point(9, 78)
        Me.Panel_power2.Name = "Panel_power2"
        Me.Panel_power2.Size = New System.Drawing.Size(118, 30)
        Me.Panel_power2.TabIndex = 2805
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Silver
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(31, 6)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(49, 15)
        Me.Label30.TabIndex = 1924
        Me.Label30.Text = "Power2"
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.Silver
        Me.Panel21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel21.Controls.Add(Me.Label33)
        Me.Panel21.Location = New System.Drawing.Point(9, 312)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(118, 30)
        Me.Panel21.TabIndex = 3151
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Silver
        Me.Label33.ForeColor = System.Drawing.Color.Black
        Me.Label33.Location = New System.Drawing.Point(30, 6)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(56, 15)
        Me.Label33.TabIndex = 1924
        Me.Label33.Text = "DC Load"
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.Color.Silver
        Me.Panel20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel20.Controls.Add(Me.Label32)
        Me.Panel20.Location = New System.Drawing.Point(9, 136)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(118, 30)
        Me.Panel20.TabIndex = 3150
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Silver
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(31, 6)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(49, 15)
        Me.Label32.TabIndex = 1924
        Me.Label32.Text = "Power1"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(53, 110)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 3147
        Me.PictureBox1.TabStop = False
        '
        'pic_TA
        '
        Me.pic_TA.Image = CType(resources.GetObject("pic_TA.Image"), System.Drawing.Image)
        Me.pic_TA.Location = New System.Drawing.Point(53, 52)
        Me.pic_TA.Name = "pic_TA"
        Me.pic_TA.Size = New System.Drawing.Size(24, 24)
        Me.pic_TA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pic_TA.TabIndex = 3146
        Me.pic_TA.TabStop = False
        '
        'panel_chamber
        '
        Me.panel_chamber.BackColor = System.Drawing.Color.Silver
        Me.panel_chamber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panel_chamber.Controls.Add(Me.check_temp)
        Me.panel_chamber.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panel_chamber.ForeColor = System.Drawing.Color.White
        Me.panel_chamber.Location = New System.Drawing.Point(9, 19)
        Me.panel_chamber.Name = "panel_chamber"
        Me.panel_chamber.Size = New System.Drawing.Size(118, 30)
        Me.panel_chamber.TabIndex = 2051
        '
        'check_temp
        '
        Me.check_temp.AutoSize = True
        Me.check_temp.ForeColor = System.Drawing.Color.Black
        Me.check_temp.Location = New System.Drawing.Point(19, 4)
        Me.check_temp.Name = "check_temp"
        Me.check_temp.Size = New System.Drawing.Size(78, 19)
        Me.check_temp.TabIndex = 2334
        Me.check_temp.Text = "Chamber"
        Me.check_temp.UseVisualStyleBackColor = True
        '
        'dlgOpen
        '
        Me.dlgOpen.FileName = "OpenFileDialog1"
        '
        'btn_stop
        '
        Me.btn_stop.BackgroundImage = CType(resources.GetObject("btn_stop.BackgroundImage"), System.Drawing.Image)
        Me.btn_stop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_stop.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_stop.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btn_stop.Image = CType(resources.GetObject("btn_stop.Image"), System.Drawing.Image)
        Me.btn_stop.Location = New System.Drawing.Point(797, 384)
        Me.btn_stop.Name = "btn_stop"
        Me.btn_stop.Size = New System.Drawing.Size(110, 45)
        Me.btn_stop.TabIndex = 3099
        Me.btn_stop.Text = "STOP"
        Me.btn_stop.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_stop.UseVisualStyleBackColor = True
        Me.btn_stop.Visible = False
        '
        'btn_run
        '
        Me.btn_run.BackgroundImage = CType(resources.GetObject("btn_run.BackgroundImage"), System.Drawing.Image)
        Me.btn_run.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_run.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_run.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btn_run.Image = CType(resources.GetObject("btn_run.Image"), System.Drawing.Image)
        Me.btn_run.Location = New System.Drawing.Point(798, 384)
        Me.btn_run.Name = "btn_run"
        Me.btn_run.Size = New System.Drawing.Size(110, 45)
        Me.btn_run.TabIndex = 3100
        Me.btn_run.Text = "RUN"
        Me.btn_run.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btn_run.UseVisualStyleBackColor = True
        '
        'TextBox24
        '
        Me.TextBox24.BackColor = System.Drawing.Color.Gray
        Me.TextBox24.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox24.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox24.Location = New System.Drawing.Point(799, 240)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.ReadOnly = True
        Me.TextBox24.Size = New System.Drawing.Size(109, 21)
        Me.TextBox24.TabIndex = 3256
        Me.TextBox24.Text = "Chart Type"
        Me.TextBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel40
        '
        Me.Panel40.BackColor = System.Drawing.Color.LightGray
        Me.Panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel40.Controls.Add(Me.cbox_type_Eff)
        Me.Panel40.Location = New System.Drawing.Point(799, 262)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(109, 35)
        Me.Panel40.TabIndex = 3257
        '
        'cbox_type_Eff
        '
        Me.cbox_type_Eff.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbox_type_Eff.FormattingEnabled = True
        Me.cbox_type_Eff.Items.AddRange(New Object() {"Linear", "Log"})
        Me.cbox_type_Eff.Location = New System.Drawing.Point(13, 5)
        Me.cbox_type_Eff.Name = "cbox_type_Eff"
        Me.cbox_type_Eff.Size = New System.Drawing.Size(83, 23)
        Me.cbox_type_Eff.TabIndex = 3172
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(934, 465)
        Me.Controls.Add(Me.Panel40)
        Me.Controls.Add(Me.btn_run)
        Me.Controls.Add(Me.TextBox24)
        Me.Controls.Add(Me.TextBox30)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.btn_stop)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.btn_test_export)
        Me.Controls.Add(Me.btn_test_import)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Main"
        Me.Text = "I2C Meter Efficiency ATE"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        CType(Me.data_GPIB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.Panel69.ResumeLayout(False)
        Me.Panel69.PerformLayout()
        CType(Me.data_Temp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_TA_delay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_Temp_add, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.Panel_vin2.ResumeLayout(False)
        Me.Panel_vin2.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        CType(Me.num_sense_VIN2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_start_VIN2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        CType(Me.num_VIN_OCP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_start_VIN, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_sense.ResumeLayout(False)
        Me.Panel_sense.PerformLayout()
        CType(Me.num_sense_VIN, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.data_vin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        CType(Me.num_step_iout, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_stop_iout, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_start_iout, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.data_iout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.Panel_out_merte.ResumeLayout(False)
        Me.Panel_out_merte.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.num_slave_out_IO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_resolution_out_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_resolution_out_M, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_resolution_out_L, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_comp_out_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_slave_out_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_comp_out_M, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_slave_out_M, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_comp_out_L, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_slave_out_L, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.num_slave_in_IO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_resolution_in_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_resolution_in_M, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_comp_in_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_slave_in_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_comp_in_M, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_slave_in_M, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_comp_in_L, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_slave_in_L, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_resolution_in_L, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_meter_count, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        CType(Me.num_test_slave_w, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_test_data, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.data_i2c_write, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.num_test_addr_w, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.panel_vout_i2c.ResumeLayout(False)
        Me.panel_vout_i2c.PerformLayout()
        Me.Panel_multivout.ResumeLayout(False)
        Me.Panel_multivout.PerformLayout()
        CType(Me.num_slave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.data_i2c_vout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        CType(Me.data_I2C, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.data_I2C_multi, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.num_pass_eff, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel_setting.ResumeLayout(False)
        Me.panel_setting.PerformLayout()
        CType(Me.pic_VIN2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel_initial.ResumeLayout(False)
        Me.panel_initial.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_power2.ResumeLayout(False)
        Me.Panel_power2.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_TA, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel_chamber.ResumeLayout(False)
        Me.panel_chamber.PerformLayout()
        Me.Panel40.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel8 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_bridge As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_Version As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_error As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents Panel69 As System.Windows.Forms.Panel
    Friend WithEvents data_Temp As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btn_temp_add As System.Windows.Forms.Button
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents num_TA_delay As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_Temp_add As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents btn_scan As System.Windows.Forms.Button
    Friend WithEvents data_GPIB As System.Windows.Forms.DataGridView
    Friend WithEvents col_Instrument As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn35 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_Address As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents num_VIN_OCP As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents num_start_VIN As System.Windows.Forms.NumericUpDown
    Friend WithEvents btn_vin_add As System.Windows.Forms.Button
    Friend WithEvents Panel_sense As System.Windows.Forms.Panel
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents cbox_sense_VIN As System.Windows.Forms.ComboBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents num_sense_VIN As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents data_vin As System.Windows.Forms.DataGridView
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents cbox_VIN As System.Windows.Forms.ComboBox
    Friend WithEvents num_addr_VIN As System.Windows.Forms.TextBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents btn_iout_clear As System.Windows.Forms.Button
    Friend WithEvents cbox_iout_ch As System.Windows.Forms.ComboBox
    Friend WithEvents num_step_iout As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_stop_iout As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_start_iout As System.Windows.Forms.NumericUpDown
    Friend WithEvents btn_iout_add As System.Windows.Forms.Button
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents data_iout As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents num_comp_out_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_slave_out_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_comp_out_M As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_slave_out_M As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_comp_out_L As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_slave_out_L As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbox_daq_vout As System.Windows.Forms.ComboBox
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents num_comp_in_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_slave_in_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_comp_in_M As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_slave_in_M As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_comp_in_L As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_slave_in_L As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents num_resolution_in_L As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents num_meter_count As System.Windows.Forms.NumericUpDown
    Friend WithEvents btn_test_export As System.Windows.Forms.Button
    Friend WithEvents btn_test_import As System.Windows.Forms.Button
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents panel_vout_i2c As System.Windows.Forms.Panel
    Friend WithEvents Panel_multivout As System.Windows.Forms.Panel
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents Lab_note As System.Windows.Forms.Label
    Friend WithEvents num_slave As System.Windows.Forms.NumericUpDown
    Friend WithEvents txt_i2c As System.Windows.Forms.TextBox
    Friend WithEvents data_i2c_vout As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents txt_vout_volt As System.Windows.Forms.TextBox
    Friend WithEvents btn_vout_set As System.Windows.Forms.Button
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents num_test_slave_w As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents num_test_data As System.Windows.Forms.NumericUpDown
    Friend WithEvents btn_add_w As System.Windows.Forms.Button
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents data_i2c_write As System.Windows.Forms.DataGridView
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_data_w As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents num_test_addr_w As System.Windows.Forms.NumericUpDown
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents btn_vout_Clear As System.Windows.Forms.Button
    Friend WithEvents num_resolution_out_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_resolution_out_M As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_resolution_out_L As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_resolution_in_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents num_resolution_in_M As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents Panel_vin2 As System.Windows.Forms.Panel
    Friend WithEvents num_addr_VIN2 As System.Windows.Forms.TextBox
    Friend WithEvents cbox_VIN2 As System.Windows.Forms.ComboBox
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents cbox_sense_VIN2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents num_sense_VIN2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents num_start_VIN2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents num_slave_out_IO As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents num_slave_in_IO As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents btn_add As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents panel_setting As System.Windows.Forms.Panel
    Friend WithEvents check_vout As System.Windows.Forms.CheckBox
    Friend WithEvents pic_VIN2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents panel_initial As System.Windows.Forms.Panel
    Friend WithEvents check_initial As System.Windows.Forms.CheckBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel_power2 As System.Windows.Forms.Panel
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents pic_TA As System.Windows.Forms.PictureBox
    Friend WithEvents panel_chamber As System.Windows.Forms.Panel
    Friend WithEvents check_temp As System.Windows.Forms.CheckBox
    Friend WithEvents VIN2_check As System.Windows.Forms.CheckBox
    Friend WithEvents data_I2C As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents data_I2C_multi As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_vin2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dlgOpen As System.Windows.Forms.OpenFileDialog
    Friend WithEvents dlgSave As System.Windows.Forms.SaveFileDialog
    Friend WithEvents col_VIN As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btn_stop As System.Windows.Forms.Button
    Friend WithEvents btn_run As System.Windows.Forms.Button
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_test_min As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents num_pass_eff As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents Panel40 As System.Windows.Forms.Panel
    Friend WithEvents cbox_type_Eff As System.Windows.Forms.ComboBox
    Friend WithEvents rbtn_iout_load As System.Windows.Forms.RadioButton
    Friend WithEvents rbtn_meter_iout As System.Windows.Forms.RadioButton
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Panel_out_merte As System.Windows.Forms.Panel

End Class
