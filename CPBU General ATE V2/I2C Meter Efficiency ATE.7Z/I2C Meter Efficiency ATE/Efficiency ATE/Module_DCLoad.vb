﻿Module Module_DCLoad


    Public Load_Dev As Integer
    Public Load_addr As Integer


    Public Load_Mode_CC As String = "CC"
    Public Load_Mode_CRL As String = "CRL"
    Public Load_Mode_CRM As String = "CRM"
    Public Load_Mode_CRH As String = "CRH"
    Public Load_Mode_CV As String = "CV"
    Public Load_range_L As String = "L"
    Public Load_range_M As String = "M"
    Public Load_range_H As String = "H"
    Public Load_ch As Integer = 1
    Public Load_mode As String = Load_Mode_CC
    Public Load_device As String
    Public Load_range As String = Load_range_L
    'Public DCLoad_CCH As Double = 2
    Public DCLoad_CCH As Double = 0.8
    Public DCLoad_CCL As Double = 0.2

    Dim ts As String = ""

    Function DCLoad_Iout(ByVal iout_now As Double) As Integer


        If Mid(Load_device, 1, 3) = "636" Then

            If iout_now > DCLoad_CCH And Load_range <> Load_range_H Then
                Load_range = Load_range_H
                load_init(Load_range)
            ElseIf iout_now <= DCLoad_CCH And iout_now > DCLoad_CCL And Load_range <> Load_range_M Then
                Load_range = Load_range_M
                load_init(Load_range)
            ElseIf iout_now <= DCLoad_CCL And Load_range <> Load_range_L Then
                Load_range = Load_range_L
                load_init(Load_range)
            End If


        Else


            If iout_now > DCLoad_CCH And Load_range <> Load_range_H Then
                Load_range = Load_range_H
                load_init(Load_range)
            ElseIf iout_now <= DCLoad_CCH And Load_range <> Load_range_L Then
                Load_range = Load_range_L
                load_init(Load_range)
            End If

        End If



        load_set(iout_now)


    End Function
    Function load_init(ByVal range As String) As Double

        ts = "CHAN " & Load_ch


        ilwrt(Load_Dev, ts, CInt(Len(ts)))

        Select Case Load_mode
            Case "CC"
                If Mid(Load_device, 1, 3) = "630" Then
                    ts = "MODE:CURR:A "
                    ilwrt(Load_Dev, ts, CInt(Len(ts)))
                    Select Case range
                        Case "L"
                            ts = "CURR:RANGE MIN"

                        Case "H"
                            ts = "CURR:RANGE MAX"

                    End Select
                Else
                    Select Case range
                        Case "L"
                            ts = "MODE CCL"

                        Case "H"
                            ts = "MODE CCH"


                        Case "M"

                            ts = "MODE CCM"

                    End Select
                End If
            Case "CRL"

                ts = "MODE CRL"

                'max:2.04 ohm

            Case "CRM"

                ts = "MODE CRM"
                'min: 1.44 ohm
                'max: 2900 ohm

            Case "CRH"

                ts = "MODE CRH"

                '12000 ohm

            Case "CV"
                If Mid(Load_device, 1, 3) = "631" Then

                    ts = "MODE CV"

                Else
                    ts = "MODE CVL"


                End If

        End Select


        ilwrt(Load_Dev, ts, CInt(Len(ts)))

        Delay(100)

    End Function


    Function load_onoff(ByVal onoff As String) As Integer
        ts = "CHAN " & Load_ch

        ilwrt(Load_Dev, ts, CInt(Len(ts)))



        If onoff = "ON" Then
            ts = "LOAD ON"
            'DCLoad_ON = True
        Else
            ts = "LOAD OFF"

            'DCLoad_ON = False
        End If

        ilwrt(Load_Dev, ts, CInt(Len(ts)))

    End Function

    Function load_set(ByVal iout As Double) As Double

        ts = "CHAN " & Load_ch

        ilwrt(Load_Dev, ts, CInt(Len(ts)))

        Select Case Load_mode

            Case "CC"

                If Mid(Load_device, 1, 3) = "630" Then

                    ts = "CURR:A " & Format(iout, "#0.000")
                Else

                    ts = "CURR:STAT:L1 " & Format(iout, "#0.0000")
                End If


            Case "CRL"

                If Mid(Load_device, 1, 3) = "631" Then

                    ts = "RES:L1 " & Format(iout, "#0.000")
                Else

                    ts = "RES:STAT:L1 " & Format(iout, "#0.0000")
                End If
                'RES:STAT:L1 20 ; Set constant resistance=20 Ohm

            Case "CRM"

                If Mid(Load_device, 1, 3) = "631" Then

                    ts = "RES:L1 " & Format(iout, "#0.000")
                Else

                    ts = "RES:STAT:L1 " & Format(iout, "#0.0000")
                End If


            Case "CRH"

                If Mid(Load_device, 1, 3) = "631" Then

                    ts = "RES:L1 " & Format(iout, "#0.000")
                Else

                    ts = "RES:STAT:L1 " & Format(iout, "#0.0000")
                End If



            Case "CV"

                If Mid(Load_device, 1, 3) = "631" Then

                    ts = "VOLT:L1 " & Format(iout, "#0.000")
                Else

                    ts = "VOLT:STAT:L1 " & Format(iout, "#0.0000")
                End If




        End Select




        ilwrt(Load_Dev, ts, CInt(Len(ts)))

        If Mid(Load_device, 1, 3) = "630" Then
            Delay(300)
        End If




    End Function

    Function load_read(ByVal volt_curr As String) As Double
        Dim test As Double = 0

        ts = "CHAN " & Load_ch
        ilwrt(Load_Dev, ts, CInt(Len(ts)))
        Delay(50)

        If volt_curr = "VOLT" Then
            ts = "MEAS:VOLT?"
        Else
            ts = "MEAS:CURR?"
        End If
        ilwrt(Load_Dev, ts, CInt(Len(ts)))
        Delay(50)
        ilrd(Load_Dev, ValueStr, ARRAYSIZE)
        Delay(200)
       
        If (ibcnt > 0) And (ibsta <> EERR) Then

            test = Val(Mid(ValueStr, 1, (ibcntl - 1)))

        End If

        Return test


    End Function


   


    Function Dynamic_init(ByVal Imax As Double, ByVal Imin As Double, ByVal T1 As Double, ByVal T1_unit As String, ByVal T2 As Double, ByVal T2_unit As String, ByVal RISE As Double, ByVal FALL As Double) As Integer



        ts = "CHAN " & Load_ch
        ilwrt(Load_Dev, ts, CInt(Len(ts)))

        If Mid(Load_device, 1, 3) = "630" Then

            ts = "CURR:DYN:H " & Imax

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURR:DYN:L " & Imin

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURR:TIME:T1 " & T1 & T1_unit 'mS, S"

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURR:TIME:T2 " & T2 & T2_unit

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURRent:SLEW:DYNamic:RISE " & RISE ' "A/uS"

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURRent:SLEW:DYNamic:FALL " & FALL ' "A/uS"

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


        Else
            ts = "CURR:DYN:L1 " & Imax

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURR:DYN:L2 " & Imin

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURR:DYN:T1 " & T1 & T1_unit 'mS, S

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURR:DYN:T2 " & T2 & T2_unit

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURRent:DYNamic:RISE " & RISE ' "A/uS"

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


            ts = "CURRent:DYNamic:FALL " & FALL ' "A/uS"

            ilwrt(Load_Dev, ts, CInt(Len(ts)))


        End If



    End Function



End Module
