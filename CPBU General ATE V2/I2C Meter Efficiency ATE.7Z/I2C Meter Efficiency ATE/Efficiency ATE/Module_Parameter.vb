﻿Module Module_Parameter

    'Meter
    Public Relay_OK As Boolean = False
    Public in_high_id, in_low_id, in_middle_id, in_io_id As Integer
    Public in_high_comp, in_low_comp, in_middle_comp As Integer
    Public in_high_resolution, in_low_resolution, in_middle_resolution As Double

    Public out_high_id, out_low_id, out_middle_id, out_io_id As Integer
    Public out_high_comp, out_low_comp, out_middle_comp As Integer
    Public out_high_resolution, out_low_resolution, out_middle_resolution As Double


    Public Meter_H As Double = 9.5
    Public Meter_L As Double = 0.18

    Public vin_meas() As Double
    Public iin_meas() As Double
    Public vout_meas() As Double
    Public iout_meas() As Double
    Public Eff_meas() As Double
    Public loss_meas() As Double
    Public PASS_meas() As String



    Public TA_num As Integer
    Public row_Space As Integer = 5
    Public test_row As Integer = 6
    Public test_col As Integer = 3
    Public start_col As Integer
    Public first_row As Integer
    Public Vout_test_num As Integer
    Public TA_Test_num As Integer
    Public Vin_test_num As Integer
    Public row_num As Integer
    Public col_num As Integer = 7
    Public chart_num As Integer = 0
    Public init_row, end_row As Integer
    Public TA_title As String

    Public Meas_ID_input As Integer
    Public Meas_ID_input_before As Integer
    Public Meas_ID_input_now As Integer
    Public data_input As Byte
    Public resolution_input As Double

    Public Meas_ID_output As Integer
    Public Meas_ID_output_before As Integer
    Public Meas_ID_output_now As Integer
    Public data_output As Byte
    Public resolution_output As Double

End Module
