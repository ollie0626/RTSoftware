﻿Module Module_DAQ
    Public DAQ_name As String
    Public DAQ_Dev As Integer
    Public DAQ_addr As Integer
    Public DAQ_resolution As String = "DEF" 'DEF=5 1/2; MIN=6 1/2; MAX=4 1/2
    Public DC_AUTO As String = "AUTO"
    Public DC_100 As String = "100"
    Public DC_10 As String = "10"
    Public DC_1 As String = "1"
    Public DAQ_unit As String = DC_AUTO
    Dim ts As String
   
    Function DAQ_caculation(ByVal channel As String, ByVal average As Integer) As Double
        Dim i As Integer
        Dim total As Double
        Dim volt(2) As Double ' min max mean
        Dim temp() As Double

        ReDim temp(average - 1)

        For i = 0 To average - 1
            System.Windows.Forms.Application.DoEvents()

            If run = False Then
                Exit For
            End If

            temp(i) = DAQ_read(channel)

            While temp(i) > (10 ^ 10)
                System.Windows.Forms.Application.DoEvents()

                If run = False Then
                    Exit While
                End If

                temp(i) = DAQ_read(channel)

                Delay(10)
            End While

            If i = 0 Then
                total = temp(i)
            Else
                total = total + temp(i)
            End If

        Next

        total = total / average



        'Array.Sort(temp) '由小排到大

        'volt(0) = total 'Mean
        'volt(1) = temp(0) 'MIN
        'volt(2) = temp(average - 1) 'MAX

        Return total
    End Function
    Function DAQ_config(ByVal channel As String) As Integer
        Dim ts As String

        ts = "CONFigure:VOLTage:DC " & DAQ_unit & ", " & DAQ_resolution & ",(@" & channel & ")"
        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))

    End Function

    Function DAQ_read(ByVal channel As String) As Double


        ts = "MEAS:VOLT:DC? " & DAQ_unit & ", " & DAQ_resolution & ",(@" & channel & ")"

        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))
        ilrd(DAQ_Dev, ValueStr, ARRAYSIZE)



        If ibcntl > 0 Then
            Return Val(Mid(ValueStr, 1, ibcntl - 1))
        Else
            Return 0
        End If


    End Function


    Function DAQ_read_Temp(ByVal channel As String, ByVal thermal_type As String) As Double

        ts = "MEAS:TEMP? TC," & thermal_type & ",(@" & channel & ")"

        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))
        ilrd(DAQ_Dev, ValueStr, ARRAYSIZE)



        If ibcntl > 0 Then
            Return Val(Mid(ValueStr, 1, ibcntl - 1))
        Else
            Return 0
        End If


    End Function


    Function DAQ_inputR(ByVal channel As String, ByVal ONOFF As Integer) As Integer
        Dim ts As String = ""

        'AUTO OFF: 10 MΩ (100 mV, 1 V, 10 V, 100 V, 300 V ranges);
        'AUTO ON: > 10 GΩ (100 mV, 1 V, 10 V ranges); 10 MΩ (100 V, 300 V ranges).

        If ONOFF = 0 Then
            ts = "INPUT:IMPEDANCE:AUTO OFF,(@" & channel & ")"

        ElseIf ONOFF = 1 Then
            ts = "INPUT:IMPEDANCE:AUTO ON,(@" & channel & ")"

        End If

        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))


    End Function


    Function DAQ_monitor_set(ByVal channel As String, ByVal on_off As Boolean) As Double

        ts = "ROUTe:MONitor (@" & channel & ")"
        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))


        If on_off = True Then
            ts = "ROUTe:MONitor:STATe ON"
        Else
            ts = "ROUTe:MONitor:STATe OFF"
        End If

        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))
    End Function


    Function DAQ_monitor() As Double


        ts = "ROUTe:MONitor:DATA?"

        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))

        ilrd(DAQ_Dev, ValueStr, ARRAYSIZE)

        If ibcntl > 0 Then
            Return Val(Mid(ValueStr, 1, ibcntl - 1))
        Else
            Return 0
        End If


    End Function

    Function scan_init(ByVal count As Integer, ByVal timer As Double) As Integer
        Dim ts As String = ""

        ts = "TRIG:TIM " & timer / 1000

        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))
        'This command sets the trigger-to-trigger interval (in seconds) for measurements on the channels in the present scan list. 
        'This command defines the time from the start of one trigger to the start of the next trigger, up to the specified trigger count (see TRIGger:COUNt command). 


        ts = "TRIG:COUN " & count
        'This command specifies the number of times to sweep through the scan list. 
        'A sweep is one pass through the scan list. The scan stops when the number of specified sweeps has occurred.


        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))


    End Function

    Function data_scan(ByVal channel As String) As Integer
        Dim ts As String = ""
        Dim value(2) As Double 'MIN, AVER, MAX
        Dim check As Integer = 16


        '--------------------------------------------------------------
        'single scan

        ts = "ROUT:SCAN (@" & channel & ")"

        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))
        'This command selects the channels to be included in the scan list. This command is used in conjunction with the CONFigure commands to set up an automated scan. The specified channels supersede any channels previously defined to be part of the scan list. 
        'To start the scan, use the INITiate or READ? command. 


        '--------------------------------------------------------------

        ts = "INIT"
        'This command changes the state of the triggering system from the "idle" state to the "wait-for-trigger" state. Scanning will begin when the specified trigger conditions are satisfied following the receipt of the INITiate command. Readings are stored in the instrument's internal reading memory. Note that the INITiate command also clears the previous set of readings from memory.

        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))

        While check = 16

            'check = 16 : The instrument is scanning
            ts = "STAT:OPER:COND?"
            'This command queries the condition register for the Standard Operation Register group. This is a read-only register and the bits are not cleared when you read the register
            ilwrt(DAQ_Dev, ts, CInt(Len(ts)))
            ilrd(DAQ_Dev, ValueStr, ARRAYSIZE)
            If ibcntl > 0 Then
                check = Val(Mid(ValueStr, 1, (ibcntl - 1)))
            Else
                Exit While
            End If

        End While

    End Function


    Function data_scan_read(ByVal channel As String, ByVal calculate As String) As Double
        Dim ts As String = ""
        Dim value As Double 'MIN, AVER, MAX
        Dim check As Integer = 2 ^ 15

        'These queries return the minimum, average (arithmetic mean) and maximum values found on each of the specified channels during the scan. Each channel should be a multiplexer, digital or totalizer channel that has been configured to be part of the scan list. If it is not part of the scan list, no error will be generated, but the value returned will be a meaningless value of 0.


        Select Case calculate
            Case "MIN"
                ts = "CALCulate:AVERage:MINimum? (@" & channel & ")"

            Case "AVER"
                ts = "CALCulate:AVERage:AVERage? (@" & channel & ")"

            Case "MAX"
                ts = "CALCulate:AVERage:MAXimum? (@" & channel & ")"

        End Select


        ilwrt(DAQ_Dev, ts, CInt(Len(ts)))

        ilrd(DAQ_Dev, ValueStr, ARRAYSIZE)

        If ibcntl > 0 Then
            value = Val(Mid(ValueStr, 1, (ibcntl - 1)))
        End If

        Return value

    End Function


End Module
