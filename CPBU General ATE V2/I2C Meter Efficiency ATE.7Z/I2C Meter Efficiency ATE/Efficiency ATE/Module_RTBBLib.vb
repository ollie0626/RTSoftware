﻿
Imports RTBBLibDotNet
Module Module_RTBBLib

    Public reg_data(255) As Byte
    Public Device_ID As Byte
    Public pI2CAvailableAddressVBarray(15) As Byte
    Public SlaveAddr As Integer
    Public Result As Integer
    Public currentFreqMode As Integer
    Public currentFreqKHz As Integer
    Public dwFreqCap As Integer
    Public maxFreqKHz As Integer
    Public DataBuffer(&HFF) As Byte

    Public Device_OK As Boolean = False
    Public No_Device As String = "N/A"

    Public Status_Update_W As Boolean = False
    Public Status_Update_R As Boolean = False

 
    Public hEnum As BridgeBoardEnum
    Public hDevice As BridgeBoard
    Public I2C_Module As I2CModule
    Public GSMW_Module As ExtGSMWModule
    Public GPIO_Module As GPIOModule

    Function Check_Eagleboard() As Boolean
        Dim pEnumBoardInfo As BridgeBoard.RTBBInfo
        Dim strLibraryName As String
        Dim strFirmwareInfo As String
        Dim BoardCount As Integer



        hEnum = BridgeBoardEnum.GetBoardEnum()
        BoardCount = hEnum.RTBB_GetBoardCount()



        If BoardCount = 0 Then

            '---------------------------------------------------
            Main.status_bridge.Text = "No board detected"

            Main.status_error.Text = "No Bridge Board detected!!"

            Device_OK = False


            MsgBox("No Bridge Board detected!!", MsgBoxStyle.Exclamation, "Error Message")

        Else


            hEnum.RTBB_GetEnumBoardInfo(0, pEnumBoardInfo)

            strLibraryName = pEnumBoardInfo.strLibraryName

            strFirmwareInfo = pEnumBoardInfo.strFirmwareInfo


            Main.status_bridge.Text = strLibraryName & " (" & strFirmwareInfo & ")"

            'Connect Board
            hDevice = BridgeBoard.ConnectByIndex(hEnum, 0)


            If (IsDBNull(hDevice)) Then

                Main.status_error.Text = "No board detected"
                Exit Function
            End If

            I2C_Module = hDevice.GetI2CModule(0)

            If (IsDBNull(I2C_Module)) Then
                Exit Function
            End If

            Device_OK = True

        End If





    End Function
    Function I2CScan() As Integer
        Dim all_ID As Integer
        Dim pI2CAvailableAddressVBarray As I2CModule.I2CSLAVEADDR
        Dim SlaveAddr As Integer
        Dim check_num As Integer
    
        'in_high_id = num_slave_in_H.Value
        'in_middle_id = num_slave_in_M.Value
        'in_low_id = num_slave_in_L.Value
        'in_io_id = num_slave_in_IO.Value


        'out_high_id = num_slave_out_H.Value
        'out_middle_id = num_slave_out_M.Value
        'out_low_id = num_slave_out_L.Value
        'out_io_id = num_slave_out_IO.Value

        all_ID = 0
        check_num = 0


        Result = I2C_Module.RTBB_I2CScanSlaveDevice(pI2CAvailableAddressVBarray)

        If Result = I2CModule.RT_BB_SUCCESS Then
            SlaveAddr = 0
            While (1)
                SlaveAddr = I2C_Module.RTBB_I2CGetFirstValidSlaveAddr(pI2CAvailableAddressVBarray, SlaveAddr)
                If SlaveAddr < 0 Then
                    Exit While
                End If

                If Main.rbtn_meter_iout.Checked = True Then

                    Select Case SlaveAddr

                        Case in_high_id

                            check_num = check_num + 1

                        Case in_middle_id

                            check_num = check_num + 1

                        Case in_low_id

                            check_num = check_num + 1

                        Case in_io_id

                            check_num = check_num + 1

                        Case out_high_id

                            check_num = check_num + 1

                        Case out_middle_id

                            check_num = check_num + 1

                        Case out_low_id

                            check_num = check_num + 1

                        Case out_io_id

                            check_num = check_num + 1

                    End Select

                Else


                    Select Case SlaveAddr

                        Case in_high_id

                            check_num = check_num + 1

                        Case in_middle_id

                            check_num = check_num + 1

                        Case in_low_id

                            check_num = check_num + 1

                        Case in_io_id

                            check_num = check_num + 1

                    End Select

                End If


                SlaveAddr += 1
            End While

        End If

        If Main.rbtn_meter_iout.Checked = True Then

            If check_num = 8 Then
                Relay_OK = True
            Else
                Relay_OK = False
            End If


        Else

            If check_num = 4 Then
                Relay_OK = True
            Else
                Relay_OK = False
            End If

        End If

       


    End Function

    Function reg_write(ByVal ID As Byte, ByVal addr As Byte, ByVal data As Byte) As String
        Dim i2c_error As Integer

        If Device_OK = True Then

            Main.status_error.Text = ""

            DataBuffer(0) = data

            i2c_error = I2C_Module.RTBB_I2CWrite(ID, 1, addr, 1, DataBuffer)

            'If Status_Update_W = True Then
            '    Main.txt_status.Text = Main.txt_status.Text & "  W" & vbTab & "0x" & addr.ToString("X2") & vbTab & "0x" & data.ToString("X2") & vbNewLine
            'End If


            If i2c_error = 0 Then
                Main.status_error.Text = "I2C Write Success!"
            Else
                MsgBox("I2C Write Error:" & i2c_status(i2c_error), MsgBoxStyle.Exclamation, "Error Message")
                Main.status_error.Text = "I2C Write Error:" & i2c_status(i2c_error)
                run = False

            End If

            Return Result

        End If

      

    End Function
    Function reg_write_word(ByVal ID As Byte, ByVal addr As Byte, ByVal data As Integer, ByVal H_L As String) As Integer
        Dim i2c_error As Integer
        Dim w_data(1) As Integer

        Main.status_error.Text = ""

        w_data = word2byte_data(H_L, data)

        DataBuffer(0) = w_data(0)
        DataBuffer(1) = w_data(1)

        i2c_error = I2C_Module.RTBB_I2CWrite(ID, 1, addr, 2, DataBuffer)



        '設定 register data 為"data", I2C data to be written to device
        If i2c_error = 0 Then

            Main.status_error.Text = "I2C Write Success!"

        Else
            MsgBox("I2C Write Error:" & i2c_status(i2c_error), MsgBoxStyle.Exclamation, "Error Message")
            Main.status_error.Text = "I2C Write Error:" & i2c_status(i2c_error)
            run = False
        End If



        Return i2c_error


    End Function
    Function reg_read(ByVal ID As Byte, ByVal addr As Byte) As Integer()
        Dim i2c_error As Integer
        Dim return_data(1) As Integer


        If Device_OK = True Then

            i2c_error = I2C_Module.RTBB_I2CRead(ID, 1, addr, 1, DataBuffer)

            return_data(0) = i2c_error

            'If Status_Update_R = True Then
            '    Main.txt_status.Text = Main.txt_status.Text & "  R" & vbTab & "0x" & addr.ToString("X2") & vbTab & "0x" & DataBuffer(0).ToString("X2") & vbNewLine
            'End If


            If i2c_error = GlobalVariable.RT_BB_SUCCESS Then

                return_data(1) = DataBuffer(0)
                Main.status_error.Text = "I2C Write Success!"

            Else
                MsgBox("I2C Read Error:" & i2c_status(i2c_error), MsgBoxStyle.Exclamation, "Error Message")
                Main.status_error.Text = "I2C Read Error:" & i2c_status(i2c_error)
                run = False
            End If


            Return return_data

        End If

    


    End Function
    Function reg_read_word(ByVal ID As Byte, ByVal addr As Byte, ByVal H_L As String) As Integer()

        Dim i2c_error As Integer
        Dim return_data(1) As Integer

        Main.status_error.Text = ""

        i2c_error = I2C_Module.RTBB_I2CRead(ID, 1, addr, 2, DataBuffer)


        return_data(0) = i2c_error


        If i2c_error = 0 Then

            If H_L = "H" Then
                'DataBuffer(0):LOW DATA BYTE
                'DataBuffer(1):HIGH DATA BYTE
                return_data(1) = DataBuffer(0) * (2 ^ 8) + DataBuffer(1)
            Else
                return_data(1) = DataBuffer(1) * (2 ^ 8) + DataBuffer(0)
            End If


            Main.status_error.Text = "I2C Read Success!"
        Else
            MsgBox("I2C Read Error:" & i2c_status(i2c_error), MsgBoxStyle.Exclamation, "Error Message")
            Main.status_error.Text = "I2C Read Error:" & i2c_status(i2c_error)
            run = False
        End If


        Return return_data


    End Function
    Function i2c_status(ByVal num As Integer) As String
        Dim status As String = ""

        Select Case num
            Case 0
                status = "RT_BB_SUCCESS"
            Case -1
                status = "RT_BB_BAD_PARAMETER"
            Case -2
                status = "RT_BB_HARDWARE_NOT_FOUND"
            Case -3
                status = "RT_BB_SLAVE_DEVICE_NOT_FOUND"
            Case -4
                status = "RT_BB_TRANSACTION_FAILED"
            Case -5
                status = "RT_BB_SLAVE_OPENNING_FOR_WRITE_FAILED"
            Case -6
                status = "RT_BB_SLAVE_OPENNING_FOR_READ_FAILED"
            Case -7
                status = "RT_BB_SENDING_MEMORY_ADDRESS_FAILED"
            Case -8
                status = "RT_BB_SENDING_DATA_FAILED"
            Case -9
                status = "RT_BB_NOT_IMPLEMENTED"
            Case -10
                status = "RT_BB_NO_ACK"
            Case -11
                status = "RT_BB_DEVICE_BUSY"
            Case -12
                status = "RT_BB_MEMORY_ERROR"
            Case -13
                status = "RT_BB_UNKNOWN_ERROR"
            Case -14
                status = "RT_BB_I2C_TIMEOUT"
            Case -15
                status = "RT_BB_IDLE"
            Case -16
                status = "RT_BB_NO_DATA"
            Case -17
                status = "RT_BB_BUFFER_OVERFLOW"

            Case -18
                status = "RT_BB_HARDWARE_NOT_SUPPORT"
            Case -19
                status = "RT_BB_MEMORY_ACCESS_ERROR"
            Case -20
                status = "RT_BB_GSMW_PIN_MASK_ERROR"
            Case -21
                status = "RT_BB_SVI2_TIMEOUT"
            Case -22
                status = "RT_BB_SVI2_NO_POWER_OK"
            Case -23
                status = "RT_BB_SVI2_ALREADY_BOOTUP"
            Case -24
                status = "RT_BB_SVI2_ALREADY_POWEROFF"
            Case -25
                status = "RT_BB_USB_COMMUNICATION_FAILED"

        End Select

        Return status

    End Function

End Module
