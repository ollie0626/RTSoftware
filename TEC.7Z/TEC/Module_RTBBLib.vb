﻿
Imports RTBBLibDotNet
Module Module_RTBBLib

    Public reg_data(255) As Byte
    Public Device_OK As Boolean = False
    Public hEnum As BridgeBoardEnum
    Public hDevice As BridgeBoard
    Public I2C_Module As I2CModule
    Public GSMW_Module As ExtGSMWModule
    Public GPIO_Module As GPIOModule
    Public Device_ID As Byte
    '---------------------------------------------------------------------
    'I2C
    Public No_Device As String = "N/A"
    Public DataBuffer(&HFF) As Byte
    Public Status_Update_W As Boolean = False
    Public Status_Update_R As Boolean = False
    Dim Result As Integer
    Public count_slave As Integer
    Public all_slave(10) As Byte
    Public all_slave_name As String





    Function Check_Eagleboard() As Boolean
        Dim pEnumBoardInfo As BridgeBoard.RTBBInfo
        Dim strLibraryName As String
        Dim strFirmwareInfo As String
        Dim BoardCount As Integer


        hEnum = BridgeBoardEnum.GetBoardEnum()
        BoardCount = hEnum.RTBB_GetBoardCount()
        '------------
        '如果要使用TEC控制溫度,那要安裝1.4.6版本
        hIsoEnum = RTBB_EnumIsolatedBoard(TEC_ControlFuntion.isoboardNames, TEC_ControlFuntion.isoboardNames.Length)
        pIsoDevice = RTBB_ConnectToIsoBoardByIndex(hIsoEnum, 0)
        '------------
        Device_OK = False

        If BoardCount = 0 Then


            Main.status_error.Text = "No Bridge Board detected!!"
            MsgBox("No Bridge Board detected!!", MsgBoxStyle.Exclamation, "Error Message")
            Device_OK = False
        Else

            Device_OK = True
            hEnum.RTBB_GetEnumBoardInfo(0, pEnumBoardInfo)

            strLibraryName = pEnumBoardInfo.strLibraryName

            strFirmwareInfo = pEnumBoardInfo.strFirmwareInfo


            'Connect Board
            hDevice = BridgeBoard.ConnectByIndex(hEnum, 0)


            If (IsDBNull(hDevice)) Then

                Main.status_error.Text = "No board detected"
                Exit Function
            End If

            I2C_Module = hDevice.GetI2CModule(0)
            GPIO_Module = hDevice.GetGPIOModule()

            Main.status_bridge.Text = "Connect successfully!"

            For i = 0 To 6
                GPIO_Module.RTBB_GPIOSingleSetIODirection(32 + i, True) 'Ouput
                GPIO_Module.RTBB_GPIOSingleWrite(32 + i, False) '0
            Next

            If (IsDBNull(I2C_Module)) Then
                Exit Function
            End If



        End If





    End Function

    Function I2CScan() As Integer

        Dim pI2CAvailableAddressVBarray As I2CModule.I2CSLAVEADDR
        Dim SlaveAddr As Integer


        all_slave_name = ""
        count_slave = 0



        Result = I2C_Module.RTBB_I2CScanSlaveDevice(pI2CAvailableAddressVBarray)

        If Result = I2CModule.RT_BB_SUCCESS Then
            SlaveAddr = 0
            While (1)
                SlaveAddr = I2C_Module.RTBB_I2CGetFirstValidSlaveAddr(pI2CAvailableAddressVBarray, SlaveAddr)
                If SlaveAddr < 0 Then
                    Exit While
                End If

                ReDim Preserve all_slave(count_slave)
                all_slave(count_slave) = SlaveAddr
                all_slave_name = "0x" & Hex(SlaveAddr)


                SlaveAddr += 1
                count_slave = count_slave + 1

            End While

        End If



        For i = 1 To count_slave

            If i = 1 And count_slave = 1 Then

                all_slave_name = "0x" & Hex(all_slave(i - 1))

            Else

                If i = count_slave Then

                    all_slave_name = all_slave_name & "0x" & Hex(all_slave(i - 1))

                Else

                    all_slave_name = all_slave_name & "0x" & Hex(all_slave(i - 1)) & ","

                End If


            End If


        Next





    End Function

    Function reg_write(ByVal ID As Byte, ByVal addr As Byte, ByVal data As Byte) As String
        Dim i2c_error As Integer

        Main.status_error.Text = ""

        DataBuffer(0) = data

        i2c_error = I2C_Module.RTBB_I2CWrite(ID, 1, addr, 1, DataBuffer)


        If i2c_error = 0 Then
            Main.status_error.Text = "I2C Write Success!"
        Else
            Main.status_error.Text = "I2C Write Error:" & i2c_status(i2c_error)
        End If

        Return Result

    End Function
    Function reg_read(ByVal ID As Byte, ByVal addr As Byte) As Integer()
        Dim i2c_error As Integer
        Dim return_data(1) As Integer


        i2c_error = I2C_Module.RTBB_I2CRead(ID, 1, addr, 1, DataBuffer)

        return_data(0) = i2c_error


        If i2c_error = GlobalVariable.RT_BB_SUCCESS Then

            return_data(1) = DataBuffer(0)
            Main.status_error.Text = "I2C Write Success!"

        Else
            Main.status_error.Text = "I2C Read Error:" & i2c_status(i2c_error)

        End If


        Return return_data


    End Function

    'Function reg_write_word(ByVal ID As Byte, ByVal addr As Byte, ByVal data As Integer, ByVal H_L As String) As Integer
    '    Dim i2c_error As Integer
    '    Dim w_data(1) As Integer

    '    Main.status_error.Text = ""

    '    w_data = word2byte_data(H_L, data)

    '    DataBuffer(0) = w_data(0)
    '    DataBuffer(1) = w_data(1)

    '    i2c_error = I2C_Module.RTBB_I2CWrite(ID, 1, addr, 2, DataBuffer)



    '    '設定 register data 為"data", I2C data to be written to device
    '    If i2c_error = 0 Then

    '        Main.status_error.Text = "I2C Write Success!"

    '    Else

    '        Main.status_error.Text = "I2C Write Error:" & i2c_status(i2c_error)

    '    End If



    '    Return i2c_error


    'End Function

    Function reg_read_word(ByVal ID As Byte, ByVal addr As Byte, ByVal H_L As String) As Integer()

        Dim i2c_error As Integer
        Dim return_data(1) As Integer

        Main.status_error.Text = ""

        i2c_error = I2C_Module.RTBB_I2CRead(ID, 1, addr, 2, DataBuffer)


        return_data(0) = i2c_error


        If i2c_error = 0 Then

            If H_L = "H" Then
                'DataBuffer(0):LOW DATA BYTE
                'DataBuffer(1):HIGH DATA BYTE
                return_data(1) = DataBuffer(0) * (2 ^ 8) + DataBuffer(1)
            Else
                return_data(1) = DataBuffer(1) * (2 ^ 8) + DataBuffer(0)
            End If


            Main.status_error.Text = "I2C Read Success!"
        Else

            Main.status_error.Text = "I2C Read Error:" & i2c_status(i2c_error)

        End If


        Return return_data


    End Function
    Function GPIO_out(ByVal bits As Integer, ByVal bit_value() As Integer) As Integer
        Dim i As Integer

        For i = 0 To bits - 1
            If bit_value(i) = 0 Then
                GPIO_Module.RTBB_GPIOSingleWrite(32 + i, False) '0
            Else
                GPIO_Module.RTBB_GPIOSingleWrite(32 + i, True) '1
            End If

        Next



    End Function
    Function i2c_status(ByVal num As Integer) As String
        Dim status As String = ""

        Select Case num
            Case 0
                status = "RT_BB_SUCCESS"
            Case -1
                status = "RT_BB_BAD_PARAMETER"
            Case -2
                status = "RT_BB_HARDWARE_NOT_FOUND"
            Case -3
                status = "RT_BB_SLAVE_DEVICE_NOT_FOUND"
            Case -4
                status = "RT_BB_TRANSACTION_FAILED"
            Case -5
                status = "RT_BB_SLAVE_OPENNING_FOR_WRITE_FAILED"
            Case -6
                status = "RT_BB_SLAVE_OPENNING_FOR_READ_FAILED"
            Case -7
                status = "RT_BB_SENDING_MEMORY_ADDRESS_FAILED"
            Case -8
                status = "RT_BB_SENDING_DATA_FAILED"
            Case -9
                status = "RT_BB_NOT_IMPLEMENTED"
            Case -10
                status = "RT_BB_NO_ACK"
            Case -11
                status = "RT_BB_DEVICE_BUSY"
            Case -12
                status = "RT_BB_MEMORY_ERROR"
            Case -13
                status = "RT_BB_UNKNOWN_ERROR"
            Case -14
                status = "RT_BB_I2C_TIMEOUT"
            Case -15
                status = "RT_BB_IDLE"
            Case -16
                status = "RT_BB_NO_DATA"
            Case -17
                status = "RT_BB_BUFFER_OVERFLOW"

            Case -18
                status = "RT_BB_HARDWARE_NOT_SUPPORT"
            Case -19
                status = "RT_BB_MEMORY_ACCESS_ERROR"
            Case -20
                status = "RT_BB_GSMW_PIN_MASK_ERROR"
            Case -21
                status = "RT_BB_SVI2_TIMEOUT"
            Case -22
                status = "RT_BB_SVI2_NO_POWER_OK"
            Case -23
                status = "RT_BB_SVI2_ALREADY_BOOTUP"
            Case -24
                status = "RT_BB_SVI2_ALREADY_POWEROFF"
            Case -25
                status = "RT_BB_USB_COMMUNICATION_FAILED"

        End Select

        Return status

    End Function

End Module
